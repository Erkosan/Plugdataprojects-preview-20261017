# KÖTTDISK 3000

Första instrumentet i **KÖTTETS LUSTAR**, en ny delserie inom 3000-serien.
En fristående sexrösters FM-klaviatur med fyra operatorer, inte en samlingsyta
för flera instrument. Nästa instrument och en eventuell sammankoppling ingår
inte i den här leveransen.

## Källa och arbetsgräns

- Normerande dokumentation: `feat/landningssida`, commit
  `d1212fc904ca322dd4b8d58528a0794be680faf2`, 2026-10-17 19:28 +02:00.
- Dokumenten lästes i `/home/elias/Plugdataprojects-landning`; samtliga tolv
  efterfrågade filer var identiska med den committen.
- Ny kod skrivs i en separat klon, branch `codex/kottets-lustar-kottdisk`.
- Claude-arbetsytor, brancher, processer och byggen har lämnats orörda.
  Inget pågående Claude- eller Antigravity-material har återanvänts.
- Nya ljudpatchar, paneler och byggadapter är skrivna för denna maskin.
  Gemensamma externa beroenden hämtas till den egna arbetsytan.
- Inga ändringar publiceras till runken.nu eller befintliga previews.

## Bygg och kör

Från repots rot, med Python 3.11+ och C/C++-verktyg installerade:

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements-kottdisk.txt
.venv/bin/python tools/build_kottdisk.py --native --vst3 --kit
python3 -m http.server 8000 --directory synths/Kottdisk/web/dist
```

Webbygget kräver Emscripten **3.1.69** i `~/emsdk` eller `EMSDK`.
VST3-bygget hämtar DPF och låser den till
`4238e1c7f0351bbe488d79f0899c540543ac7583`.
`--skip-web --vst3 --kit` bygger bara VST3 och källpaketet utan Emscripten.
`--native` bygger testbiblioteket för Linux; utelämna den flaggan på Mac/Windows.

På Mac behövs Xcode Command Line Tools, Python och Git. På Windows behövs
MSYS2 UCRT64 med GCC/Make och Python; kör byggkommandot från den miljön.
Mac- och Windows-byggena är inte verifierade i denna leverans.

Resultat: `synths/Kottdisk/web/dist/` samt
`build/kottdisk/heavy/bin/Kottdisk.vst3`.
Kugghjulsmenyn erbjuder Linux-VST3 och ett eget käll-/byggpaket.

## Verifiera

```sh
.venv/bin/python tests/test_kottdisk.py
npm install --prefix synths/Kottdisk
node tests/run_kottdisk_web.cjs
.venv/bin/python tests/run_kottdisk_vst3.py
```

Webbtestet kräver `playwright-core` för Node och Chromium; sökvägar kan anges
i testets miljövariabler. Det mäter riktigt ljud från AudioWorklet/WASM.
VST3-testet laddar pluginen i Pedalboards JUCE-värd och spelar MIDI.
Aktuella resultat och previewadress finns i [LEVERANS.md](LEVERANS.md).

De två panelerna visar svenska Å/Ä/Ö. Den låsta DPF-versionens VST3-export
kapar dessa tecken i värdparameternamn; därför använder DAW-listan entydiga
ASCII-namn som MORHET, MORA och LAT VILA. Parameter-ID:n och symboler påverkas inte.

## Design och kontrakt

Vinröd emalj, mässing, slaktarpapper och en egenritad delikatessdisk.
Fast panel 1200 × 750, tvåoktavspiano och fjorton parametrar. Displayen visar
reglagen 0–100; VOLYM ligger på panelen, övrigt skal under kugghjulet.
Fabriksdemot följer c-moll. Ingen TONART- eller BPM-ratt finns. Värden kan
skicka tempo/transport genom `window.kottdisk.setTransport({bpm,playing})`.
Utan värd har den frivilliga webb-demofrasen 120 BPM som startvärde.

JavaScript ritar och skickar MIDI/parametrar; alla ljud och effekter kommer
från samma PlugData-patch i webb och VST3. Nativepanelen visar sina egna
nedtryckta noter; DAW-noter har ingen fabricerad visualisering.

Ljudkontrakt, MIDI, skalningar och redigerbar PlugData-panel beskrivs i
[`synths/Kottdisk/README.md`](../../synths/Kottdisk/README.md).

## Ombyggnad 0.2.0

Aktuell branch är `codex/kottdisk-overhaul`. Se [OVERHAUL.md](OVERHAUL.md)
för ljudändringar, verkliga långtester och publiceringsstatus.
