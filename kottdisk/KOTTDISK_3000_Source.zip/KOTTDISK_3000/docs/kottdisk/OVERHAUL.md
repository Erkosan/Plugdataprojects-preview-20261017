# KÖTTDISK 3000 · ombyggnad 0.2.0

## Leverans och källa

Primär preview: https://erkosan.github.io/Plugdataprojects-preview-20261017/kottets-lustar/?v=overhaul-3

Egen källklon `/home/elias/3000-kottdisk-codex`, branch `codex/kottdisk-overhaul`.
Preview publiceras från en separat klon och branch med samma namn i
`Erkosan/Plugdataprojects-preview-20261017`. Endast `kottets-lustar/` uppdateras.
`web/dist/build.json` anger paketets exakta källcommit.

Normerande dokumentation: `/home/elias/Plugdataprojects-landning`,
`feat/landningssida`, `d1212fc904ca322dd4b8d58528a0794be680faf2`.
AGENTS, KONCEPT, MASKINER, ARKITEKTUR, PLANER, NY-MASKIN, BRAND,
BYGGA-OCH-TESTA och PUBLICERA lästes där. IDEER, TEKNISKA-FORSLAG och
BEDOMNING behandlades som förslag. Inga gemensamma beslut ändras.

## Ljud och spel

Samma redigerbara PlugData-patch kompileras till webbens WASM och Linux-VST3.
Fyra operatorer ger bestående övertoner, kropp och korsmodulation.
STYCKNING ändrar förhållandet kontinuerligt, FETT ger asymmetrisk mättnad och
SALUHALL använder sex korta resonanta stereoreflexer utan rekursiv återkoppling.
MÖRA återexciterar en redan hållen ton. Sex omgjorda presets och demofrasen
visar olika klanger; c-moll är standard och tempot kommer från värden.

Den befintliga delikatessillustrationen är spelbar: köttbiten ger MÖRA,
steken ger BEN (tonhöjdsföljande metallanslag), korven ger KVARNA
(temposynkad spektral malning). Håll och dra nedåt för svagare BEN/KVARNA.
Nativepanelen och den redigerbara Pd-panelen har motsvarande funktioner.
De ursprungliga tolv parametrarnas ID:n, namn och CC bevaras;
`zz_kd_bone` och `zz_kd_grind` läggs sist, index 12 och 13.

Rattar stödjer fångad mus/touch, inkrementell finjustering med Skift,
rullhjul, tangentbord och återställning med dubbeltryck. Förlorat fokus,
meny och panik släpper ägda spelgester. Äldre tolvsparametrars sessioner läses.
Vinröd/mässingsfärgad fast panel och den sparsamma svenska texten bevaras.

## Ljudlivscykel

AudioContext aktiveras i den ursprungliga spelgesten före nätverksväntan.
WASM och worklet hämtas som en självständig modul. Runtimefel och ogiltiga
PCM-sampel gör motorn explicit osund; nästa spelgest kan skapa en ny motor,
återställa parametrar och spela om hållna noter. Regelbundna hälsomeddelanden
visar framsteg och kölängd. Parameterändringar samlas per renderblock;
MIDI-kön begränsas och panik tömmer den. Bufferten följer blockets verkliga
storlek. All syntes och alla effekter ligger fortfarande i Pd.

## Verifiering

- Fullt bygge av hvcc/Pd, Emscripten/WASM, nativt testbibliotek, Linux-VST3
  och nedladdningspaket lyckades.
- 15 nativa motortester: de tidigare sju plus åtta karaktärs-/stabilitetstester.
  Bestående övertoner, närliggande STYCKNING-värden, MÖRA på hållen ton,
  BEN, temposynkad KVARNA, determinism, extrema toner och automation vid
  44,1/48/96 kHz verifieras med riktiga PCM-data.
- Nio verkliga VST3-värdtester i Pedalboard/JUCE passerar, inklusive
  fjorton parametrar, alla åtta klang-/spelreglagens ljudskillnader,
  MIDI-tidpunkt, state-roundtrip och ytterlägen. `vst3-tests.json`.
- 18 Chromium-integrationstester passerar: riktig WASM, ljudmätning,
  release/sustain/panik, tempo, touch, sessioner, nedladdningar och requests.
- 56 ytterligare interaktionskontroller passerar mot slutlig dist.
  `overhaul-interactions.json`.
- Tre Chromium-långpass med över 120 sekunders faktisk aktivitet vardera:
  blandad spelning, oavbrutet hållet ackord samt CC-/rattbelastning.
  Ljudet förblir ändligt och begränsat; inga processor-/sid-/requestfel.
  Råa PCM-mätningar, hälsa, källhashar och antal gester finns i
  `overhaul-stress.json`. Rapporten behåller även baslinjer och två tidigare
  testinfrastrukturfel: sandboxstart samt asynkront CDP-touchCancel-kvitto.
- Verklig Playwright WebKit: spelgest startar WASM-ljud, 120,63 sekunders
  rattande (168 cykler), färska toner och suspend/resume passerar.
  `webkit-tests.json` innehåller även ett kort test av tidigare publicerad version.
- Fyra adaptertester verifierar gestaktivering, retry, avbruten kontext och
  återhämtning efter processor-/PCM-fel. Dessa testar livscykeln med mockad
  värd; ljudsviterna ovan använder riktig syntes.
- Fyra stereo-WAV-exempel renderas direkt ur den kompilerade Pd-motorn med
  `tools/render_kottdisk_character.py`. Resultat hamnar i `build/kottdisk/character`; fyra referensrenderingar
  med mätningar är även incheckade i `docs/kottdisk/character/`.

## Begränsningar och isolering

Användarens ursprungliga Chrome-bortfall och Safari-problem gick inte att
reproducera säkert i baslinjen. STYCKNINGs ursprungliga geometriska låsning
reproducerades inte heller; däremot saknades rullhjulsstöd och drag kunde
fortsätta efter fokusförlust. Därför redovisas testad robusthet och verkliga
ändringar, ingen säkerställd universell rotorsak.

Linux-WebKit är inte ett faktiskt test i Safari på användarens Mac/iPhone.
Mac-/Windows-binärer, fysisk MIDI, extern desktop-DAW och native-GUI med riktig
mus är inte provade. DPF/JUCE skriver befintliga livscykelvarningar trots
passerande ljud-/statetester; de finns i VST3-rapporten. Mätningar ersätter
inte användarens bedömning av musikalisk karaktär genom lyssning.

Claude:s och Antigravitys filer, processer, brancher och worktrees har lämnats
orörda. Ingen pågående kod, ocommittad ändring eller bygge därifrån används.
runken.nu och andra previews ändras inte. Den äldre privata Sites-adressen
är inte huvudpreview för denna ombyggnad; använd GitHub Pages-länken ovan.
