# KÖTTDISK 3000 · leverans

KÖTTETS LUSTARs första instrument: en separat webbsida och VST3, med sex
anslagskänsliga röster och fyra FM-operatorer. Inget andra instrument eller ny värd är byggt.

- Dokumentationsbas: `d1212fc904ca322dd4b8d58528a0794be680faf2`, läst i
  `/home/elias/Plugdataprojects-landning`, branch `feat/landningssida`.
- Egen klon: `/home/elias/3000-kottdisk-codex`.
- GitHub-branch: `codex/kottets-lustar-kottdisk`.
- Första källcommit: `675f0a3`.
- Preview: https://kottdisk-3000-codex.elias-pg-holm.chatgpt.site
  (se publiceringsjournalen nedan för verifierad status).
- `synths/Kottdisk/web/dist/build.json` anger exakt källcommit för paketet.
- Linux-VST3, käll-/byggpaket, redigerbara Pd-patchar, webbkälla, tester och
  bild finns i samma branch. Katalogregistret innehåller en ny artikel och ett
  20-sekundersklipp renderat från den riktiga ljudmotorn; katalogen publiceras inte.

## Tester

- hvcc 0.17.2, Emscripten 3.1.69 och Linux-VST3 med låst DPF: byggda.
- Sju nativa ljudtester godkända: stämning, anslag, sex röster, sustainackord,
  separata kanalidentiteter, röststöld, CC, release, klangreglage och ytterlägen
  vid 44,1/48/96 kHz. Resultat: `native-tests.txt`.
- 17 Chromiumkontroller godkända med verkligt AudioWorklet/WASM-ljud.
  Toner, ackord, uppmätt klang/volym, tystnad, sustain, transport, multitouch,
  sessioner, meny, mobilskalning och requests. Noll sid-/console-/HTTP-/requestfel.
  Mätningar: `web-tests.json`.
- Nio VST3-kontroller godkända i Pedalboard 0.9.26 / JUCE. Riktiga MIDI- och
  ljuddata, anslag, ackord, kanaler, sustain/panik, 14 CC-mappningar och sparade
  parametrar, klangreglage, state-roundtrip och stabilitet. MIDI schemalagd vid
  sample 1500 hörs från 1501, med exakt tystnad före. Högsta uppmätta CPU-kvot
  0,122 vid 96 kHz. Binärens SHA256 finns i `vst3-tests.json`.
- Den gemensamma ingången `tests/run_vst3_host.py` känner igen KÖTTDISK och
  använder samma dedikerade verkliga värdtest, utan långsam enhetsgissning av
  DPF:s syntetiska MIDI-parametrar.
- Python- och JavaScript-syntax samt katalogregistrets validering: godkända.

## Begränsningar

Mac- och Windows-binärer är inte byggda eller provade här. Safari/iPhone,
fysiska MIDI-enheter, användarens DAW och nativepanelens riktiga GUI-interaktion
är inte provade. Chromiumtesterna mäter ljud; musikalisk kvalitet behöver också
bedömas genom lyssning. Pedalboard kräver att dess långsamma Python-inferens av
DPF:s syntetiska MIDI-parametrar hoppas över; DSP, MIDI, VST3 och JUCE-värden
är oförändrade. Värden skriver DPF-livscykelvarningar, redovisade i rapporten,
men ljud- och statetesterna passerar. DAW-parameternamn translittereras till
ASCII på grund av den låsta DPF-versionens titelkonvertering; båda panelerna
visar full svensk text. MIDI-CC verifieras mot pluginens sparade komponentstate;
värdens automatiska uppdatering av öppna GUI-reglage beror på värdstöd.

## Isolering och publicering

Claude:s och Antigravitys filer, brancher, processer och worktrees har lämnats
orörda. Ingen pågående kod, ocommittad ändring eller bygge därifrån används.
Ny kod och egenritad vektorgrafik ligger i den egna branchen. runken.nu,
serverkonfigurationen och andra previews har inte ändrats.

Sites används för en egen privat testpreview, med åtkomst för ägaren.
Publicering verifierad av Sites: **succeeded**.

- URL: https://kottdisk-3000-codex.elias-pg-holm.chatgpt.site
- Deploy: `appgdep_6ad3f68c9798819181543aed5e57a782`.
- Sites-version: `appgprj_6ad3c8a5301481918100c09bbad737ff~appgver_2f4fda4468288191a8eeb6dd8efee8ec`.
- Sites-källsnapshot: `2f83ccd864e3122c953c88cc8bfb74bcb85f112e`.
- Instrumentets källcommits: `675f0a3`, `fc20d29`, `dd6eea3`.
- Levererade paket anger källcommit `dd6eea3` i build.json. Webbens Chromiumtest
  kördes lokalt mot samma filer; ingen separat inloggad browsertestning av den
  privata liveadressen har gjorts. Publiceringen är verifierad av Sites.
- Filerna och paketen kan verifieras mot `artifact-sha256.json`.


## Uppdaterad ljudstart

Se [LJUDSTART.md](LJUDSTART.md). Primär testadress är nu den verifierade
GitHub Pages-versionen:
https://erkosan.github.io/Plugdataprojects-preview-20261017/kottets-lustar/?v=audio-2

18 Chromiumkontroller har körts direkt på den publicerade sidan med vanlig
autoplay-policy, plus tre regressionskontroller av startadaptern. Ljudmotorn
och Linux-VST3-binären är oförändrade. Nya källcommitten är `03191af`.


## Ombyggnad 0.2.0

Aktuell leverans, tester och begränsningar finns i [OVERHAUL.md](OVERHAUL.md).
Branch: `codex/kottdisk-overhaul`. GitHub Pages är huvudpreview.
