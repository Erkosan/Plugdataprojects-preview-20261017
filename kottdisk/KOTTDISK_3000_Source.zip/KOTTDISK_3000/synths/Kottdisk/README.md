# KÖTTDISK 3000

Första och enda instrumentet i KÖTTETS LUSTAR: ett anslagskänsligt FM-keyboard med sex röster och fyra fasoperatorer per röst. Av Pastor Gregorius.

Öppna `kottdisk.pd` i PlugData. Den redigerbara panelen är 1200 × 750 på ett 25-pixelsrutnät. Pianot har två oktaver, C3–B4; klick spelar ett kort anslag. Ett externt MIDI-keyboard ger full anslagskänslighet och hålltid. Samma patch kompileras med hvcc 0.17.2 till webb och VST3. Webbsidans JavaScript producerar inget ljud.

`KD_Engine.pd` samlar sex separata `KD_Voice.pd`, `KD_Parameters.pd` och `KD_Midi.pd`. Fyra operatorer bildar två hörbara kroppar: en stadig grundton med fasmodulation och en övertonskropp som korsmoduleras av en hård, delvis inharmonisk klang. Övertonerna fortsätter klinga efter anslaget. STYCKNING rör kvoten kontinuerligt genom harmoniska och inharmoniska lägen. Ett separat anslag ger en kort klangrörelse; FM-djupet begränsas i diskanten. FETT driver en asymmetrisk, nivåkompenserad mättnad. SALUHALL blandar två metallresonanser med sex olika stereoreflexer, 23–263 ms. Ingen ljudåterkoppling kan självsvänga. Samtliga inställningar har startvärden via `loadbang` och utjämnade signalvägar där det behövs.

| Parameter | Panel | Standard | MIDI CC |
|---|---|---:|---:|
| `kd_volume` | VOLYM · UTNIVÅ | 0.65 | 7 |
| `kd_tone` | DISK · LJUSHET | 0.65 | 16 |
| `kd_bite` | MARMORERING · FM | 0.35 | 17 samt 1 |
| `kd_ratio` | STYCKNING · ÖVERTONER | 0.25 | 18 |
| `kd_attack` | ANSATS · ANSATS | 0.08 | 19 |
| `kd_decay` | MÖRHET · AVKLINGNING | 0.40 | 20 |
| `kd_sustain` | KROPP · HÅLLNIVÅ | 0.45 | 21 |
| `kd_release` | VILA · SLÄPP | 0.30 | 22 |
| `kd_warmth` | FETT · MÄTTNAD | 0.20 | 23 |
| `kd_space` | SALUHALL · RUM | 0.18 | 24 |
| `kd_tender` | MÖRA · ANSLAG | 0 | 25 |
| `kd_hold` | LÅT VILA · HÅLL TONER | 0 | 26 samt 64 |
| `zz_kd_bone` | BEN · ANSLAG | 0 | – |
| `zz_kd_grind` | KVARNA · MALNING | 0 | – |

Alla fjorton parametrar har intervallet 0–1 och är deklarerade som `@hv_param`. De tolv ursprungliga parametrarnas namn, alfabetiska ID 0–11, CC och standardvärden är bevarade. BEN och KVARNA ligger sist, ID 12 respektive 13. `kd_ratio` rör kvoten kontinuerligt enligt `1 + 7 × värde²`; den förändrar också övertonskroppens tyngd och metallens deltoner. Attack är 3–1203 ms, decay 35–2435 ms och release 30–3230 ms med kvadratisk rattkurva. LÅT VILA är aktiv från 0.5. MÖRA på PlugData-panelen är en 180 ms lång gest; webb och värd skickar själva 1 vid nedtryck och 0 vid släpp. En stigande kant ger ett verkligt 170 ms slag med klang- och styrkerörelse i redan klingande röster. BEN slår en tonhöjdsföljande hård delton med 480 ms avklingning; ett kvarhållet värde behåller dess hårda klang. KVARNA skrapar två deltoner mot varandra samtidigt som fyra tänder per fjärdedelsnot hackar ljudet. Tempot kommer från `__hv_dpf_bpm` (120 som reservvärde, begränsat till 20–400), och MIDI-start nollställer tandfasen. Gesterna använder ingen slump. PlugData-panelens BEN spelar 250 ms och KVARNA 1000 ms; webbens ytor följer nedtryck/släpp. MIDI CC25, CC26 och CC64 är binära: värden från 64 aktiverar gesten, lägre värden släpper den. Ingen tonart eller tempoparameter finns. Exempel och presets skrivs i c-moll.

MIDI lyssnar på kanal **1 och 9**. Kanalnumren från vanilla Pd `notein` och `ctlin` är ettbaserade. Heavy-mottagarna `__hv_notein` och `__hv_ctlin` använder däremot nollbaserade kanaler: wrappers ska skicka **0 eller 8**, så översätter hvcc:s standardabstraktioner till 1 och 9. Note-on med anslag 0 fungerar som note-off. Kanalernas noter har separata interna identiteter (`ton + 128 × kanalindex`) så att samma ton på den ena kanalen inte släpps av den andras note-off. Innan `mtof` återställs identiteten till tonnumret med modulo 128.

Hållpedalen skjuter upp note-off före `poly 6 1`, med en tabell över väntande släpp för de 256 kanal/ton-identiteterna. Släppta tangenter behåller därför sin röst tills pedalen släpps eller den sjunde tonen stjäl den äldsta aktiva rösten. Pedalsläpp skickar endast de väntande släppen, så fysiskt nedtryckta tangenter fortsätter klinga. Ett nytt anslag av samma ton på samma kanal ersätter föregående anslag och rensar dess väntande släpp. CC120 och CC123 tystar alla röster med en 5 ms ramp, tömmer väntande släpp och nollställer röstfördelaren samt parametrarna LÅT VILA, MÖRA, BEN och KVARNA direkt i patchen. Slagets privata envelopper stoppas också; rummets ändliga reflektionssvans klingar ut.

PlugData-pianot skickar interna listor `ton anslag` till `kd_ui_note`; webben och VST3 använder standard-MIDI, aldrig en separat syntmotor. GUI-mottagarna `kd_*_ui` använder explicita `set`-meddelanden och `route float` på sändningssidan för att spegla värden utan rundgång även i Heavy. Patchen har inga externa ljudbibliotek, samples, JavaScript-oscillatorer eller separata ljudfiler. För mycket tät MIDI använder wrappers lämpligen `hv_Kottdisk_new_with_options(sr,64,32,8)` i stället för standardkön.

Källan är de incheckade `.pd`-filerna. Layouten och kabeldragningen kan även återbildas deterministiskt med `python3 synths/Kottdisk/generate_patch.py`. Kompilera med `hvcc synths/Kottdisk/kottdisk.pd -n Kottdisk -o /tmp/kottdisk-audio-check`; motorprefixet är `hv_Kottdisk_*`. Plugin-ID är `Kd30`, varumärkes-ID `Erks`.

Bygg- och testkommandon för webb och VST3 finns i repots byggverktyg. Riktigt ljud ska kontrolleras med nativ motortest, Chromium och VST3-värd. Plattformar som inte faktiskt har provats ska redovisas separat.

## Ljudprov och regression

`tests/test_kottdisk_character.py` mäter kvarvarande övertoner i hållna toner, kontinuerlig STYCKNING, MÖRA efter att ett anslag lagt sig, BEN/KVARNAs spektrala skillnader, stereoreflexer, värdens tempoföljning, reproducerbar rendering och återhämtning efter tät automation. Testet använder den kompilerade Pd-motorn; `KOTTDISK_CHARACTER_LIB` kan välja en isolerad nativ biblioteksfil. De ursprungliga motortesterna kontrollerar dessutom MIDI, röststöld, sustain, amplitud, tonhöjd och extrema värden vid 44,1/48/96 kHz.

`python tools/render_kottdisk_character.py` skriver fyra o-normaliserade stereo-WAV-filer i `build/kottdisk/character/`: SKINKSAMMET (mjuk ackordkropp), KNIVSPETS (kort och ljus), BENPORSLIN (hårda stämda anslag) och FLÄSKMORR (bas med MÖRA och KVARNA i andra halvan). Allt spelas i c-moll, genom samma motor. `measurements.json` innehåller nivåer, klangtyngdpunkt och exakta presetvärden.
