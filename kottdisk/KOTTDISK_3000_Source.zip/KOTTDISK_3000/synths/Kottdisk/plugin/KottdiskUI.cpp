// KÖTTDISK 3000 · Pastor Gregorius
// Native panel. Sound and parameter storage belong to the generated Pd plugin.
#include "DistrhoUI.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

START_NAMESPACE_DISTRHO
using DGL_NAMESPACE::Color;

namespace {
enum Parameter {
    Attack, Bite, Decay, Hold, Ratio, Release, Space, Sustain, Tender,
    Tone, Volume, Warmth, Bone, Grind, ParameterCount
};
static_assert(Attack == 0 && Warmth == 11 && Bone == 12 && Grind == 13,
              "Existing host parameter indices must remain stable");
struct Control {
    unsigned parameter;
    const char* name;
    const char* meaning;
    float x, y, size;
    unsigned color;
};
// Coordinates share the web panel's fixed 1200 × 750 coordinate system.
const Control controls[] = {
    {Tone, "DISK", "LJUSHET", 54, 421, 68, 0xeac4b8},
    {Bite, "MARMORERING", "FM", 179, 421, 68, 0xd88d83},
    {Ratio, "STYCKNING", "ÖVERTONER", 304, 421, 68, 0xe9b18e},
    {Attack, "ANSATS", "ANSATS", 429, 421, 68, 0xcfbd84},
    {Decay, "MÖRHET", "AVKLINGNING", 554, 421, 68, 0xcfbd84},
    {Sustain, "KROPP", "HÅLLNIVÅ", 679, 421, 68, 0xcfbd84},
    {Release, "VILA", "SLÄPP", 804, 421, 68, 0xcfbd84},
    {Volume, "VOLYM", "UTNIVÅ", 817, 285, 50, 0xe4d6ae},
    {Warmth, "FETT", "MÄTTNAD", 950, 285, 50, 0xd7ae7b},
    {Space, "SALUHALL", "RUM", 1083, 285, 50, 0xb5bfa4}
};
const float defaults[ParameterCount] = {
    .08f, .35f, .4f, 0, .25f, .3f, .18f, .45f, 0, .65f, .65f, .2f, 0, 0
};
struct Performance {
    unsigned parameter;
    const char* name;
    const char* meaning;
    float x, y, width, height;
};
// Invisible hit regions follow the existing steak, roast and sausage artwork.
const Performance performances[] = {
    {Tender, "MÖRA", "EXTRA BETT", 102, 207, 231, 112},
    {Bone, "BEN", "METALLANSLAG", 439, 205, 187, 112},
    {Grind, "KVARNA", "RYTMISK MALNING", 335, 211, 96, 100}
};
int performanceHover(int index) { return index ? 11 + index : 10; }
const int whites[] = {0,2,4,5,7,9,11,12,14,16,17,19,21,23};
const unsigned computerKeys[] = {
    'a','w','s','e','d','f','t','g','y','h','u','j','k','o','l','p',
    ';','\'',']','\\','z','x','c','v'
};
float limit(float v) { return std::max(0.f, std::min(1.f, v)); }
bool inside(float x, float y, float bx, float by, float w, float h)
{ return x >= bx && y >= by && x < bx+w && y < by+h; }
Color ink(unsigned c, float alpha = 1.f)
{ return Color(int(c >> 16 & 255), int(c >> 8 & 255), int(c & 255), alpha); }
}

class KottdiskUI final : public UI {
public:
    KottdiskUI() : UI(1200, 750), drag(-1), hover(-1), mouseNote(-1),
        dragX(0), dragY(0), dragValue(0), mousePlaying(false),
        mousePerformance(-1), mouseDepth(1), menu(false)
    {
        std::copy(defaults, defaults+ParameterCount, values);
        std::memset(performanceKeys, 0, sizeof(performanceKeys));
        std::memset(keyDown, 0, sizeof(keyDown));
        std::memset(noteUsers, 0, sizeof(noteUsers));
        std::memset(latched, 0, sizeof(latched));
        loadSharedResources();
    }

    ~KottdiskUI() override { releaseOwnedNotesAndGestures(); }

protected:
    void parameterChanged(uint32_t index, float value) override
    {
        if (index >= ParameterCount || !std::isfinite(value)) return;
        values[index] = limit(value);
        if (index == Hold && value < .5f) std::memset(latched, 0, sizeof(latched));
        repaint();
    }

    void uiFocus(bool focused, DGL_NAMESPACE::CrossingMode) override
    { if (!focused) releaseOwnedNotesAndGestures(); }

    bool onMouse(const MouseEvent& ev) override
    {
        if (ev.button != 1) return false;
        const float x = ev.pos.getX(), y = ev.pos.getY();
        if (!ev.press) {
            bool used = drag >= 0 || mousePlaying || mousePerformance >= 0;
            finishDrag();
            if (mouseNote >= 0) releaseNote(mouseNote);
            mouseNote = -1; mousePlaying = false;
            if (mousePerformance >= 0) {
                const int previous = mousePerformance; mousePerformance = -1;
                syncPerformance(previous, true);
            }
            repaint();
            return used;
        }
        if (inside(x,y,1100,25,50,50)) {
            releaseOwnedNotesAndGestures(); menu = !menu; repaint(); return true;
        }
        if (menu) {
            if (inside(x,y,850,100,300,55)) panic();
            menu = false; repaint(); return true;
        }
        const int control = controlAt(x,y);
        if (control >= 0) {
            drag = control; hover = control;
            dragX = x; dragY = y; dragValue = values[controls[drag].parameter];
            editParameter(controls[drag].parameter, true);
            repaint(); return true;
        }
        const int performance = inside(x,y,925,400,250,150) ? 0 : performanceAt(x,y);
        if (performance >= 0) {
            const bool wasActive = performanceOwned(performance);
            mousePerformance = performance; mouseDepth = 1;
            hover = performanceHover(performance); syncPerformance(performance, wasActive);
            return true;
        }
        if (inside(x,y,1050,575,125,150)) {
            hover = 11; editParameter(Hold,true);
            change(Hold, values[Hold] >= .5f ? 0 : 1); editParameter(Hold,false);
            return true;
        }
        mouseNote = noteAt(x,y);
        if (mouseNote >= 0) { mousePlaying = true; pressNote(mouseNote); return true; }
        return false;
    }

    bool onMotion(const MotionEvent& ev) override
    {
        const float x = ev.pos.getX(), y = ev.pos.getY();
        if (drag >= 0) {
            const float scale = ev.mod & DGL_NAMESPACE::kModifierShift ? 1600.f : 200.f;
            dragValue = limit(dragValue + (dragY-y + .4f*(x-dragX))/scale);
            dragX = x; dragY = y; change(controls[drag].parameter, dragValue);
            return true;
        }
        if (mousePerformance >= 0) {
            if (mousePerformance > 0) {
                const Performance& p = performances[mousePerformance];
                mouseDepth = std::max(.08f, limit(1 - (y - (p.y + p.height / 2)) / p.height));
                syncPerformance(mousePerformance, true);
            }
            return true;
        }
        if (mousePlaying) {
            const int next = noteAt(x,y);
            if (next != mouseNote) {
                if (mouseNote >= 0) releaseNote(mouseNote);
                mouseNote = next;
                if (next >= 0) pressNote(next);
            }
            return true;
        }
        int next = controlAt(x,y);
        const int performance = performanceAt(x,y);
        if (performance >= 0) next = performanceHover(performance);
        if (inside(x,y,925,400,250,150)) next = 10;
        else if (inside(x,y,1050,575,125,150)) next = 11;
        if (hover != next) { hover = next; repaint(); }
        return false;
    }

    bool onScroll(const ScrollEvent& ev) override
    {
        const int c = controlAt(ev.pos.getX(), ev.pos.getY());
        if (c < 0 || menu) return false;
        hover = c; const unsigned p = controls[c].parameter;
        editParameter(p,true);
        change(p, values[p] + float(ev.delta.getY()) *
            (ev.mod & DGL_NAMESPACE::kModifierShift ? .001f : .01f));
        editParameter(p,false); return true;
    }

    bool onKeyboard(const KeyboardEvent& ev) override
    {
        if (ev.key == DGL_NAMESPACE::kKeyEscape) {
            if (ev.press) { panic(); menu = false; repaint(); }
            return true;
        }
        const int performance = ev.key == ' ' ? 0 : ev.key == '1' ? 1 : ev.key == '2' ? 2 : -1;
        if (performance >= 0) {
            if (ev.press && (menu || (ev.mod & (DGL_NAMESPACE::kModifierControl |
                DGL_NAMESPACE::kModifierAlt | DGL_NAMESPACE::kModifierSuper)))) return false;
            // Releases always count, even after modifiers or the menu change.
            if (performanceKeys[performance] != ev.press) {
                const bool wasActive = performanceOwned(performance);
                performanceKeys[performance] = ev.press;
                hover = performanceHover(performance); syncPerformance(performance, wasActive);
            }
            return true;
        }
        for (int i=0; i<24; ++i) {
            if (ev.key != computerKeys[i]) continue;
            // Always accept releases, including when the modifier changed while playing.
            if (ev.press && (ev.mod & (DGL_NAMESPACE::kModifierControl |
                DGL_NAMESPACE::kModifierAlt | DGL_NAMESPACE::kModifierSuper))) return false;
            if (menu && ev.press) return false;
            if (keyDown[i] != ev.press) {
                keyDown[i] = ev.press;
                if (ev.press) pressNote(i); else releaseNote(i);
            }
            return true;
        }
        return false;
    }

    void onNanoDisplay() override
    {
        fontFace(NANOVG_DEJAVU_SANS_TTF);
        fillPaint(linearGradient(0,0,1200,750,ink(0x793542),ink(0x571e2b)));
        beginPath(); rect(0,0,1200,750); fill();
        outline(0.5f,.5f,1199,749,0xb37a6b);
        outline(9.5f,9.5f,1181,731,0x9e6656);
        for (int i=0;i<4;++i) {
            const float x = i%2 ? 1179 : 21, y = i/2 ? 729 : 21;
            disk(x,y,4,0xcaa371); line(x-2,y+1,x+2,y-1,0x624832,1);
        }
        label(50,62,"KÖTTDISK",48,0xfae9c3);
        outline(381,30,134,43,0xd3ad72); label(448,52,"3000",29,0xfae9c3,ALIGN_CENTER);
        label(52,96,"KÖTTETS LUSTAR     —     PASTOR GREGORIUS",9,0xddbc95);
        beginPath(); circle(1012,62,37); strokeColor(ink(0xc99867)); strokeWidth(1); stroke();
        label(1012,43,"UTVALT",7,0xd5b181,ALIGN_CENTER);
        label(1012,65,"K",29,0xd5b181,ALIGN_CENTER);
        label(1012,85,"SEDAN NYSS",6,0xd5b181,ALIGN_CENTER);
        disk(1125,50,25,0x552330); ring(1125,50,24,0xbf9362);
        for (int i=0;i<8;++i) {
            const float a=i*3.14159265f/4;
            line(1125+std::cos(a)*10,50+std::sin(a)*10,
                 1125+std::cos(a)*15,50+std::sin(a)*15,0xedd9ae,3);
        }
        ring(1125,50,7,0xedd9ae);
        drawCounter(); drawScale();
        box(25,400,875,150,0x6d2b38); line(25,400,900,400,0xbe8c69);
        line(400,415,400,525,0x956350);
        for (const Control& control : controls) drawKnob(control);
        drawTender(); drawKeyboard(); drawHold();
        label(50,738,"KG / 003 — KÖTTETS LUSTAR",6,0xc69a79);
        if (menu) {
            box(850,100,300,55,0xefe2c3); outline(850,100,300,55,0xbd996b);
            label(1000,127,"SLÄPP ALLA TONER",12,0x652636,ALIGN_CENTER);
        }
    }

private:
    float values[ParameterCount];
    int drag, hover, mouseNote;
    float dragX, dragY, dragValue;
    bool mousePlaying;
    int mousePerformance;
    float mouseDepth;
    bool menu, performanceKeys[3];
    bool keyDown[24], latched[24];
    unsigned noteUsers[24];

    void change(unsigned parameter, float value)
    {
        values[parameter] = limit(value);
        if (parameter == Hold && value < .5f) std::memset(latched,0,sizeof(latched));
        setParameterValue(parameter,values[parameter]); repaint();
    }
    void finishDrag()
    { if (drag >= 0) { editParameter(controls[drag].parameter,false); drag = -1; } }
    void pressNote(int note)
    {
        if (noteUsers[note]++ == 0) { sendNote(0,uint8_t(48+note),106); latched[note] = false; }
        repaint();
    }
    void releaseNote(int note)
    {
        if (noteUsers[note] && --noteUsers[note] == 0) {
            sendNote(0,uint8_t(48+note),0); latched[note] = values[Hold] >= .5f;
        }
        repaint();
    }
    bool performanceOwned(int index) const
    { return performanceKeys[index] || mousePerformance == index; }
    void syncPerformance(int index, bool wasActive)
    {
        const bool active = performanceOwned(index);
        const unsigned parameter = performances[index].parameter;
        if (active && !wasActive) editParameter(parameter, true);
        change(parameter, performanceKeys[index] ? 1 : mousePerformance == index ? mouseDepth : 0);
        if (!active && wasActive) editParameter(parameter, false);
    }
    void releasePerformances(bool all = false)
    {
        for (int i=0; i<3; ++i) {
            const bool owned = performanceOwned(i);
            performanceKeys[i] = false;
            if (mousePerformance == i) mousePerformance = -1;
            if (owned) syncPerformance(i, true);
            else if (all && values[performances[i].parameter] > 0) {
                editParameter(performances[i].parameter, true);
                change(performances[i].parameter, 0);
                editParameter(performances[i].parameter, false);
            }
        }
    }
    void releaseOwnedNotesAndGestures()
    {
        finishDrag();
        for (int i=0;i<24;++i) {
            if (!noteUsers[i]) continue;
            sendNote(0,uint8_t(48+i),0);
            // Host sustain/automation remains owned by the host on focus loss.
            latched[i] = values[Hold] >= .5f;
        }
        std::memset(keyDown,0,sizeof(keyDown));
        std::memset(noteUsers,0,sizeof(noteUsers));
        releasePerformances(); mousePlaying = false;
        mouseNote = -1; hover = -1;
        repaint();
    }
    void panic()
    {
        finishDrag();
        // Reset hold first so note-offs cannot leave notes sustained in the Pd engine.
        if (values[Hold] >= .5f) { editParameter(Hold,true); change(Hold,0); editParameter(Hold,false); }
        for (int i=0;i<24;++i) if (noteUsers[i] || latched[i]) sendNote(0,uint8_t(48+i),0);
        std::memset(keyDown,0,sizeof(keyDown)); std::memset(noteUsers,0,sizeof(noteUsers));
        std::memset(latched,0,sizeof(latched));
        releasePerformances(true); mousePlaying = false; mouseNote = -1; hover = -1;
        repaint();
    }
    int performanceAt(float x, float y) const
    {
        for (int i=0; i<3; ++i) {
            const Performance& p = performances[i];
            if (inside(x,y,p.x,p.y,p.width,p.height)) return i;
        }
        return -1;
    }
    int controlAt(float x,float y) const
    {
        for (int i=0;i<10;++i) { const Control& c=controls[i];
            if (inside(x,y,c.x-9,c.y-9,c.size+18,c.size+37)) return i;
        }
        return -1;
    }
    int noteAt(float x,float y) const
    {
        if (!inside(x,y,35,575,980,132)) return -1;
        if (y < 658) for (int n=1;n<24;++n) {
            if (isWhite(n)) continue;
            int before=0; while (before<14 && whites[before]<n) ++before;
            if (inside(x,y,35+before*70-21,575,42,83)) return n;
        }
        return whites[std::min(13,int((x-35)/70))];
    }
    static bool isWhite(int note)
    { return std::find(whites,whites+14,note) != whites+14; }
    void box(float x,float y,float w,float h,unsigned c)
    { beginPath(); rect(x,y,w,h); fillColor(ink(c)); fill(); }
    void outline(float x,float y,float w,float h,unsigned c)
    { beginPath(); rect(x,y,w,h); strokeColor(ink(c)); strokeWidth(1); stroke(); }
    void disk(float x,float y,float r,unsigned c)
    { beginPath(); circle(x,y,r); fillColor(ink(c)); fill(); }
    void ring(float x,float y,float r,unsigned c)
    { beginPath(); circle(x,y,r); strokeColor(ink(c)); strokeWidth(1); stroke(); }
    void line(float x,float y,float ex,float ey,unsigned c,float width=1)
    { beginPath(); moveTo(x,y); lineTo(ex,ey); strokeColor(ink(c)); strokeWidth(width); stroke(); }
    void label(float x,float y,const char* s,float size,unsigned c,int align=ALIGN_LEFT)
    { fontSize(size); textAlign(align|ALIGN_MIDDLE); fillColor(ink(c)); text(x,y,s,nullptr); }

    void drawKnob(const Control& c)
    {
        const float x=c.x, y=c.y, s=c.size, cx=x+s/2, cy=y+s/2;
        box(x,y+3,s,s,0x2a1720); box(x,y,s,s,s==50?0x7f705b:0x3d2930);
        outline(x,y,s,s,0x342025); ring(cx,cy,s/2-7,0x967557);
        disk(cx,cy,s/2-12,c.color); ring(cx,cy,s/2-12,0xebd1a4);
        ring(cx,cy,s/2-18,0xb48d72);
        const float angle=(-225+values[c.parameter]*270)*3.14159265f/180;
        line(cx+std::cos(angle)*(s/2-24),cy+std::sin(angle)*(s/2-24),
             cx+std::cos(angle)*(s/2-15),cy+std::sin(angle)*(s/2-15),0x592d34,3);
        disk(cx,y+3,1.5f,0xdfc196);
        label(cx,y+s+(s==50?18:22),c.name,s==50?8:9,s==50?0x5d4b36:0xebd4b2,ALIGN_CENTER);
        if (s!=50) line(cx-25,y+s+34,cx+25,y+s+34,c.color);
    }

    void drawScale()
    {
        box(775,129,400,250,0x361d23); box(775,125,400,250,0xe3d7b8);
        outline(775,125,400,250,0xb09a75); outline(780,130,390,240,0xb9a780);
        label(975,146,"LUSTVÅG  3000",11,0x563d2a,ALIGN_CENTER);
        box(800,160,350,115,0x3d4336); box(806,166,338,103,0xabb692);
        for (int y=168;y<269;y+=3) line(806,float(y),1144,float(y),0xa6b18d);
        unsigned p=0; const char* name="KÖTTETS LUSTAR"; const char* meaning="";
        if (hover>=0 && hover<10) { p=controls[hover].parameter; name=controls[hover].name; meaning=controls[hover].meaning; }
        else if (hover==10) { p=Tender; name="MÖRA"; meaning="EXTRA BETT"; }
        else if (hover==11) { p=Hold; name="LÅT VILA"; meaning="HÅLL TONER"; }
        else if (hover==12 || hover==13) {
            const Performance& performance = performances[hover-11];
            p=performance.parameter; name=performance.name; meaning=performance.meaning;
        }
        char description[120], reading[20];
        if (hover>=0) {
            std::snprintf(description,sizeof(description),"%s · %s",name,meaning);
            std::snprintf(reading,sizeof(reading),"%d",int(values[p]*100+.5f));
        } else { std::snprintf(description,sizeof(description),"%s",name); std::strcpy(reading,"3000"); }
        label(818,181,description,10,0x2a422d);
        label(1098,218,reading,48,0x2a422d,ALIGN_RIGHT);
        label(1123,231,hover>=0?"%":"FM",12,0x2a422d,ALIGN_CENTER);
        line(818,246,1132,246,0x7e916b);
        int voices=0; for (int i=0;i<24;++i) if (noteUsers[i] || latched[i]) ++voices;
        for (int i=0;i<6;++i) box(819+i*13,254,8,4,i<voices?0x304c2e:0x8e9f7b);
        label(1130,256,values[Hold]>=.5f?"LÅT VILA":"UTVALT FÖR HAND",7,0x2a422d,ALIGN_RIGHT);
    }

    void drawCounter()
    {
        box(25,129,725,250,0x311823); box(25,125,725,250,0xe6dec8);
        outline(25,125,725,250,0xcda36a);
        // Chipped ice under enamel trays; deterministic shapes keep repainting still.
        for (int row=0;row<5;++row) for (int col=0;col<14;++col) {
            const float x=25+col*57+(row%2)*14,y=164+row*39;
            beginPath(); moveTo(x,y); lineTo(x+19,y-9); lineTo(x+43,y+2);
            lineTo(x+34,y+24); lineTo(x+4,y+25); closePath();
            fillColor(ink(0xd7dbce)); fill(); strokeColor(ink(0xf9f5df)); strokeWidth(1); stroke();
        }
        beginPath(); moveTo(47,338); lineTo(138,200); lineTo(379,212); lineTo(424,351); closePath();
        fillColor(ink(0xb2b6a7)); fill();
        beginPath(); moveTo(58,332); lineTo(144,210); lineTo(368,221); lineTo(411,341); closePath();
        fillColor(ink(0xe8e8d8)); fill();
        beginPath(); moveTo(383,353); lineTo(402,217); lineTo(691,219); lineTo(725,353); closePath();
        fillColor(ink(0xb2b6a7)); fill();
        beginPath(); moveTo(395,343); lineTo(410,230); lineTo(682,230); lineTo(711,343); closePath();
        fillColor(ink(0xe8e8d8)); fill();
        // Bone-in cut, marbling and a tied roast, drawn directly as native paths.
        save(); translate(25,150);
        beginPath(); moveTo(79,127); bezierTo(78,96,115,69,154,69);
        bezierTo(178,68,192,49,217,57); bezierTo(244,65,242,83,267,89);
        bezierTo(294,95,317,110,314,135); bezierTo(311,164,289,173,259,168);
        bezierTo(232,164,220,186,179,182); bezierTo(147,179,143,164,118,165);
        bezierTo(91,167,80,155,79,127); closePath();
        fillColor(ink(0xf3ccac)); fill(); strokeColor(ink(0x782c36)); strokeWidth(3); stroke();
        save(); translate(18,12); scale(.88f,.83f);
        beginPath(); moveTo(79,127); bezierTo(78,96,115,69,154,69);
        bezierTo(178,68,192,49,217,57); bezierTo(244,65,242,83,267,89);
        bezierTo(294,95,317,110,314,135); bezierTo(311,164,289,173,259,168);
        bezierTo(232,164,220,186,179,182); bezierTo(147,179,143,164,118,165);
        bezierTo(91,167,80,155,79,127); closePath(); fillColor(ink(0xb44d55)); fill(); restore();
        line(179,84,184,116,0xf3c8b0,4); line(184,116,153,148,0xf3c8b0,4);
        line(184,116,227,126,0xf3c8b0,4); line(227,126,242,155,0xf3c8b0,4);
        line(184,116,207,81,0xf3c8b0,4); line(148,111,114,122,0xf3c8b0,4);
        line(244,104,227,126,0xf3c8b0,4); line(227,126,280,132,0xf3c8b0,4);
        disk(182,117,11,0xfff0d0); disk(192,124,9,0xfff0d0); disk(180,132,8,0xfff0d0);
        save(); translate(512,110); rotate(.21f);
        beginPath(); ellipse(0,0,98,52); fillColor(ink(0xd78b80)); fill();
        strokeColor(ink(0xf2c8ae)); strokeWidth(8); stroke();
        beginPath(); ellipse(0,0,84,37); fillColor(ink(0xa8424e)); fill();
        for (int i=-60;i<=60;i+=30) {
            beginPath(); moveTo(float(i),-43); bezierTo(float(i-10),-20,float(i-10),22,float(i),43);
            strokeColor(ink(0xfff0c7)); strokeWidth(3); stroke();
        }
        line(-70,18,70,18,0xfff0c7,2); line(-65,-7,-25,8,0xefb9a7,3);
        line(0,-20,16,6,0xefb9a7,3); line(16,6,59,15,0xefb9a7,3); restore();
        beginPath(); moveTo(329,71); bezierTo(305,144,366,177,380,133);
        bezierTo(381,115,388,92,399,85); strokeColor(ink(0x7c3038)); strokeWidth(28); stroke();
        strokeColor(ink(0xcc7668)); strokeWidth(22); stroke();
        line(331,110,350,115,0xf0b695,3); line(355,139,371,140,0xf0b695,3);
        line(328,58,331,45,0xb58f56,2); line(397,74,406,65,0xb58f56,2);
        restore();
        // Glass reflections and the paper price tickets.
        beginPath(); moveTo(60,150); lineTo(166,352); lineTo(185,352); lineTo(79,150); closePath();
        fillColor(ink(0xfffdf0,.18f)); fill();
        save(); translate(59,314); rotate(-.12f); box(0,0,99,35,0xfff3d4);
        outline(0,0,99,35,0xab855b); label(50,19,"MÖRT",17,0x692c35,ALIGN_CENTER); restore();
        save(); translate(566,323); rotate(.08f); box(0,0,132,30,0xfff3d4);
        outline(0,0,132,30,0xab855b); label(66,16,"GOTT OM FETT",11,0x692c35,ALIGN_CENTER); restore();
        box(26,126,723,24,0xd3ae6e); line(26,150,749,150,0x97723f);
        label(130,138,"FÄRSKT AV EGEN VILJA",9,0x513e2c);
        line(345,138,465,138,0x987444); label(575,138,"VÄL HÄNGT",9,0x513e2c);
        box(26,352,723,22,0xc6aa81);
        label(50,364,"6 RÖSTER",8,0x5a4434); label(387,364,"4 OPERATÖRER",8,0x5a4434,ALIGN_CENTER);
        label(724,364,"INGA BEN",8,0x5a4434,ALIGN_RIGHT);
        for (int i=0; i<3; ++i) {
            const Performance& p = performances[i];
            const bool pressed = values[p.parameter] > 0;
            if (!pressed && hover != performanceHover(i)) continue;
            beginPath(); ellipse(p.x+p.width/2,p.y+p.height/2,p.width/2,p.height/2);
            fillColor(ink(0xffe9bd,pressed?.12f:.035f)); fill();
            strokeColor(ink(0xffe9bd,pressed?.65f:.35f)); strokeWidth(pressed?2:1); stroke();
        }
    }

    void drawTender()
    {
        const bool pressed=values[Tender]>=.5f;
        box(925,400,250,150,pressed?0x753142:0x4a202c); outline(925,400,250,150,0xc18b68);
        label(945,432,"MÖRA",25,0xf3e3bb); label(945,456,"FÖR HAND",7,0xc9a784);
        line(980,484,980,512,0xbe906c,2); line(974,506,980,512,0xbe906c,2); line(986,506,980,512,0xbe906c,2);
        box(1077,424,22,103,0x291b21); outline(1077,424,22,103,0xac7c57);
        box(1082,pressed?491:440,11,pressed?30:76,0xd9be8c);
        save(); translate(1087,pressed?503:445); rotate(pressed?.17f:-.21f);
        box(-38,-17,75,34,pressed?0xf4c489:0xd6a48e); outline(-38,-17,75,34,0xefbea2);
        for (int x=-8;x<=8;x+=8) line(float(x),-10,float(x),10,0x995e50);
        restore();
    }

    void drawKeyboard()
    {
        box(25,575,1000,150,0x311b22); outline(25,575,1000,150,0xc0956a);
        for (int i=0;i<14;++i) {
            const bool pressed=noteUsers[whites[i]] || latched[whites[i]];
            const float x=35+i*70;
            box(x,576,70,131,pressed?0xd59c86:0xf0deba);
            box(x+1,701,68,6,pressed?0x9c695a:0xc6a87a); outline(x,576,70,131,0x765c49);
        }
        for (int n=0;n<24;++n) {
            if (isWhite(n)) continue;
            int before=0; while (before<14 && whites[before]<n) ++before;
            const float x=35+before*70-21; const bool pressed=noteUsers[n] || latched[n];
            box(x,576,42,82,pressed?0xab7060:0x3d2528);
            box(x+3,579,36,73,pressed?0xab7060:0x563931); outline(x,576,42,82,0x20161c);
        }
        label(47,718,"C",7,0xbf996e);
        label(1005,718,"PASTOR GREGORIUS",7,0xba9677,ALIGN_RIGHT);
    }

    void drawHold()
    {
        const bool held=values[Hold]>=.5f;
        box(1050,575,125,150,0x4b232d); outline(1050,575,125,150,0xc0956a);
        label(1112,598,"LÅT VILA",11,0xf3e3bb,ALIGN_CENTER);
        box(1085,620,55,65,0x30242a); outline(1085,620,55,65,0xb5956a);
        box(1092,held?631:626,39,48,0xbea074); outline(1092,held?631:626,39,48,0xf5d2a0);
        disk(1112,held?636:632,2.5f,held?0xe3b355:0x886946);
        line(1097,held?669:664,1126,held?669:664,0xa0845c,2);
        label(1112,708,"HÅLL TONER",7,0xcfad88,ALIGN_CENTER);
    }

    DISTRHO_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(KottdiskUI)
};

UI* createUI() { return new KottdiskUI(); }
END_NAMESPACE_DISTRHO
