import createKottdiskModule from './kottdisk-engine.js';

if(!globalThis.atob)globalThis.atob=input=>{
  const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let bits=0,value=0,output='';
  for(const char of input.replace(/=+$/,'')){
    const digit=chars.indexOf(char);if(digit<0)continue;
    value=(value<<6)|digit;bits+=6;
    if(bits>=8){bits-=8;output+=String.fromCharCode((value>>bits)&255);}
  }
  return output;
};
const names=['kd_attack','kd_bite','kd_decay','kd_hold','kd_ratio','kd_release',
  'kd_space','kd_sustain','kd_tender','kd_tone','kd_volume','kd_warmth','zz_kd_bone','zz_kd_grind'];

class KottdiskProcessor extends AudioWorkletProcessor {
  constructor(){
    super();this.module=null;this.failed=false;this.disposed=false;
    this.params=new Map();this.events=[];this.transport=null;this.frames=0;this.reportAt=0;this.peak=0;
    this.port.onmessage=({data})=>this.message(data);
    Promise.resolve().then(()=>createKottdiskModule({printErr:message=>this.port.postMessage({type:'diagnostic',message})})).then(module=>{
      this.module=module;this.context=module._kd_new(sampleRate);
      if(!this.context)throw new Error('Kunde inte skapa PlugData-motorn.');
      this.capacity=8192;this.buffer=module._malloc(this.capacity*2*4);
      if(!this.buffer)throw new Error('Ljudmotorn saknar buffertminne.');
      this.offset=this.buffer>>>2;
      this.port.postMessage({type:'ready',sampleRate,engine:'PlugData/hvcc',wasm:true,parameters:names.length});
    }).catch(error=>this.error(error));
  }
  error(error){
    if(this.failed)return;this.failed=true;
    this.port.postMessage({type:'error',message:String(error)});
  }
  message(data){
    if(!data || this.disposed)return;
    if(data.type==='param'){
      const index=names.indexOf(data.name);
      if(index>=0 && Number.isFinite(data.value))this.params.set(index,Math.max(0,Math.min(1,data.value)));
    }else if(data.type==='midi' && data.bytes?.length>=3){
      if(this.events.length>=2048){this.events=[];this.panicPending=true;}
      this.events.push(data.bytes.slice(0,3));
    }else if(data.type==='transport')this.transport=data;
    else if(data.type==='panic'){this.events=[];this.panicPending=true;}
    else if(data.type==='dispose'){
      if(this.context)this.module._kd_free(this.context);
      if(this.buffer)this.module._free(this.buffer);
      this.context=0;this.disposed=true;
    }
  }
  process(inputs,outputs){
    if(this.disposed)return false;
    const channels=outputs[0],frames=channels[0]?.length || 0;
    if(!this.context || this.failed || !frames)return true;
    try{
      if(frames>this.capacity)throw new Error('Ljudblockets storlek stöds inte.');
      const m=this.module;
      // Collapse pointer traffic before entering Heavy, including while suspended.
      for(const [index,value] of this.params)m._kd_param(this.context,index,value);
      this.params.clear();
      if(this.transport){m._kd_transport(this.context,this.transport.bpm||120,this.transport.playing?1:0);this.transport=null;}
      if(this.panicPending){m._kd_midi(this.context,0xb0,120,0);m._kd_midi(this.context,0xb8,120,0);this.panicPending=false;}
      const count=Math.min(64,this.events.length);
      for(let i=0;i<count;i++)m._kd_midi(this.context,...this.events[i]);
      if(count)this.events.splice(0,count);
      m._kd_process(this.context,this.buffer,frames);
      const heap=m.HEAPF32;
      for(let i=0;i<frames;i++)for(let ch=0;ch<channels.length;ch++){
        const value=heap[this.offset+i*2+(ch&1)];
        if(!Number.isFinite(value))throw new Error('Ljudmotorn gav ett ogiltigt sampel.');
        channels[ch][i]=value;this.peak=Math.max(this.peak,Math.abs(value));
      }
      this.frames+=frames;
      if(this.frames>=this.reportAt){
        this.reportAt=this.frames+sampleRate*2;
        this.port.postMessage({type:'health',frames:this.frames,peak:this.peak,queuedEvents:this.events.length});this.peak=0;
      }
    }catch(error){for(const channel of channels)channel.fill(0);this.error(error);}
    return true;
  }
}
registerProcessor('kottdisk',KottdiskProcessor);
