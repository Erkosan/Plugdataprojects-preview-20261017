"""Audible character and long-session regression against compiled Pd, no DSP mocks.

KOTTDISK_CHARACTER_LIB can select an isolated native build for audio development.
"""
import ctypes as C
import math
import os
from pathlib import Path
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PARAMS = ['attack','bite','decay','hold','ratio','release','space','sustain','tender','tone','volume','warmth','bone','grind']
LIB = C.CDLL(os.environ.get('KOTTDISK_CHARACTER_LIB', str(ROOT/'build/kottdisk/libkottdisk.so')))
LIB.kd_new.argtypes=[C.c_double]; LIB.kd_new.restype=C.c_void_p
LIB.kd_free.argtypes=[C.c_void_p]
LIB.kd_param.argtypes=[C.c_void_p,C.c_int,C.c_float]
LIB.kd_midi.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int]
LIB.kd_transport.argtypes=[C.c_void_p,C.c_double,C.c_int]
LIB.kd_process.argtypes=[C.c_void_p,C.POINTER(C.c_float),C.c_int]


def rms(a): return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))


class CharacterSynth:
    def __init__(self,sr=48000):
        self.sr=sr; self.p=LIB.kd_new(sr); self.audio(.03)
    def close(self):
        if self.p: LIB.kd_free(self.p); self.p=None
    def param(self,name,value): LIB.kd_param(self.p,PARAMS.index(name.removeprefix('zz_kd_').removeprefix('kd_')),value)
    def preset(self,values):
        for name,value in values.items(): self.param(name,value)
    def note(self,note,velocity=100,channel=1): LIB.kd_midi(self.p,0x90|channel-1,note,velocity)
    def cc(self,cc,value): LIB.kd_midi(self.p,0xb0,cc,value)
    def tempo(self,bpm,playing=1): LIB.kd_transport(self.p,bpm,playing)
    def audio(self,seconds):
        result=np.zeros((math.ceil(seconds*self.sr/128),128,2),np.float32)
        for block in result: LIB.kd_process(self.p,block.ctypes.data_as(C.POINTER(C.c_float)),128)
        return result.reshape(-1,2)


def spectrum(audio,sr=48000):
    mono=audio.mean(axis=1); power=np.abs(np.fft.rfft(mono*np.hanning(len(mono))))**2
    return np.fft.rfftfreq(len(mono),1/sr),power


class CharacterTests(unittest.TestCase):
    def make(self,**params):
        s=CharacterSynth();self.addCleanup(s.close);s.preset(params);return s
    def held(self,**params):
        s=self.make(space=0,sustain=.75,**params);s.note(48);s.audio(1.5);return s.audio(.4)
    def test_body_retains_upper_partials_after_transient(self):
        audio=self.held(bite=.65,ratio=.38)
        f,p=spectrum(audio)
        self.assertGreater(rms(audio),.035)
        self.assertGreater(float(p[f>400].sum()/p.sum()),.10)
    def test_cut_is_continuous_and_changes_nearby_settings(self):
        sounds=[self.held(bite=.65,ratio=value) for value in [.41,.43,.45]]
        for a,b in zip(sounds,sounds[1:]):self.assertGreater(rms(a-b),.015)
    def test_mora_reexcites_an_already_sustained_note(self):
        s=self.make(space=0,sustain=.6);s.note(48);s.audio(2)
        before=s.audio(.15);s.param('tender',1);hit=s.audio(.07)
        s.param('tender',0);s.audio(.4);settled=s.audio(.15)
        self.assertGreater(rms(hit),rms(before)*1.15)
        self.assertLess(abs(rms(before)-rms(settled)),rms(before)*.08)
    def test_bone_and_grinder_have_distinct_spectral_effects(self):
        base=self.held(bite=.35,ratio=.25)
        bone=self.held(bite=.35,ratio=.25,bone=1)
        grind=self.held(bite=.35,ratio=.25,grind=1)
        f,p=spectrum(base);_,pb=spectrum(bone);_,pg=spectrum(grind)
        self.assertGreater(float(pb[f>600].sum()/pb.sum()),float(p[f>600].sum()/p.sum())*1.3)
        self.assertGreater(rms(grind-base),.025)
        # Grinding changes the normalized spectral distribution as well as volume.
        self.assertGreater(float(np.abs(pg/pg.sum()-p/p.sum()).sum()),.15)
    def test_grinder_follows_host_tempo_and_render_is_repeatable(self):
        rates=[]
        renders=[]
        for bpm in [60,120,120]:
            s=self.make(space=0,sustain=.8,grind=1,bite=.4)
            s.tempo(bpm);s.note(60);s.audio(1.5);a=s.audio(2)
            size=256;mono=a[:len(a)//size*size,0].reshape(-1,size)
            envelope=np.sqrt(np.mean(mono**2,axis=1));envelope-=envelope.mean()
            f=np.fft.rfftfreq(len(envelope),size/s.sr)
            power=np.abs(np.fft.rfft(envelope*np.hanning(len(envelope))))**2
            power[(f<1)|(f>20)]=0
            rates.append(float(f[np.argmax(power)]));renders.append(a)
        self.assertAlmostEqual(rates[0],4,delta=.6)
        self.assertAlmostEqual(rates[1],8,delta=.6)
        np.testing.assert_array_equal(renders[1],renders[2])
    def test_gestures_remain_finite_at_sample_rate_and_pitch_extremes(self):
        for sr in [44100,48000,96000]:
            s=CharacterSynth(sr);self.addCleanup(s.close)
            s.preset({name:1 for name in PARAMS if name!='hold'})
            for n in [0,12,36,60,96,127]:s.note(n,127)
            a=s.audio(.8)
            self.assertTrue(np.isfinite(a).all());self.assertLessEqual(np.max(np.abs(a)),.981)
            s.cc(120,0);self.assertLess(rms(s.audio(.7)[-4800:]),1e-7)
    def test_counter_has_stereo_reflections_and_finite_tail(self):
        s=self.make(space=1,sustain=0,decay=.1,release=0)
        s.note(60);a=s.audio(.15);s.note(60,0);tail=s.audio(.5)
        self.assertGreater(rms(a[:,0]-a[:,1]),.001)
        self.assertGreater(rms(tail[:5000]),.0001)
        self.assertLess(rms(tail[-4800:]),1e-7)
    def test_repeated_automation_and_strikes_keep_playing_and_panic_clears(self):
        s=self.make()
        for step in range(240):
            # Every step completes an audio block; resembles sustained UI/host automation.
            for i,name in enumerate(['bite','ratio','tone','warmth','space','tender','bone','grind']):
                s.param(name,((step*(i+3))%101)/100)
            if step%12==0:s.note([48,51,55,58,60,63][step//12%6])
            a=s.audio(.016)
            self.assertTrue(np.isfinite(a).all());self.assertLessEqual(np.max(np.abs(a)),.981)
        s.cc(120,0);self.assertLess(rms(s.audio(.7)[-4800:]),1e-7)
        s.preset(dict(attack=.01,decay=.3,sustain=.6,bite=.4,tone=.7,volume=.65))
        s.note(60);self.assertGreater(rms(s.audio(.3)),.025)


if __name__=='__main__':unittest.main(verbosity=2)
