#!/usr/bin/env node
'use strict';
// Prolonged integration test: actual browser pointer input, AudioWorklet and WASM.
// Usage: node tests/run_kottdisk_stress.cjs [URL] --seconds 120 --sessions 2 --label final --cc-automation
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
let chromium;
try { ({chromium} = require('playwright-core')); }
catch { ({chromium} = require('/home/elias/node_modules/playwright-core')); }
const ROOT = path.resolve(__dirname, '..');
const DIST = path.join(ROOT, 'synths/Kottdisk/web/dist');
const REPORT = path.join(ROOT, 'docs/kottdisk/overhaul-stress.json');
const args = process.argv.slice(2);
const option = (key, fallback) => { const i = args.indexOf(key); return i < 0 ? fallback : args[i + 1]; };
const seconds = Number(option('--seconds', 120));
const sessions = Number(option('--sessions', 2));
const label = option('--label', 'final');
const mode = option('--mode', 'both');
const ccAutomation = args.includes('--cc-automation');
const target = args.find(a => /^https?:\/\//.test(a));
assert(Number.isFinite(seconds) && seconds >= 120 && seconds <= 900, '--seconds must be between 120 and 900 real seconds');
assert(Number.isInteger(sessions) && sessions >= 1 && sessions <= 4, '--sessions must be 1–4');
assert(['both','mixed','held'].includes(mode), '--mode must be both, mixed or held');
const knobs = ['kd_volume','kd_tone','kd_bite','kd_ratio','kd_attack','kd_decay','kd_sustain','kd_release','kd_warmth','kd_space'];
const audible = {kd_volume:.65,kd_tone:.65,kd_bite:.35,kd_ratio:.25,kd_attack:0,kd_decay:.2,kd_sustain:.7,kd_release:0,kd_warmth:.1,kd_space:0,kd_hold:0,kd_tender:0,zz_kd_bone:0,zz_kd_grind:0};
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
let server, browser, current;
const run = {label, started:new Date().toISOString(), engine:'Real compiled PlugData/hvcc/WASM; no DSP mocks', test_sha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),requested_seconds_per_session:seconds,cc_automation:ccAutomation, sessions:[], limitations:['Chromium/Linux; no claim of physical Safari/iOS/MIDI/DAW coverage.','RMS is required after restoring a known audible patch. Extreme envelopes and zero volume may legitimately be silent.']};
const mime = {'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
const watchdog = setTimeout(() => { run.fatal='Overall stress-test time limit exceeded'; void finish(1); }, (seconds * sessions + 120) * 1000);
watchdog.unref();
let finishing = false;
async function finish(code) {
  if (finishing) return;
  finishing = true;
  clearTimeout(watchdog);
  if (browser) await browser.close().catch(() => {});
  if (server) await new Promise(resolve => server.close(resolve));
  run.finished = new Date().toISOString();
  run.pass = !run.fatal && run.sessions.length === sessions && run.sessions.every(s => s.pass);
  let report = {instrument:'KÖTTDISK 3000', runs:[]};
  try { const existing = JSON.parse(fs.readFileSync(REPORT,'utf8')); if (Array.isArray(existing.runs)) report = existing; } catch {}
  report.runs.push(run);
  fs.mkdirSync(path.dirname(REPORT), {recursive:true});
  fs.writeFileSync(REPORT, JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({label,pass:run.pass,sessions:run.sessions.map(s=>({pass:s.pass,seconds:s.elapsed_seconds,cycles:s.cycles,probes:s.probes.length,errors:s.errors})),report:path.relative(ROOT,REPORT)}));
  process.exitCode = code || (run.pass ? 0 : 1);
}
async function geometry(page, selector) {
  const b = await page.locator(selector).boundingBox();
  assert(b, `${selector} has no pointer target`);
  return {x:b.x+b.width/2,y:b.y+b.height/2};
}
async function holdChord(page) {
  await page.locator('#instrument').click({position:{x:12,y:12}});
  for (const key of ['a','d','g']) await page.keyboard.down(key);
}
async function releaseChord(page) { for (const key of ['a','d','g']) await page.keyboard.up(key); }
async function measure(page, duration=350) {
  return page.evaluate(async duration => {
    const a=window.__stressAnalyser,data=new Float32Array(a.fftSize);
    let sum=0,count=0,peak=0,nonfinite=0;
    const end=performance.now()+duration;
    do { a.getFloatTimeDomainData(data); for(const v of data){ if(!Number.isFinite(v))nonfinite++; else{sum+=v*v;peak=Math.max(peak,Math.abs(v));}count++; } await new Promise(r=>setTimeout(r,15)); }while(performance.now()<end);
    const k=window.kottdisk,e=k.engine;
    return {rms:Math.sqrt(sum/count),peak,nonfinite,samples:count,context:e.context.state,engine:{healthy:e.healthy,status:e.status,error:e.error?.message||null,diagnostics:{...e.diagnostics},params:k.values,ready:k.ready}};
  },duration);
}
async function recovery(page, name) {
  await releaseChord(page);
  await page.evaluate(params=>{const k=window.kottdisk;k.panic();for(const [n,v]of Object.entries(params))k.update(n,v,{display:false});},audible);
  await holdChord(page);
  await wait(180);
  const a=await measure(page);
  current.probes.push({name,elapsed_seconds:(Date.now()-current.begin)/1000,...a});
  assert.equal(a.context,'running',`${name}: audio context stopped`);
  assert.equal(a.nonfinite,0,`${name}: non-finite audio`);
  assert(a.rms>.001,`${name}: restored audible patch is silent, RMS=${a.rms}`);
  assert(a.peak<=1.01,`${name}: clipped output, peak=${a.peak}`);
  return a;
}
async function drag(page,id,cycle) {
  const b=await geometry(page,'#'+id);
  const scale=await page.locator('#instrument').evaluate(el=>el.getBoundingClientRect().width/1200);
  await page.mouse.move(b.x,b.y);
  await page.mouse.down();
  // Cross both endpoints and all internal FM ratio boundaries on every sweep.
  // Input is dispatched by Chromium, including real pointer capture and hit testing.
  for(const delta of [240,-240,160,-160,0]) {
    await page.mouse.move(b.x+((cycle%2)?18:-18)*scale,b.y-delta*scale,{steps:8});
    const value=await page.evaluate(id=>window.kottdisk.values[id],id);
    const observed=current.parameter_extrema[id]||{min:Infinity,max:-Infinity};
    observed.min=Math.min(observed.min,value);observed.max=Math.max(observed.max,value);current.parameter_extrema[id]=observed;
  }
  await page.mouse.up();
  current.pointer_drags[id]=(current.pointer_drags[id]||0)+1;
}
async function denseUiBurst(page,client,cycle) {
  const id=knobs[cycle%knobs.length],b=await geometry(page,'#'+id);
  await page.mouse.move(b.x,b.y);await page.mouse.down();
  // CDP Input events are native browser input, not dispatched DOM events or direct engine calls.
  const events=[];
  for(let i=0;i<180;i++)events.push(client.send('Input.dispatchMouseEvent',{type:'mouseMoved',x:b.x+Math.sin(i*.7)*25,y:b.y+Math.cos(i*.37)*220,button:'none',buttons:1}));
  await Promise.all(events);await page.mouse.up();
  current.dense_native_moves+=180;
}
async function ccBurst(page,cycle) {
  const result=await page.evaluate(cycle=>{
    const k=window.kottdisk,controllers=[7,16,17,18,19,20,21,22,23,24,25,26,64],boundaries=[0,1,31,63,64,96,126,127];
    let mapped=0,raw=0;
    // Exercise the public host's MIDI-to-panel path, including channel 9.
    for(let round=0;round<16;round++)for(const cc of controllers){k.controlChange(cc,boundaries[round%boundaries.length],round%2?9:1);mapped++;}
    // Genuine raw MIDI through the worklet queue and WASM bridge. This burst is
    // intentionally larger than its 2048-event bound; the worklet must stay alive.
    for(let i=0;i<4096;i++){k.engine.controlChange(controllers[i%controllers.length],boundaries[(i+cycle)%boundaries.length],i%2?9:1);raw++;}
    return {mapped,raw,params:k.values,engine:{status:k.engine.status,healthy:k.engine.healthy,diagnostics:{...k.engine.diagnostics}}};
  },cycle);
  current.cc_bursts.push({cycle:cycle+1,...result});
}
async function twoTouch(page,client,cycle) {
  await releaseChord(page);
  const points=[];
  for(const [i,n]of [48,55].entries()){const b=await page.locator(`.key[data-note="${n}"]`).boundingBox();points.push({x:b.x+b.width/2,y:b.y+b.height*.82,id:i+1,radiusX:2,radiusY:2});}
  await client.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:points});await wait(70);
  const to=await page.locator(`.key[data-note="${cycle%2?52:50}"]`).boundingBox();
  points[0].x=to.x+to.width/2;
  await client.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:points});await wait(70);
  await client.send('Input.dispatchTouchEvent',{type:cycle%2?'touchCancel':'touchEnd',touchPoints:[]});
  current.multitouch_sequences++;
  await holdChord(page);
}
async function preset(page,cycle) {
  await releaseChord(page);await page.locator('#menu-open').click();
  const ids=await page.locator('#presets option').evaluateAll(els=>els.map(e=>e.value).filter(v=>v!=='custom'));
  const id=ids[cycle%ids.length];await page.selectOption('#presets',id);await page.locator('#menu-close').click();
  current.presets.push(id);await holdChord(page);
}
async function suspendResume(page) {
  await releaseChord(page);
  await page.evaluate(()=>window.kottdisk.engine.context.suspend());
  assert.equal(await page.evaluate(()=>window.kottdisk.engine.context.state),'suspended');
  await page.locator('.key[data-note="60"]').click();
  await page.waitForFunction(()=>window.kottdisk.engine.context.state==='running');
  current.suspend_resume++;
  await holdChord(page);
}
async function performancePads(page,client) {
  const selectors=await page.locator('[data-performance]').evaluateAll(els=>els.map(el=>'#'+el.id));
  for(const selector of selectors){
    const param=await page.locator(selector).getAttribute('data-performance');
    const p=await geometry(page,selector);
    await page.mouse.move(p.x,p.y);await page.mouse.down();
    await page.waitForFunction(n=>window.kottdisk.values[n]===1,param,{timeout:1000});
    assert.equal(await page.evaluate(n=>window.kottdisk.values[n],param),1,`${selector} native press did not engage`);
    await page.mouse.move(p.x,p.y+35,{steps:8});await page.mouse.up();
    await page.waitForFunction(n=>window.kottdisk.values[n]===0,param,{timeout:1000});
    assert.equal(await page.evaluate(n=>window.kottdisk.values[n],param),0,`${selector} failed to release`);
    current.performance_presses[param]=(current.performance_presses[param]||0)+1;
  }
  if(!current.uninterrupted&&selectors.includes('#play-bone')&&selectors.includes('#play-grind')){
    const points=[];
    for(const [id,selector]of ['#play-bone','#play-grind'].entries())points.push({...await geometry(page,selector),id:id+1,radiusX:2,radiusY:2});
    await client.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:points});
    await page.waitForFunction(()=>window.kottdisk.values.zz_kd_bone===1&&window.kottdisk.values.zz_kd_grind===1,null,{timeout:1000});
    const both=await page.evaluate(()=>[window.kottdisk.values.zz_kd_bone,window.kottdisk.values.zz_kd_grind]);assert.deepEqual(both,[1,1],'Simultaneous performance pads did not both engage');
    await client.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});
    // CDP can acknowledge dispatch before the renderer handles pointercancel.
    await page.waitForFunction(()=>window.kottdisk.values.zz_kd_bone===0&&window.kottdisk.values.zz_kd_grind===0,null,{timeout:1000});
    const released=await page.evaluate(()=>[window.kottdisk.values.zz_kd_bone,window.kottdisk.values.zz_kd_grind]);assert.deepEqual(released,[0,0],'Performance pads survived touch cancellation');
    current.performance_multitouch++;
  }
}
async function session(index) {
  const uninterrupted=mode==='held'||(mode==='both'&&index%2===0);
  current={index,uninterrupted,mode:uninterrupted?'continuous held chord without panic or preset resets':'mixed controls, presets, multitouch, sustain and context resume',begin:Date.now(),pass:false,probes:[],activity_samples:[],cc_bursts:[],pointer_drags:{},parameter_extrema:{},performance_presses:{},performance_multitouch:0,dense_native_moves:0,multitouch_sequences:0,suspend_resume:0,presets:[],cycles:0,errors:{page:[],console:[],requests:[],http:[],processor:[]}};
  run.sessions.push(current);
  const context=await browser.newContext({viewport:{width:1280,height:900},hasTouch:true,serviceWorkers:'block'});
  const page=await context.newPage();
  page.on('pageerror',e=>current.errors.page.push(e.message));
  page.on('console',m=>{if(m.type()==='error')current.errors.console.push(m.text());});
  page.on('requestfailed',r=>current.errors.requests.push({url:r.url(),error:r.failure()?.errorText}));
  page.on('response',r=>{if(r.status()>=400)current.errors.http.push({url:r.url(),status:r.status()});});
  await page.addInitScript(()=>{
    window.__stressMessages=[];window.__stressProcessorErrors=[];window.__stressMeters=[];
    const Native=window.AudioWorkletNode;
    window.AudioWorkletNode=class extends Native{
      constructor(...args){super(...args);const processor=args[1];this.addEventListener('processorerror',()=>window.__stressProcessorErrors.push({processor,time:performance.now()}));this.port.addEventListener('message',e=>{if(processor==='kottdisk'&&window.__stressMessages.length<10000)window.__stressMessages.push({time:performance.now(),data:e.data});});this.port.start();}
    };
  });
  let client;
  try {
    await page.goto(run.url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.kottdisk);
    assert.equal(await page.evaluate(()=>window.kottdisk.engine.context),null,'Audio eagerly initialized before gesture');
    await page.locator('.key[data-note="60"]').click();
    await page.waitForFunction(()=>window.kottdisk.ready&&window.kottdisk.engine.context?.state==='running');
    assert(await page.evaluate(()=>window.__stressMessages.some(m=>m.data.type==='ready'&&m.data.wasm===true&&m.data.engine==='PlugData/hvcc')),'Missing genuine WASM/AudioWorklet handshake');
    await page.evaluate(async()=>{
      const e=window.kottdisk.engine;
      window.__stressAnalyser=e.context.createAnalyser();window.__stressAnalyser.fftSize=4096;e.node.connect(window.__stressAnalyser);
      const code=`class Meter extends AudioWorkletProcessor{constructor(){super();this.last=[];this.reset();}reset(){this.frames=0;this.samples=0;this.sum=0;this.peak=0;this.bad=0;this.nonzero=0;this.identical=0;this.longest=0;this.streak=[];}process(inputs){const channels=inputs[0];if(channels?.[0]){this.frames+=channels[0].length;for(let ch=0;ch<channels.length;ch++)for(const v of channels[ch]){this.samples++;if(!Number.isFinite(v))this.bad++;else{this.sum+=v*v;this.peak=Math.max(this.peak,Math.abs(v));if(v!==0)this.nonzero++;if(v===this.last[ch]&&v!==0){this.identical++;this.streak[ch]=(this.streak[ch]||0)+1;this.longest=Math.max(this.longest,this.streak[ch]);}else this.streak[ch]=0;this.last[ch]=v;}}}if(this.frames>=sampleRate){this.port.postMessage({frames:this.frames,samples:this.samples,rms:Math.sqrt(this.sum/this.samples),peak:this.peak,nonfinite:this.bad,nonzero:this.nonzero,identical_nonzero:this.identical,longest_constant_nonzero:this.longest,audio_time:currentTime});this.reset();}return true;}}registerProcessor('stress-meter',Meter);`;
      const url=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));await e.context.audioWorklet.addModule(url);URL.revokeObjectURL(url);
      window.__stressMeter=new AudioWorkletNode(e.context,'stress-meter',{numberOfInputs:1,numberOfOutputs:0});window.__stressMeter.port.onmessage=ev=>window.__stressMeters.push(ev.data);e.node.connect(window.__stressMeter);
    });
    client=await context.newCDPSession(page);
    await recovery(page,'before activity');
    const start=Date.now();current.activity_started=new Date(start).toISOString();
    while(Date.now()-start<seconds*1000){
      const cycle=current.cycles;
      for(const id of knobs)await drag(page,id,cycle);
      await denseUiBurst(page,client,cycle);
      if(ccAutomation&&!uninterrupted)await ccBurst(page,cycle);
      await page.locator('#hold').click();
      if(!uninterrupted){await releaseChord(page);await wait(35);await holdChord(page);}
      const tender=await geometry(page,'#tender');await page.mouse.move(tender.x,tender.y);await page.mouse.down();await wait(45);await page.mouse.up();
      await page.locator('#hold').click();
      await performancePads(page,client);
      if(!uninterrupted){
        await twoTouch(page,client,cycle);
        await preset(page,cycle);
        if(cycle%2===0)await suspendResume(page);
        await recovery(page,`after cycle ${cycle+1}`);
      }else{
        // Restore controls without any MIDI note-off/on or panic. Envelope state,
        // voice allocation and the same physical held keyboard chord survive.
        await page.evaluate(params=>{for(const [n,v]of Object.entries(params))window.kottdisk.update(n,v,{display:false});},audible);
        assert.equal(await page.locator('.key.active').count(),3,'The uninterrupted chord lost a held key');
        const a=await measure(page,80);current.activity_samples.push({cycle:cycle+1,...a});
        assert.equal(a.context,'running','Continuous held-chord audio context stopped');
        assert.equal(a.nonfinite,0,'Continuous held-chord sample is non-finite');
      }
      current.cycles++;
      console.log(JSON.stringify({label,session:index,cycle:current.cycles,seconds:Math.round((Date.now()-start)/1000),rms:(uninterrupted?current.activity_samples:current.probes).at(-1).rms}));
    }
    current.activity_seconds=(Date.now()-start)/1000;
    await recovery(page,'after prolonged activity');
    await releaseChord(page);await page.evaluate(()=>window.kottdisk.panic());await wait(350);
    current.final_silence=await measure(page);
    assert(current.final_silence.rms<.0001,`Panic left audio RMS ${current.final_silence.rms}`);
    const data=await page.evaluate(()=>{const k=window.kottdisk,e=k.engine;return {messages:window.__stressMessages,meters:window.__stressMeters,processor:window.__stressProcessorErrors,state:e.context.state,sampleRate:e.context.sampleRate,engine:{healthy:e.healthy,status:e.status,error:e.error?.message||null,diagnostics:{...e.diagnostics},params:k.values,ready:k.ready}};});
    current.worklet=data.messages;current.continuous_audio=data.meters;current.errors.processor=data.processor;current.sample_rate=data.sampleRate;
    current.final_engine=data.engine;
    if(data.engine.status!==undefined){assert.equal(data.engine.status,'ready');assert.equal(data.engine.healthy,true);assert.equal(data.engine.error,null);}
    const total=data.meters.reduce((s,m)=>s+m.frames,0);
    current.measured_audio_seconds=total/data.sampleRate;
    assert(current.measured_audio_seconds>=seconds*.85,'Continuous audio capture did not cover enough real rendering time');
    assert(data.meters.every(m=>m.nonfinite===0&&m.peak<=1.01),'Continuous output contains non-finite or clipped samples');
    assert(data.meters.every(m=>m.longest_constant_nonzero<data.sampleRate*.1),'Audio became a constant nonzero sample stream');
    assert(data.messages.every(m=>!['error','diagnostic','recovery'].includes(m.data.type)),`Worklet emitted diagnostics: ${JSON.stringify(data.messages.filter(m=>m.data.type!=='ready'))}`);
    assert(data.messages.filter(m=>m.data.type==='health').every(m=>Number.isFinite(m.data.peak)&&m.data.queuedEvents<=2048),'Worklet health reported unbounded or invalid state');
    for(const [kind,items]of Object.entries(current.errors))assert.equal(items.length,0,`${kind}: ${JSON.stringify(items)}`);
    for(const id of knobs){assert(current.pointer_drags[id]>=2,`${id} did not receive repeated real pointer drags`);assert(current.parameter_extrema[id].min===0&&current.parameter_extrema[id].max===1,`${id} did not reach both endpoints through native input`);}
    if(!uninterrupted)assert(new Set(current.presets).size===6,'Not every factory preset was exercised');
    current.pass=true;
  }catch(error){
    current.failure=error.stack;
    try{const data=await page.evaluate(()=>({messages:window.__stressMessages,meters:window.__stressMeters,processor:window.__stressProcessorErrors,state:window.kottdisk?.engine.context?.state,values:window.kottdisk?.values}));current.worklet=data.messages;current.continuous_audio=data.meters;current.errors.processor=data.processor;current.failure_state=data;}catch{}
    console.error('FAIL',label,index,error.stack);
  }finally{
    current.elapsed_seconds=(Date.now()-current.begin)/1000;delete current.begin;
    if(client)await client.detach().catch(()=>{});await context.close();
  }
}
(async()=>{
  if(!target){
    run.artifacts={};for(const f of ['app.js','engine.js','worklet.js','kottdisk-engine.js'])run.artifacts[f]=crypto.createHash('sha256').update(fs.readFileSync(path.join(DIST,f))).digest('hex');
    server=http.createServer((request,response)=>{let file;try{file=path.resolve(DIST,'.'+decodeURIComponent(new URL(request.url,'http://localhost').pathname));}catch{response.writeHead(400).end();return;}if(file!==DIST&&!file.startsWith(DIST+path.sep)){response.writeHead(403).end();return;}if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');fs.readFile(file,(error,body)=>{if(error)response.writeHead(404).end();else response.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'}).end(body);});});
    await new Promise((resolve,reject)=>{server.on('error',reject);server.listen(0,'127.0.0.1',resolve);});
  }
  run.url=target||`http://127.0.0.1:${server.address().port}/`;
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  run.browser={version:browser.version(),headless:true,added_arguments:['--no-sandbox'],autoplay_bypass:false};
  for(let i=0;i<sessions;i++)await session(i+1);
})().catch(e=>{run.fatal=e.stack;console.error(e);}).finally(()=>finish());
