#!/usr/bin/env python3
"""Exercise the built KÖTTDISK VST3 in Pedalboard's real JUCE VST3 host.

Run with .venv/bin/python tests/run_kottdisk_vst3.py [path/to/Kottdisk.vst3].
Writes measured results to docs/kottdisk/vst3-tests.json. No GUI is opened.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import time
import traceback
import unicodedata
from unittest.mock import patch

import numpy as np
from mido import Message
import pedalboard
from pedalboard import load_plugin, VST3Plugin
from pedalboard._pedalboard import _PythonExternalPluginMixin

ROOT = Path(__file__).resolve().parents[1]
RATE = 48000
LABELS = {
    'attack': 'ANSATS', 'bite': 'MARMORERING', 'decay': 'MÖRHET',
    'hold': 'LÅT VILA', 'ratio': 'STYCKNING', 'release': 'VILA',
    'space': 'SALUHALL', 'sustain': 'KROPP', 'tender': 'MÖRA',
    'tone': 'DISK', 'volume': 'VOLYM', 'warmth': 'FETT', 'bone': 'BEN', 'grind': 'KVARNA',
}
DEFAULTS = dict(zip(LABELS, [.08, .35, .4, 0, .25, .3, .18, .45, 0, .65, .65, .2, 0, 0]))


def normalized(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode().lower()
    return ''.join(c for c in text if c.isalnum())


def host_parameters(plugin):
    # DPF exposes thousands of synthetic MIDI controllers. Pedalboard's public
    # .parameters guesses each one's units by probing 1000 values, which is
    # unnecessary for our declared normalized controls. Use the same JUCE-hosted
    # parameter objects directly and select only our twelve names.
    return {parameter.name: parameter for parameter in plugin._parameters}


def rms(audio):
    return float(np.sqrt(np.mean(np.asarray(audio, dtype=np.float64) ** 2)))


def note(number=60, velocity=100, channel=0, at=.04):
    return Message('note_on', note=number, velocity=velocity, channel=channel, time=at)


def off(number=60, channel=0, at=.4):
    return Message('note_off', note=number, velocity=0, channel=channel, time=at)


def cc(number, value, channel=0, at=0):
    return Message('control_change', control=number, value=value, channel=channel, time=at)


class HostTests:
    def __init__(self, path):
        self.path = str(path)
        self.keys = {}
        self.results = []

    def fresh(self, **parameters):
        # Suppress only Pedalboard's Python unit-guessing pass during load.
        # Actual VST3 discovery, processor creation, MIDI and audio use JUCE.
        with patch.object(_PythonExternalPluginMixin, '__set_initial_parameter_values__',
                          lambda instance, values: None):
            plugin = load_plugin(self.path)
        if not self.keys:
            keys = {}
            for name, label in LABELS.items():
                matches = [key for key, p in host_parameters(plugin).items()
                           if normalized(key) in {normalized(label), normalized('kd_' + name)}
                           or normalized(p.name) in {normalized(label), normalized('kd_' + name)}]
                assert len(matches) == 1, (name, [p.name for p in plugin._parameters
                                                 if not p.name.startswith('MIDI Ch.')])
                keys[name] = matches[0]
            self.keys = keys
        # Let Pd's startup messages settle before editing controls, as on the
        # native/web bridge. Continue this same processor for all later blocks.
        plugin([], duration=.03, sample_rate=RATE, num_channels=2, buffer_size=256, reset=False)
        for name, value in {**DEFAULTS, **parameters}.items():
            host_parameters(plugin)[self.keys[name]].raw_value = value
        return plugin

    def render(self, plugin, messages, duration=1.2, rate=RATE, block=256):
        audio = plugin(sorted(messages, key=lambda m: m.time), duration=duration,
                       sample_rate=rate, num_channels=2, buffer_size=block, reset=False)
        assert audio.shape == (2, round(duration * rate)), audio.shape
        assert np.isfinite(audio).all(), 'NaN/Inf in host audio'
        assert float(np.max(np.abs(audio))) <= 1.001, 'Audio exceeds ±1'
        return audio

    def saved_values(self, plugin):
        # JUCE's offline adapter does not relay DSP output changes into its
        # controller cache. Read the saved component state through a real reload.
        restored = self.fresh()
        VST3Plugin.raw_state.__set__(restored, plugin.raw_state)
        return {name: float(host_parameters(restored)[key].raw_value)
                for name, key in self.keys.items()}

    def check(self, name, function):
        print('... ' + name, flush=True)
        start = time.perf_counter()
        try:
            data = function()
            row = {'name': name, 'passed': True, 'measurements': data}
            print('ok  ' + name, flush=True)
        except Exception as error:
            row = {'name': name, 'passed': False, 'error': str(error),
                   'traceback': traceback.format_exc()}
            print('FEL ' + name + ': ' + str(error), flush=True)
        row['seconds'] = round(time.perf_counter() - start, 4)
        self.results.append(row)

    def identity(self):
        p = self.fresh()
        assert p.is_instrument
        assert p.name == 'KÖTTDISK 3000', p.name
        assert len(self.keys) == 14
        for name, key in self.keys.items():
            assert abs(host_parameters(p)[key].raw_value - DEFAULTS[name]) < 1e-5
        return {'plugin_name': p.name, 'parameters': self.keys, 'instrument': p.is_instrument}

    def channels_and_release(self):
        levels = {}
        for channel in [0, 8, 1, 15]:
            a = self.render(self.fresh(space=0), [note(channel=channel), off(channel=channel)])
            level = rms(a[:, int(.1 * RATE):int(.35 * RATE)])
            tail = rms(a[:, -RATE // 10:])
            assert (level > .01) if channel in [0, 8] else (level < 1e-9), (channel + 1, level)
            assert tail < 1e-7, (channel + 1, tail)
            levels[str(channel + 1)] = {'playing_rms': level, 'released_tail_rms': tail}
        # Identical pitch on both accepted channels must have independent note ownership.
        a = self.render(self.fresh(space=0), [note(channel=0), note(channel=8),
                        off(channel=0, at=.25), off(channel=8, at=.8)], duration=1.6)
        still_playing = rms(a[:, int(.65 * RATE):int(.75 * RATE)])
        assert still_playing > .01, still_playing
        assert rms(a[:, -4800:]) < 1e-7
        levels['independent_same_pitch_rms'] = still_playing
        return levels

    def velocity_and_chord(self):
        levels = []
        for velocity in [25, 70, 127]:
            a = self.render(self.fresh(), [note(velocity=velocity), off()])
            levels.append(rms(a[:, 4800:16800]))
        assert levels[0] < levels[1] < levels[2], levels
        notes = [48, 63, 67]  # C, E-flat, G: distinct fundamentals, not octave aliases.
        a = self.render(self.fresh(bite=0, space=0, warmth=0, sustain=1),
                        [note(n) for n in notes] + [off(n, at=.8) for n in notes], duration=1.5)
        segment = a[0, 9600:33600]
        spectrum = np.abs(np.fft.rfft(segment * np.hanning(len(segment))))
        peaks = {}
        for n in notes:
            freq = 440 * 2 ** ((n - 69) / 12)
            center = round(freq * len(segment) / RATE)
            amplitude = float(np.max(spectrum[center - 2:center + 3]))
            assert amplitude > 10, (n, amplitude)
            peaks[str(n)] = amplitude
        assert rms(a[:, -4800:]) < 1e-7
        return {'velocity_rms': levels, 'c_minor_fundamentals': peaks}

    def hold_pedal_and_panic(self):
        measurements = {}
        for controller in [26, 64]:
            a = self.render(self.fresh(space=0, sustain=1), [cc(controller, 127), note(),
                            off(at=.2), cc(controller, 0, at=.65)], duration=1.5)
            held = rms(a[:, 19200:28800]); tail = rms(a[:, -4800:])
            assert held > .01 and tail < 1e-7, (controller, held, tail)
            measurements[str(controller)] = {'held_rms': held, 'released_tail_rms': tail}
        for controller in [120, 123]:
            p = self.fresh(space=0, hold=1, tender=1)
            a = self.render(p, [note(), off(at=.2), cc(controller, 0, at=.4)], duration=.9)
            assert rms(a[:, -4800:]) < 1e-7
            saved = self.saved_values(p)
            assert saved['hold'] == 0, (controller, saved['hold'])
            assert saved['tender'] == 0, (controller, saved['tender'])
        return measurements

    def mapped_cc_state(self):
        controls = [(7, 'volume'), (1, 'bite'), (16, 'tone'), (17, 'bite'), (18, 'ratio'),
                    (19, 'attack'), (20, 'decay'), (21, 'sustain'), (22, 'release'),
                    (23, 'warmth'), (24, 'space'), (25, 'tender'), (26, 'hold'), (64, 'hold')]
        observed = {}
        p = self.fresh()
        for index, (controller, name) in enumerate(controls):
            value = 95 if name in ['hold', 'tender'] else 27 + index * 5
            self.render(p, [cc(controller, value)], duration=.02)
            actual = self.saved_values(p)[name]
            expected = 1 if name in ['hold', 'tender'] else value / 127
            assert abs(actual - expected) < 1e-5, (controller, name, actual, expected)
            observed[str(controller)] = actual
        # Unsupported channels must neither play nor alter saved host parameters.
        before = self.saved_values(p)['tone']
        self.render(p, [cc(16, 127, channel=1)], duration=.02)
        assert abs(self.saved_values(p)['tone'] - before) < 1e-5
        return observed

    def knob_timbre(self):
        metrics = {}
        for parameter in ['tone', 'bite', 'ratio', 'warmth', 'space', 'tender', 'bone', 'grind']:
            sounds = []
            for value in [0, 1]:
                sounds.append(self.render(self.fresh(**{parameter: value}), [note(), off()]))
            difference = rms(sounds[0] - sounds[1])
            assert difference > 1e-4, (parameter, difference)
            metrics[parameter] = {'difference_rms': difference}
        return metrics

    def midi_sample_offset(self):
        offset = 1500
        p = self.fresh(attack=0, space=0)
        a = self.render(p, [note(at=offset / RATE), off(at=.15)], duration=.3, block=4096)
        before = float(np.max(np.abs(a[:, :offset])))
        nonzero = np.flatnonzero(np.max(np.abs(a), axis=0) > 1e-6)
        assert len(nonzero), 'No note rendered'
        first = int(nonzero[0])
        assert before < 1e-10, (before, first)
        assert offset <= first <= offset + 256, (offset, first)
        return {'buffer_frames': 4096, 'scheduled_frame': offset,
                'first_audible_frame': first, 'peak_before_event': before}

    def state_roundtrip(self):
        original = self.fresh(tone=.19, bite=.83, ratio=.72, warmth=.54, volume=.37)
        # Flush JUCE's controller-to-processor automation queue before saving
        # the processor component state, just as an active DAW audio block does.
        self.render(original, [], duration=.02)
        state = original.raw_state
        assert isinstance(state, bytes) and len(state) > 0
        restored = self.fresh()
        # Direct descriptor avoids Pedalboard's __setattr__ unit-inference pass.
        VST3Plugin.raw_state.__set__(restored, state)
        expected = {name: float(host_parameters(original)[key].raw_value) for name, key in self.keys.items()}
        actual = {name: float(host_parameters(restored)[key].raw_value) for name, key in self.keys.items()}
        for name in expected:
            assert abs(actual[name] - expected[name]) < 1e-5, (name, actual[name], expected[name])
        return {'state_bytes': len(state), 'restored_parameters': actual}

    def extremes_and_cpu(self):
        results = []
        for rate in [44100, 96000]:
            for value in [0, 1]:
                params = {name: value for name in LABELS if name != 'hold'}
                p = self.fresh(**params)
                events = [note(n, velocity=127) for n in [0, 12, 36, 60, 96, 127]]
                events.append(cc(120, 0, at=.6))
                start = time.perf_counter()
                a = self.render(p, events, duration=1.1, rate=rate)
                elapsed = time.perf_counter() - start
                assert rms(a[:, -rate // 10:]) < 1e-7
                assert elapsed < 1.1, ('Slower than realtime', rate, elapsed)
                results.append({'sample_rate': rate, 'knobs': value,
                                'peak': float(np.max(np.abs(a))), 'realtime_ratio': elapsed / 1.1})
        return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plugin', nargs='?', type=Path,
                        default=ROOT / 'build/kottdisk/heavy/bin/Kottdisk.vst3')
    parser.add_argument('--report', type=Path, default=ROOT / 'docs/kottdisk/vst3-tests.json')
    args = parser.parse_args()
    if not args.plugin.exists():
        parser.error(f'Build the plugin first: {args.plugin}')
    tests = HostTests(args.plugin.resolve())
    for name in ['identity', 'channels_and_release', 'velocity_and_chord', 'hold_pedal_and_panic',
                 'mapped_cc_state', 'knob_timbre', 'midi_sample_offset', 'state_roundtrip',
                 'extremes_and_cpu']:
        tests.check(name, getattr(tests, name))
    report = {'plugin': str(args.plugin.resolve()), 'host': 'Pedalboard / JUCE VST3',
              'tested_at_utc': datetime.now(timezone.utc).isoformat(),
              'binary_sha256': {str(p.relative_to(args.plugin)): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in args.plugin.rglob('*') if p.is_file() and p.suffix in {'.so', '.vst3'}},
              'pedalboard_version': pedalboard.__version__, 'platform': platform.platform(),
              'passed': all(row['passed'] for row in tests.results), 'tests': tests.results,
              'host_adapter': 'Bypasses only Pedalboard Python unit inference for 2080 synthetic MIDI parameters; '
                              'uses unmodified JUCE VST3 audio, MIDI, state and raw host parameters.',
              'host_warnings': ['Locked DPF prints !fIsActive during JUCE initialization and active-refcount '
                                'messages during disposal. These are recorded separately from audio assertions.'],
              'limitations': ['Native GUI interaction is not tested by Pedalboard.',
                              'macOS, Windows, Safari, physical MIDI and desktop DAWs are not tested here.']}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(f'Report: {args.report}', flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
