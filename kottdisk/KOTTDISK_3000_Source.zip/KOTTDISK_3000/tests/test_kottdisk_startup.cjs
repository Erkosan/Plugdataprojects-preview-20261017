// Host lifecycle regressions. No DSP is simulated; real audio has its own suite.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const {pathToFileURL} = require('node:url');

(async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'kottdisk-startup-'));
  try {
    const file = path.join(directory, 'engine.mjs');
    fs.copyFileSync(path.join(__dirname, '../synths/Kottdisk/web/engine.js'), file);
    const {KottdiskEngine} = await import(pathToFileURL(file));
    let calls = [], activation = false, rejectFetch = false, contexts = [];
    class Context {
      constructor() { this.state='suspended'; contexts.push(this); this.destination={}; this.audioWorklet={addModule:async url=>{calls.push('module'); activation=false; assert(url.startsWith('blob:'));}}; }
      resume() { calls.push('resume'); assert(activation || this.state==='running', 'resume must run inside the original user gesture'); this.state='running'; return Promise.resolve(); }
      close() { this.state='closed'; return Promise.resolve(); }
    }
    global.window = {AudioContext:Context};
    Object.defineProperty(global, 'navigator', {configurable:true,value:{audioSession:{set type(_) {throw new Error('Unsupported optional routing');}}}});
    global.fetch = async (url, options) => {calls.push('fetch'); activation=false; assert.equal(options.credentials,'same-origin'); return {ok:!rejectFetch,status:rejectFetch?401:200,text:async()=> '// self-contained engine'};};
    global.AudioWorkletNode = class {
      constructor() {this.port={postMessage(){}};queueMicrotask(()=>this.port.onmessage({data:{type:'ready'}}));}
      connect(){} disconnect(){}
    };
    const synth = new KottdiskEngine(); activation=true; await synth.start();
    assert.deepEqual(calls,['resume','fetch','module']);
    assert.equal(synth.context.state,'running');
    console.log('PASS: synchronous gesture unlock; optional audioSession failure is harmless; authenticated fetch precedes Blob module');
    synth.context.state='interrupted';activation=true;await synth.start();
    assert.equal(synth.context.state,'running');
    console.log('PASS: interrupted audio resumes on a fresh user gesture');
    const failing = new KottdiskEngine();activation=true;rejectFetch=true;
    await assert.rejects(failing.start(), /401/);
    assert.equal(failing.context,null);assert.equal(failing.node,null);assert.equal(failing.pending,null);
    assert.equal(contexts.at(-1).state,'closed');
    rejectFetch=false;activation=true;await failing.start();
    assert.equal(failing.context.state,'running');
    console.log('PASS: failed startup releases resources and can retry');
    let runtimeError;
    failing.onerror = error => { runtimeError = error; };
    const retiredNode = failing.node, retiredContext = failing.context;
    retiredNode.onprocessorerror();
    assert.equal(failing.healthy, false);
    assert.equal(failing.status, 'failed');
    assert.match(runtimeError.message, /avbröts/);
    activation=true;await failing.start();
    assert.equal(failing.healthy, true);
    assert.notEqual(failing.node, retiredNode);
    assert.equal(retiredContext.state, 'closed');
    failing.node.port.onmessage({data:{type:'health',frames:1234,queuedEvents:0}});
    assert.equal(failing.diagnostics.frames,1234);
    failing.node.port.onmessage({data:{type:'error',message:'Non-finite PCM'}});
    assert.equal(failing.healthy,false);assert.match(runtimeError.message,/Non-finite PCM/);
    activation=true;await failing.start();assert.equal(failing.healthy,true);
    console.log('PASS: processor and PCM failures invalidate the engine and recover on a new gesture');
    await failing.dispose();await synth.dispose();
  } finally {fs.rmSync(directory,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exitCode=1;});
