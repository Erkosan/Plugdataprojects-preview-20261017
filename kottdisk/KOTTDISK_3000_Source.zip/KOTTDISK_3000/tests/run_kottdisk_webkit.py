#!/usr/bin/env python3
"""Real WebKit audio + long-session integration; no audio/autoplay mocks."""
import argparse,json,os,time,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
def environment():
    env=os.environ.copy()
    base=ROOT/'.browser-libs/root'
    web=Path.home()/'.cache/ms-playwright/webkit-2370/minibrowser-wpe'
    if base.exists() and web.exists():
        env.update({'LD_LIBRARY_PATH':f'{web}/lib:{web}/sys/lib:{base}/usr/lib/x86_64-linux-gnu','WEBKIT_EXEC_PATH':str(web/'bin'),'WEBKIT_INJECTED_BUNDLE_PATH':str(web/'lib'),'WEBKIT_INSPECTOR_RESOURCES_PATH':str(web/'share'),'GIO_EXTRA_MODULES':str(base/'usr/lib/x86_64-linux-gnu/gio/modules'),'GST_PLUGIN_SYSTEM_PATH_1_0':str(base/'usr/lib/x86_64-linux-gnu/gstreamer-1.0'),'GST_PLUGIN_SCANNER_1_0':str(base/'usr/lib/x86_64-linux-gnu/gstreamer1.0/gstreamer-1.0/gst-plugin-scanner')})
        return env,str(web/'bin/MiniBrowser')
    return env,None
def meter(page):
    return page.evaluate("""() => {const a=window.__meter,b=new Float32Array(a.fftSize);a.getFloatTimeDomainData(b);return {rms:Math.sqrt(b.reduce((n,v)=>n+v*v,0)/b.length),peak:Math.max(...b.map(Math.abs)),finite:Array.from(b).every(Number.isFinite),time:kottdisk.engine.context.currentTime,status:kottdisk.engine.status,healthy:kottdisk.engine.healthy};}""")
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url');parser.add_argument('--seconds',type=int,default=120);parser.add_argument('--label',default='final')
    args=parser.parse_args()
    server=None;errors=[];checks=[];probes=[]
    if not args.url:
        class Handler(SimpleHTTPRequestHandler):
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'synths/Kottdisk/web/dist')))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        url=f'http://127.0.0.1:{server.server_port}/?no-sw=1'
    else:url=args.url
    report={'label':args.label,'url':url,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'engine':'Playwright WebKit, real AudioWorklet/WASM','checks':checks,'probes':probes,'errors':errors,'passed':False}
    with sync_playwright() as p:
        env,executable=environment()
        browser=p.webkit.launch(headless=True,executable_path=executable,env=env)
        try:
            page=browser.new_page(viewport={'width':1280,'height':850})
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
            page.add_init_script("""window.__messages=[];const Original=window.AudioWorkletNode;window.AudioWorkletNode=class extends Original{constructor(...a){super(...a);this.port.addEventListener('message',e=>window.__messages.push(e.data));this.port.start();}};""")
            page.goto(url,wait_until='networkidle')
            page.wait_for_function('window.kottdisk')
            key=page.locator('.key[data-note="60"]');key.hover();page.mouse.down()
            page.wait_for_function("kottdisk.ready && kottdisk.engine.context.state==='running'",timeout=15000)
            page.evaluate("() => {const e=kottdisk.engine;window.__meter=e.context.createAnalyser();__meter.fftSize=2048;e.node.connect(__meter);}")
            page.wait_for_timeout(400)
            initial=meter(page);probes.append(initial)
            assert initial['rms']>.001 and initial['finite'],initial
            checks.append('User gesture starts actual WebKit/WASM audio');page.mouse.up()
            # Keep a physical keyboard chord through repeated control gestures.
            page.keyboard.down('a');page.keyboard.down('d');page.keyboard.down('g')
            controls=['kd_tone','kd_bite','kd_ratio','kd_attack','kd_decay','kd_sustain','kd_release','kd_warmth','kd_space','kd_volume']
            start=time.monotonic();cycles=0
            while time.monotonic()-start<args.seconds:
                for index,name in enumerate(controls):
                    control=page.locator('#'+name);box=control.bounding_box()
                    x=box['x']+box['width']/2;y=box['y']+box['height']/2
                    page.mouse.move(x,y);page.mouse.down();page.mouse.move(x,y-120 if cycles%2 else y+120,steps=8);page.mouse.up()
                # Restore audible controls without replacing engine or resetting notes.
                page.evaluate("() => {for(const [n,v] of Object.entries({kd_volume:.65,kd_attack:.03,kd_decay:.4,kd_sustain:.7,kd_release:.1,kd_tone:.7,kd_bite:.5,kd_ratio:.3,kd_space:.25}))kottdisk.update(n,v,{display:false});}")
                page.wait_for_timeout(100)
                sample=meter(page);probes.append(sample);assert sample['finite'] and sample['peak']<1.01,sample
                assert page.evaluate("kottdisk.engine.context.state")== 'running'
                cycles+=1
            page.keyboard.up('a');page.keyboard.up('d');page.keyboard.up('g')
            page.evaluate('kottdisk.panic()')
            page.wait_for_timeout(100)
            key.hover();page.mouse.down();page.wait_for_timeout(300)
            final=meter(page);probes.append(final);assert final['rms']>.001,final
            page.mouse.up();checks.append('Repeated real drags preserve finite audio and fresh notes')
            page.evaluate('kottdisk.engine.context.suspend()')
            key.click();page.wait_for_function("kottdisk.engine.context.state==='running'")
            checks.append('Fresh physical gesture resumes suspended WebKit audio')
            report.update({'passed':not errors,'activity_seconds':round(time.monotonic()-start,2),'cycles':cycles,'user_agent':page.evaluate('navigator.userAgent'),'worklet_messages':page.evaluate('__messages')})
            print(json.dumps({k:v for k,v in report.items() if k not in ['probes','worklet_messages']}),flush=True)
        except Exception as error:
            report['failure']=str(error)
            try:report['state']=page.evaluate("({ready:kottdisk.ready,context:kottdisk.engine.context?.state,lcd:document.querySelector('#menu-status').textContent,messages:__messages})")
            except Exception:pass
            print(json.dumps(report,ensure_ascii=False),flush=True)
        finally:
            browser.close()
            if server:server.shutdown()
            output=ROOT/'docs/kottdisk/webkit-tests.json'
            previous=json.loads(output.read_text()) if output.exists() else {'runs':[]}
            previous['runs'].append(report);output.write_text(json.dumps(previous,ensure_ascii=False,indent=2)+'\n')
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
