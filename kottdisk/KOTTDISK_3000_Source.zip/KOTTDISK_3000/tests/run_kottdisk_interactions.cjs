#!/usr/bin/env node
'use strict';
// Real pointer hit-testing at scaled coordinates. --dist serves the final built application.
// Source mode uses the source panel with the bundled, compiled Pd worklet.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const {chromium} = require('playwright-core');
const web = path.resolve(__dirname, '../synths/Kottdisk/web');
const finalBuild = process.argv.includes('--dist');
const root = finalBuild ? path.join(web, 'dist') : web;
const baseline = process.argv.includes('--baseline');
const report = {date:new Date().toISOString(), baseline, panel:finalBuild?'final dist':'source', engine:'Real compiled PlugData/hvcc/WASM', checks:[], errors:[]};
const server = http.createServer((req,res) => {
  const name = decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  let file = path.join(root,name === '/' ? 'index.html' : name);
  if (!file.startsWith(root + path.sep)) return res.writeHead(403).end();
  // The build bundles the compiled Pd engine into the worklet for Safari blob loading.
  if (name === '/worklet.js' || !fs.existsSync(file)) file = path.join(web,'dist',name);
  fs.readFile(file,(error,data) => {
    if (error) return res.writeHead(404).end();
    res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.json':'application/json'})[path.extname(file)] || 'application/octet-stream');res.end(data);
  });
});
let browser, page;
const check = async (name, fn) => {try {const detail=await fn();report.checks.push({name,pass:true,detail});console.log('PASS',name);} catch(e){report.checks.push({name,pass:false,error:e.message});console.log('FAIL',name,e.message);} finally {if(page) await page.mouse.up().catch(()=>{});}};
(async()=>{
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const context=await browser.newContext({viewport:{width:1280,height:850},hasTouch:true,serviceWorkers:'block'});
  page=await context.newPage();page.on('pageerror',e=>report.errors.push(e.message));
  await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>window.kottdisk);
  const value=id=>page.evaluate(id=>window.kottdisk.values[id],id);
  const set=(id,v)=>page.evaluate(([id,v])=>window.kottdisk.update(id,v,{display:false}),[id,v]);
  const center=async selector=>{const b=await page.locator(selector).boundingBox();return {x:b.x+b.width/2,y:b.y+b.height/2};};
  const drag=async (id,delta)=>{const p=await center('#'+id);await page.mouse.move(p.x,p.y);await page.mouse.down();await page.mouse.move(p.x,p.y+delta,{steps:5});await page.mouse.up();};
  const ids=await page.locator('.knob').evaluateAll(nodes=>nodes.map(n=>n.id));
  for (const width of [1280,800,390]) {
    await page.setViewportSize({width,height:850});await page.waitForTimeout(80);
    for (const id of ids) await check(`${width}: ${id} real hit and drag`,async()=>{
      await set(id,.5);
      const p=await center('#'+id);
      const hit=await page.evaluate(({p,id})=>{const n=document.getElementById(id),hit=document.elementFromPoint(p.x,p.y);return {correct:n===hit||n.contains(hit),tag:hit?.outerHTML?.slice(0,180)}},{p,id});
      assert(hit.correct,JSON.stringify(hit));await drag(id,-20);assert(await value(id)>.5,`${id} unchanged after mouse drag`);return hit;
    });
  }
  await page.setViewportSize({width:1280,height:850});await page.waitForTimeout(80);
  for(const id of ids) {
    await check(`${id}: keyboard range, wheel, reset`,async()=>{
      await page.locator('#'+id).focus();await page.keyboard.press('Home');assert.equal(await value(id),0);await page.keyboard.press('End');assert.equal(await value(id),1);
      await page.keyboard.press('ArrowLeft');assert.equal(await value(id),.99);await page.keyboard.press('Shift+ArrowLeft');assert(Math.abs(await value(id)-.989)<1e-7);
      const p=await center('#'+id);await page.mouse.move(p.x,p.y);await page.mouse.wheel(0,100);await page.waitForTimeout(40);assert(await value(id)<.989,'wheel has no effect');
      await page.locator('#'+id).dblclick();const d=await value(id);assert(d>0&&d<1,'reset failed');
      await drag(id,-1000);assert.equal(await value(id),1);await drag(id,1000);assert.equal(await value(id),0);
    });
    await check(`${id}: real touch drag and double tap`,async()=>{
      await set(id,.5);const p=await center('#'+id);const c=await context.newCDPSession(page);
      await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y-40,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert(await value(id)>.5);
      await page.touchscreen.tap(p.x,p.y);await page.waitForTimeout(70);await page.touchscreen.tap(p.x,p.y);assert(await value(id)<.7,'double tap failed');
      await set(id,.5);await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y-220,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await value(id),1);
      await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...p,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y+220,id:1}]});await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await value(id),0);await c.detach();
    });
  }
  await check('drag cancels on blur and lost capture',async()=>{
    const id='kd_ratio';await set(id,.5);const p=await center('#'+id);await page.mouse.move(p.x,p.y);await page.mouse.down();await page.evaluate(()=>window.dispatchEvent(new Event('blur')));await page.mouse.move(p.x,p.y-70);assert.equal(await value(id),.5);await page.mouse.up();
    await page.mouse.move(p.x,p.y);await page.mouse.down();await page.mouse.move(p.x,p.y-30);await page.mouse.up();assert(await value(id)>.5);
  });
  await check('MÖRA, hold and captured release',async()=>{
    await page.locator('#tender').focus();await page.keyboard.down('Space');assert.equal(await value('kd_tender'),1);await page.keyboard.up('Space');assert.equal(await value('kd_tender'),0);
    const p=await center('#tender');await page.mouse.move(p.x,p.y);await page.mouse.down();assert.equal(await value('kd_tender'),1);await page.mouse.move(0,0);await page.mouse.up();assert.equal(await value('kd_tender'),0);
    await page.locator('#hold').click();assert.equal(await value('kd_hold'),1);await page.locator('#hold').click();assert.equal(await value('kd_hold'),0);
  });
  await check('artworks play independently and release on blur',async()=>{
    for(const [id,param] of [['play-steak','kd_tender'],['play-bone','zz_kd_bone'],['play-grind','zz_kd_grind']]){
      const p=await center('#'+id);const hit=await page.evaluate(p=>document.elementFromPoint(p.x,p.y)?.closest('button')?.id,p);assert.equal(hit,id);
      await page.mouse.move(p.x,p.y);await page.mouse.down();assert.equal(await value(param),1);await page.mouse.move(0,0);await page.mouse.up();assert.equal(await value(param),0);
      await page.locator('#'+id).focus();await page.keyboard.down('Enter');assert.equal(await value(param),1);await page.evaluate(()=>window.dispatchEvent(new Event('blur')));assert.equal(await value(param),0);await page.keyboard.up('Enter');
    }
  });
  await check('mobile artwork hits and multitouch independence',async()=>{
    await page.setViewportSize({width:390,height:844});await page.waitForTimeout(100);
    const a=await center('#play-bone'),b=await center('#play-grind'),c=await context.newCDPSession(page);
    await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...a,id:11},{...b,id:12}]});assert.equal(await value('zz_kd_bone'),1);assert.equal(await value('zz_kd_grind'),1);
    await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await value('zz_kd_bone'),0);assert.equal(await value('zz_kd_grind'),0);await c.detach();
    await page.setViewportSize({width:1280,height:850});await page.waitForTimeout(80);
  });
  await check('legacy session imports and new performance parameters stay momentary',async()=>{
    assert(await page.evaluate(()=>{const k=window.kottdisk,s=k.exportSession();delete s.values.zz_kd_bone;delete s.values.zz_kd_grind;k.importSession(s);return k.values.zz_kd_bone===0&&k.values.zz_kd_grind===0;}));
  });
  await check('actual Pd worklet starts after gestures',async()=>{await page.locator('.key[data-note="60"]').click();await page.waitForFunction(()=>window.kottdisk.ready&&window.kottdisk.engine.context.state==='running');assert(await page.evaluate(()=>window.kottdisk.engine.node instanceof AudioWorkletNode && window.kottdisk.engine.healthy));
    const params=await (await page.request.get(`http://127.0.0.1:${server.address().port}/params.json`)).json();assert.equal(params.length,14);assert.deepEqual(params.slice(-2).map(p=>p.name),['zz_kd_bone','zz_kd_grind']);});
  assert.equal(report.errors.length,0,JSON.stringify(report.errors));
})().catch(e=>{report.fatal=e.stack;}).finally(async()=>{
  if(browser)await browser.close();await new Promise(r=>server.close(r));
  report.summary={passed:report.checks.filter(c=>c.pass).length,failed:report.checks.filter(c=>!c.pass).length};
  report.pass=!report.fatal && report.errors.length===0 && report.summary.failed===0;
  const output=baseline?'/tmp/kottdisk-baseline-interactions.json':path.resolve(__dirname,'../docs/kottdisk/overhaul-interactions.json');
  fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({...report.summary,pass:report.pass,panel:report.panel,report:output}));
  if(report.fatal||(!baseline&&!report.pass))process.exitCode=1;
});
