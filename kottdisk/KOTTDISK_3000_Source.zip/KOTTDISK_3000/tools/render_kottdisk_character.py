#!/usr/bin/env python3
"""Four C-minor listening examples from the same compiled Pd engine as the plugin."""
import argparse
import json
from pathlib import Path
import sys
import wave
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from test_kottdisk_character import CharacterSynth, rms, spectrum

PRESETS={
    '01-skinksammet':dict(bite=.22,ratio=.08,attack=.6,decay=.65,sustain=.72,release=.62,tone=.48,warmth=.26,space=.52),
    '02-knivspets':dict(bite=.52,ratio=.38,attack=.015,decay=.24,sustain=.10,release=.12,tone=.82,warmth=.18,space=.28),
    '03-benporslin':dict(bite=.3,ratio=.76,attack=.01,decay=.48,sustain=.12,release=.4,tone=.75,warmth=.08,space=.65),
    '04-flaskmorr':dict(bite=.79,ratio=.19,attack=.01,decay=.22,sustain=.68,release=.12,tone=.6,warmth=.86,space=.12),
}

def render(name,values):
    s=CharacterSynth();s.preset(values);s.tempo(110)
    chunks=[]
    try:
        if name.startswith('01'):
            for chord in [(48,55,60,63),(44,51,56,60),(41,48,53,56),(43,50,55,58)]:
                for n in chord:s.note(n,88)
                chunks.append(s.audio(2.2))
                for n in chord:s.note(n,0)
                chunks.append(s.audio(.35))
        elif name.startswith('04'):
            for i,n in enumerate([36,36,43,46,36,39,43,34,36,43,46,48,43,39,34,36]):
                s.note(n,105);s.param('grind',float(i>=8));s.param('tender',float(i in [3,7,11,15]))
                chunks.append(s.audio(.37));s.note(n,0);s.param('tender',0);chunks.append(s.audio(.12))
            s.param('grind',0)
        else:
            for i,n in enumerate([60,67,63,70,72,67,62,58,60,63,55,58,60,67,75,72]):
                s.note(n,78+(i%4)*12)
                if name.startswith('03') and i>=8:s.param('bone',1)
                chunks.append(s.audio(.26));s.param('bone',0);s.note(n,0);chunks.append(s.audio(.16))
        chunks.append(s.audio(2.5))
        return np.concatenate(chunks)
    finally:s.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'build/kottdisk/character')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    report={}
    for name,values in PRESETS.items():
        a=render(name,values);assert np.isfinite(a).all() and np.max(np.abs(a))<1
        path=args.output/(name+'.wav')
        with wave.open(str(path),'wb') as w:
            w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000);w.writeframes((a*32767).astype('<i2').tobytes())
        f,p=spectrum(a)
        report[name]={'path':str(path),'seconds':len(a)/48000,'rms':rms(a),'peak':float(np.max(np.abs(a))),
                      'centroid_hz':float((f*p).sum()/p.sum()),'preset':values}
    (args.output/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
