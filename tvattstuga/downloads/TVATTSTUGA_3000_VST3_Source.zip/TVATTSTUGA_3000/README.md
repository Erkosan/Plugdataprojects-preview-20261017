# TVÄTTSTUGA 3000

Miljonprogrammets källartvättstuga (`TVÄTTSTUGA B · KÄLLARPLAN`, 1971) — andra maskinen i **FOLKHEMMETS SKUGGOR**. Polymetrisk 5-spårs trum- och tvättmaskin i C-moll med Wascator-trumma, gjutjärnsmangel, högtrycksventil, luddfilter, centrifug i obalans och passivt-aggressiv tvättlapp. Ljudet är PlugData-patcharna i den här mappen (`tvattstuga.pd` och `TV_*.pd`) och kompileras med hvcc 0.17.2 till C/C++, WebAssembly och DPF VST3.

## Patcharna

| Fil | Vad |
| --- | --- |
| `tvattstuga.pd` | Huvudpatch med redigerbar PlugData-panel (`cnv`, `hsl`, `tgl`, `bng`) på 25px-rutnät, utjämnade ratt-parametrar (`@hv_param` → `line~` → `s~ tv_*`) och koppling mellan subpatcharna. |
| `TV_Seq.pd` | 5-spårs polymetrisk 16-stegs programvals i C-moll med `metro`, `midirealtimein` (248, 250, 251, 252), `__hv_dpf_bpm`, `swing`, `len0`–`len4` och `table tv_steps 16` (bas-4-kodade spår). |
| `TV_Notes.pd` | MIDI-mottagare på kanal 7 och delade kanal 1. Trummappning (35/36/48/60 = `TRUMMA`, 38/40/50/62 = `MANGEL`, 42/44/51/63 = `VENTIL` stängd, 46/49/53/65 = `VENTIL` öppen, 39/55/67 = `LUDDFILTER`, 41/43/45/47 och övriga toner = `CENTRIFUG` i C-moll). Velocity ≥ 100 = `KOKTVÄTT` (accent). |
| `TV_CC.pd` | MIDI CC på kanal 7 och 1 (CC16–32, CC74, CC71, CC77, CC64, CC14, CC15, CC7, CC120/123). |
| `TV_Gestures.pd` | Signaturgesterna `CENTRIFUG 1400 VARV · RUSNING` (`centrifug`) och `ARG TVÄTTLAPP · STÄNG AV & SKÄLL` (`tvattlapp`). |
| `TV_Voices.pd` | De 5 tvättstugerösterna i C-moll: `TRUMMA · KICK` (C2/C1/G2), `MANGEL · SNARE` (D3/G3/Bb3/Eb4), `VENTIL · HIHAT` (C6/Eb6/G6 med öppen/stängd choke), `LUDDFILTER · CLAP` (4-slags klapp + C4/Eb4/G4) och `CENTRIFUG · TOM/METALL` (C-moll-kvantiserad trumklang med obalans-vobbel). |
| `TV_FX.pd` | `OBALANS · PUMP` (`obalans`), `LUDDFILTER · FILTER` (`ludd`), `KALKAVLAGRING · OVERDRIVE` (`kalk`), `TORKRUM · KÄLLAREKO` (`torkrum`), mastervolym (`volume`) och mjuk begränsare. |

## Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `trumma` | 0–1 | 0,65 | FÖRTVÄTT · TRUMDJUP · CC16 |
| `mangel` | 0–1 | 0,55 | VALSTRYCK · MANGELBETT · CC17 |
| `ventil` | 0–1 | 0,50 | VATTENTRYCK · VENTILPYS · CC18 |
| `ludd` | 0–1 | 0,55 | LUDDFILTER · FILTER & SMÄLL · CC74 & CC19 |
| `varvtal` | 0–1 | 0,55 | CENTRIFUG · METALLKLANG · CC71 & CC20 |
| `obalans` | 0–1 | 0,30 | OBALANS · PUMP & VOBBEL · CC21 |
| `kalk` | 0–1 | 0,28 | KALKAVLAGRING · OVERDRIVE · CC77 & CC22 |
| `torkrum` | 0–1 | 0,22 | TORKRUM · KÄLLAREKO · CC23 |
| `volume` | 0–1 | 0,80 | VOLYM · UTNIVÅ · CC7 & CC24 |
| `centrifug` | 0/1 | 0 | CENTRIFUG 1400 VARV · RUSNING · CC25 |
| `tvattlapp` | 0/1 | 0 | ARG TVÄTTLAPP · STÄNG AV & SKÄLL · CC64 & CC26 |
| `bpm` | 30–300 | 120 | TEMPO · CC14 |
| `start` | 0/1 | 0 | START · CC15 |
| `swing` | 0–1 | 0,15 | SVÄNG · CC27 |
| `len0`–`len4` | 1–16 | 16,16,16,16,12 | Polymetrisk spårlängd · CC28–CC32 |
| `step0`–`step15` | 0–1023 | KULÖRTVÄTT 60° | Bas-4 per spår (`t0 + 4*t1 + 16*t2 + 64*t3 + 256*t4`, 0=paus, 1=slag, 2=KOKTVÄTT/öppen) |
