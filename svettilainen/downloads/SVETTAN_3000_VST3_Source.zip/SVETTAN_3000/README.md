# SVETTAN 3000

Gubbkören i bastun. Sex nakna gubbar sitter på laven och sjunger ackorden du spelar: varje röst i motorn är en gubbe. Kasta vatten på stenarna så sväller kören och öppnar munnen, hoppa i isvaken så fryser ackordet fast, och smiska takten med björkriset. Blir det för varmt svimmar någon.

Ljudet är PlugData-patcharna i den här mappen och kompileras med hvcc, precis som RUNKINATOR och TURBOTUTTE. Webbsidan i `web/` är bastun runt motorn.

```
svettan.pd  →  hvcc  →  C  →  Emscripten  →  svettan-engine.js  →  AudioWorklet (web/worklet.js)
            →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Intel + Apple Silicon), Windows och Linux
```

## Ljudet

Varje gubbe är två glottala sågtänder (vänster och höger röst i hans bröst) som glider upp i tonen underifrån, med ett vibrato som kommer in efter ansatsen. Kören går genom tre formantfilter per sida som flyttas mellan vokalerna **M O Å A Ä E I**, med andedräkt (brus) genom samma vokal. Vänster och höger formantbank är förskjutna 4,5 %, som två olika munnar. Därför ligger ljudet där små högtalare spelar (cirka 0,5–3 kHz) och inte bara i basen.

Bastun har en **temperatur** som lever sitt eget liv. Den följer VÄRME långsamt (en kall bastu tar några sekunder att elda upp), stiger lite för varje ton och mycket för varje kast, och sjunker i isvaken. Värmen gör kören ljusare, ger mer dallrande vibrato, mer andedräkt, mer mättnad och fler svettdroppar. Över 109 °C svimmar en gubbe: ackordet sjunker fem halvtoner, det dunsar i laven och han bärs ut (bastun svalnar) innan han vaknar.

## Patcharna

Allt är vanilla-PD och öppnas direkt i PlugData. `svettan.pd` är huvudpatchen. Patcharna skrevs av [tools/generate_patches.py](tools/generate_patches.py), som är läsbar dokumentation av hur de hänger ihop; den skriver över `.pd`-filerna, så kör den bara om du ändrar där i stället för i PlugData.

| Fil | Vad |
| --- | --- |
| `svettan.pd` | Rattarnas parametrar (`@hv_param`) → utjämnade signaler (`s~ sv_*`), sex gubbar, alla delpatchar och `dac~`. |
| `SV_Notes.pd` | MIDI-toner på kanal 16 och den delade kanal 1 → ISVAK (håll) → `poly 6 1` → sex gubbar. Den sjunde tonen tar den äldsta gubben. En hållen ton som spelas igen släpps först. |
| `SV_Voice.pd` | En gubbe (argument 1–6): tonhöjd med glid underifrån, stämning, svimning, unisono och vibrato, ansats/släpp, två sågtänder. |
| `SV_Vowel.pd` | MUN: formanter och deras styrka genom M O Å A Ä E I. Ett kast drar munnen mot A. |
| `SV_Heat.pd` | Temperaturen, termometern ut, och svimningen (sänkning, duns, utbärning). |
| `SV_Kasta.pd` | Bastuskopan: fräs och knaster från stenarna, svall i kören, värme. |
| `SV_Drops.pd` | Svettdroppar från taket, stämda över senaste tonen. Tätare ju varmare. |
| `SV_Kvast.pd` | Björkriset: 16 steg smisk och hård smisk. Följer DAW:ns transport och MIDI-klocka (start, fortsätt, stopp, sex pulser per steg, DAW-tempo via `__hv_dpf_bpm`). Kören duckar för varje smisk (PUMP). |
| `SV_CC.pd` | Seriens CC-banker (se nedan) på kanal 16 och 1. |
| `SV_FX.pd` | Andedräkt, formanter, svall, pump, SVETT, droppar och smisk, träpanelens rum (fyra dämpade kamfilter och två allpass per sida), volym och mjuk begränsare. |

### Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `heat` | 0–1 | 0,45 | VÄRME · temperatur · CC16 |
| `vowel` | 0–1 | 0,35 | MUN · vokal M O Å A Ä E I · CC17 |
| `breath` | 0–1 | 0,35 | FLÅS · andedräkt · CC18 |
| `tremble` | 0–1 | 0,3 | DALLER · vibrato · CC19 och CC1 |
| `swell` | 0–1 | 0,35 | ANDETAG · ansats 12 ms–2,4 s, släpp 0,14–3,9 s · CC20 |
| `crowd` | 0–1 | 0,4 | GUBBAR · unisono · CC21 |
| `drops` | 0–1 | 0,3 | DROPPAR · svettdroppar · CC22 |
| `drive` | 0–1 | 0,2 | SVETT · drive · CC23 |
| `room` | 0–1 | 0,4 | PANEL · rumsklang · CC24 |
| `whip` | 0–1 | 0,35 | PUMP · björkriset duckar kören · CC25 |
| `smack` | 0–1 | 0,6 | SMISK · björkrisets nivå · CC26 |
| `kasta` | 0/1 | 0 | KASTA · stigande flank kastar · CC27 (64–127) |
| `hold` | 0/1 | 0 | ISVAK · håll ackordet och kyl bastun · CC64 (sustainpedalen) |
| `bpm` | 30–300 | 96 | CC14 (samma skala som RUNKINATOR). Webbsidan och exemplet startar på 120. |
| `start` | 0/1 | 0 | björkriset spelar · CC15 |
| `length` | 1–16 | 16 | CC28, björkrisets längd |
| `swing` | 0–1 | 0 | CC29 |
| `tune` | −12–12 | 0 | STÄMMI · TONART · CC30, halvtoner (displayen visar tonnamnet) |
| `volume` | 0–1 | 0,8 | VRÅLI · VOLYM · CC7 |
| `kv0`–`kv15` | 0–2 | 2 0 0 1 0 0 1 0 2 0 0 1 0 1 0 0 | björkrisets steg: 0 vila, 1 smisk, 2 hård smisk |

CC120 och CC123 tystar alla gubbar och glömmer hållna toner.

### Händelser ut

| Send | Värden |
| --- | --- |
| `ev_voice` | gubbe (1–6), MIDI-ton, anslag (0 = slutar sjunga) |
| `ev_heat` | temperatur 0–1,05 (sidan visar 30 + 80 · värdet °C), fyra gånger i sekunden |
| `ev_kasta` | 1 för varje kast |
| `ev_svimma` | 1 när någon svimmar, 0 när han vaknar |
| `ev_step` | björkrisets steg 0–15 |
| `ev_drop` | tonen en svettdroppe fick |

Webbsidan gör om dem till `window.svettan`-händelser med ljudklockans tid, som `window.runkinator` och `window.turbotutte`:

```js
window.svettan.addEventListener('note', (e) => e.detail); // {voice, note, velocity, time, gubbe}
window.svettan.update('vowel', .5);                        // samma väg som rattarna
window.svettan.kasta();
```

## Webbsidan

- **Bastun** skalas som en bild och reflowar aldrig. På telefon i liggande läge fyller den höjden.
- **Gubbarna** heter BENGT, LASSE, KJELL, ROFFE, GÖRAN och STIG-ÅKE. Den som sjunger öppnar munnen i MUN-rattens vokal och visar sin ton. De rodnar och svettas med värmen, sträcker armarna och skriker AAAH vid ett kast, blir blå och darrar i isvaken, och GÖRANs glasögon immar igen.
- **Fotpallen** är klaviaturen: två oktaver, plankor är vita tangenter och bastustenar svarta. Den tar flera fingrar samtidigt.
- **Bastuspannen**, **KASTA**-knappen och Q kastar vatten. **Fönstret mot isvaken**, **ISVAK** och I håller ackordet. **Björkriset på kroken**, Play och mellanslag startar björkriset.
- **STÄMMI** och **VRÅLI** sist i ratt-raden är tonart och volym. STÄMMI går i hela halvtoner och displayen visar tonen (C, C#, …). Basturna rör dem inte.
- **Exemplet** (kugghjulet) spelar Cm, Ab, Fm, Gm på 120 BPM: samma tonart och tempo som TURBOTUTTEs exempelslinga, så att de låter ihop från start. Motorns standard för `bpm` är kvar på 96 så att befintliga DAW-projekt inte ändras; i en DAW styr transporten ändå tempot.
- **Bastur**: sex färdiga ljud: FINSK, RÖK, SPA, BADHUS, MUNKAR och GYMMET (tangent 1–6).
- **Bastuprat**: när ingen spelar pratar gubbarna i displayen.
- **Kugghjulet**: spela exempel, rensa björkriset, spara och öppna session (JSON), Anslut MIDI, installera app, helskärm, MIDI-mappning och VST3-nedladdningar.
- Allt sparas automatiskt i webbläsaren.
- **MIDI**: ensam på sidan tar den emot alla kanaler. Inne i ÄLSKOG lyssnar den bara på 16 och 1. Sustainpedalen är ISVAK. MIDI-klocka styr björkriset i motorn, och displayen visar `SYNKAD`.
- **iPhone**: ljudet spelas även med ljudlös-knappen på (`navigator.audioSession`).

## Bygga

```bash
source ~/emsdk/emsdk_env.sh
python3 tools/build_svettan.py                 # webben → synths/Svettan/web/dist
python3 tools/build_svettan.py --kit           # även byggkitet i web/downloads
python3 tools/build_svettan.py --vst3          # byggkit + Linux-VST3, byggd genom att köra kitet (kräver dep/dpf)
python3 tools/build_svettan.py --publish DIR   # kopiera den färdiga sidan till DIR, t.ex. runken.nu/svettan
```

## Testa

```bash
python3 -m unittest tests.test_svettan        # motorn: ackord och nivå, sex röster, kanaler, vokaler, ISVAK, kast, svimning, värme, droppar, björkris, DAW/MIDI-klocka, CC, tonart, volym
python3 tests/run_svettan_web.py               # sidan i headless Chromium, desktop och telefon, med riktigt ljud
```
