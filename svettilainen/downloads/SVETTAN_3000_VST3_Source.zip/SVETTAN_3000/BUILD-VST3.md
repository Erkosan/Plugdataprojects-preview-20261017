# SVETTAN 3000 — bygg VST3

**Skapare:** Pastor Gregorius
**Format:** VST3. VST3-formatet är gemensamt, men binären måste byggas separat för macOS, Windows och Linux.

Ljudet är PlugData-patcharna i den här mappen (`svettan.pd` och `SV_*.pd`). Öppna dem i PlugData för att lyssna eller ändra. Bygget gör om exakt samma patchar till en VST3 med hvcc och DPF, och motorn är densamma som i webbversionen. Pluginet har värdens vanliga reglage för alla rattar. Björkriset följer DAW:ns start, stopp och tempo.

## macOS

Krav: Python 3.10+, Git och Xcode Command Line Tools (`xcode-select --install`).

Dubbelklicka `bygg.command`, eller kör:

```bash
bash bygg.command
```

Resultat: `build/bin/SVETTAN_3000.vst3`, en bundle för både Intel och Apple Silicon, ad hoc-signerad. Kopiera hela bundle-mappen till `~/Library/Audio/Plug-Ins/VST3/` och skanna om i DAW:n. `bash bygg.command --install` gör kopieringen åt dig.

## Windows 10/11 (native Windows VST3)

1. Installera MSYS2 i `C:\msys64`.
2. Öppna **MSYS2 UCRT64** och kör:

```bash
pacman -Syu
pacman -S --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-python mingw-w64-ucrt-x86_64-python-pip git make
```

3. Stäng UCRT64-fönstret efter en eventuell basuppdatering, öppna det igen och kör kommandot en gång till om MSYS2 begär det.
4. Installera också vanlig 64-bitars **Windows-Python 3.13** (`winget install -e --id Python.Python.3.13`). MSYS2:s egen Python kan inte installera hvcc:s `pydantic_core`. `tools/build.py` startar därför om sig själv med Windows-Python 3.13 i en separat `.venv-windows`, medan MSYS2 fortfarande står för `make`/`gcc`.
5. Kör från projektmappen i PowerShell:

```powershell
.\bygg-vst3-windows.ps1
```

Skriptet kör `& "C:\msys64\msys2_shell.cmd" -defterm -here -no-start -ucrt64 -c "python -X utf8 tools/build.py"`, samma väg som RUNKINATOR och VULVA. Om en tidigare körning lämnat en trasig `.venv-windows` ("finns men saknar Python"): byt namn på mappen och kör igen.

Resultat: `build/bin/SVETTAN_3000.vst3`. Kopiera hela bundle-mappen till `C:\Program Files\Common Files\VST3\` (`.\bygg-vst3-windows.ps1 --install` gör det, men kräver ett PowerShell som körs som administratör).

## Linux

Krav (Debian/Ubuntu): `python3-venv git make g++`.

```bash
chmod +x bygg-vst3-linux.sh
./bygg-vst3-linux.sh
```

Resultat: `build/bin/SVETTAN_3000.vst3`. Kopiera bundle-mappen till `~/.vst3/` (`./bygg-vst3-linux.sh --install`).

## I DAW:n

- **MIDI:** kanal 16 och den delade kanal 1. Sex röster (sex gubbar); den sjunde tonen tar den äldsta gubben. Sustainpedalen (CC64) är ISVAK. CC-mappningen finns i `README.md`.
- **Björkriset:** följer DAW:ns transport (start, stopp, fortsätt och tempo, sex klockpulser per steg). Parametern `start` kör det fritt i sitt eget tempo.
- **Björkrisets steg** är parametrarna `kv0`–`kv15` (0 vila, 1 smisk, 2 hård smisk) och sparas med projektet.
- **KASTA** är en parameter: när den går från 0 till 1 kastas vatten på stenarna. Automatisera den som en puls.

## Viktigt

- Kör bygget på målplattformen. En Linux-VST3 är inte en Windows- eller macOS-binär.
- Första bygget hämtar DPF på en låst commit och installerar låst hvcc (`requirements.lock`) i projektets `.venv`.
- Motorn byggs utan SIMD (`HV_SIMD_NONE`) så att den låter exakt som webbversionen på alla plattformar.
- Interna plugin-ID:n är `Erks`/`Svet`.
