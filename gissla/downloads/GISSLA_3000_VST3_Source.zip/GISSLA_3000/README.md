# GISSLA 3000

Trummaskinen i PASTORNS GODBITAR. Källarvalvet under koret: åtta bröder knäböjer med nakna ryggar och gisslar sig i takt, kyrkvaktmästaren svänger rökelsekaret, klockrepet hänger ned från valvet, den helige Sebastian ser ned från glasfönstret och Pastor Gregorius ser på från sin ikon. Ryggarna är trummorna, och varje tänt steg är ett rött rapp.

Ljudet är PlugData-patcharna i den här mappen och kompileras med hvcc, precis som PERKELE, TURBOTUTTI och SVETTILAINEN. Webbsidan i `web/` är valvet runt motorn.

```
gissla.pd  →  hvcc  →  C  →  Emscripten  →  gissla-engine.js  →  AudioWorklet (web/worklet.js)
           →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Intel + Apple Silicon), Windows och Linux
```

## Ljudet: kroppar, klockor och ett valv

Allt är syntetiskt (inga samples). Kroppsljuden är brus och klick genom filter och stämda resonatorer; klockorna är modalsyntes (en bank `bp~` per klocka, Q satt från avklingningstiden). Allt stämt ligger i **c-moll** (C D Ess F G Ass B). Det finns ingen TONART-ratt; `tune` finns i motorn bara för ÄLSKOGs tonartsval.

| Spår | Röst | Ljud | Stämning |
| --- | --- | --- | --- |
| KÖTT · KICK | 0 | Ett hjärtslag i stenen: en sinus som faller från G2 till C2, en köttig smäll och en mjuk knack. Mättas med en kubisk kurva, som bara ger tredje övertonen. | C2 (G3) |
| PISKA | 1 | Gisslet: en knall, en brusstöt och rappet över ryggen (brus genom ett filter som sveper ned), med ryggens kropp under. Accent ger ett dubbelt rapp. | kroppen G3 och D4 |
| HANDFLATA | 2 | En handflata mot naken hud. Accent är tre flammor, som när brödraskapet applåderar. | kroppen Ess3 och Ess4 |
| RÖKELSE · HIHAT | 3, 4 | Kedjan klirrar (glesa stötar i fyra höga moder) och röken pyser. Ett ryck (3) stryper svingen (4), som har pendelns tremolo. | G7 B7 C8 Ess8 |
| SANCTUS | 5 | Tre altarklockor slagna efter varandra; accent skakar dem en gång till. | C6 Ess6 G6, med duodecimor |
| KYRKKLOCKA | 6 | En kyrkklocka: hum, prim, den lilla tersen som varje kyrkklocka har, kvint, nominal med en svävande dubblett, och högre deltoner. | C2 C3 Ess3 G3 C4 F4 G4 C5 Ess5 |
| ANDE | 7 | Flämtande andetag: brus genom tre formanter, varannan gång ut (”hhaa”) och varannan in (”hhii”). | ostämt |
| KÖR · HAH! | 8 | Brödraskapet ropar: ett hest H och ett A från tio röster genom vokalen A:s formanter. | C3 G3 C4 Ess4 G4 |
| SKRIK | 9 | Någon skriker: glider upp från D5 till G5, håller med vibrato och faller till C5. BOTGÖRING spelar det. | D5 G5 C5 |

Efter rösterna kommer **SYND · DRIVE** (på det torra ljudet, och lite in i valvet) och **VALV · REVERB**: förfördröjning, sex kamfilter per sida med mörk dämpning och tre allpassfilter. Efterklangen är 1,4–8 sekunder (5 vid standard), och valvet är en del av ljudet: varje röst skickar olika mycket dit (KÖTT lite, klockorna och kören mycket).

## Rytmen är en procession

- **En slinga på 1–16 steg**, som standard **12 steg i trioler** (12/8, fyra slag om tre), i **72 BPM**.
- **PROCESSION · DELNING**: två, tre eller fyra steg per slag (åttondelar, trioler eller sextondelar). MIDI-klockan ger 12, 8 eller 6 pulser per steg.
- **SKULD · SWING** skjuter vartannat steg; i trioler blir det en haltande procession.
- **NÅD · CHANS**: ett steg kan skonas (dess vanliga slag hörs inte). En accent skonas aldrig. Upp till 60 % vid full NÅD.
- Ett steg är vila, slag eller accent (RÖKELSE: vila, ryck eller sving). Accent är anslag 1, slag 0,72.

## BOTGÖRING · TRUMVIRVEL

Håll inne: slingan tystnar och gisslet virvlar, varje slag 12 % tätare än det förra (från ett steg, högst 300 ms, ned till 24 ms), med ett crescendo, en handflata vart tredje slag och ett flämtande andetag vart fjärde. När virveln är som snabbast skriker någon. Släpp: allt faller tillbaka på ettan. Slingan börjar om på steg 1 samma ögonblick, med ett HAH! från kören (och KÖTT, kyrkklockan och ett rapp om sequencern står still). Fungerar även när sequencern står still. Sustainpedalen (CC64) håller den också.

## Mot RUNKINATOR och PERKELE (mätt 2026-10-18)

RUNKINATOR är en 808 med samples i ett 4/4-rutnät; PERKELE en metallisk verkstad med polymeter; GISSLA ska låta som en procession i ett stenvalv. Alla tre motorerna körda offline med var sitt exempel i sitt eget standardtempo, 8 takter: RUNKINATOR och PERKELE i 128 BPM (sidans exempelsekvens respektive DIISELI med MISSTÄNDNING 0,1), GISSLA i 72 BPM med PROCESSIONEN (NÅD 0,1). Spektrum och tonhöjd ur 5,5 s av mixen, med samma analys som PERKELEs jämförelse. Kör om med `python3 synths/Gissla/tools/jamfor.py`.

| | RUNKINATOR | PERKELE | GISSLA |
| --- | --- | --- | --- |
| Tempo, takt | 128 BPM, 16 sextondelar | 128 BPM, 16 sextondelar | 72 BPM, 12 trioler (12/8) |
| Spektral tyngdpunkt | 282 Hz | 1 161 Hz | 855 Hz |
| Energi under 150 Hz / 150 Hz–1 kHz / 1–5 kHz / över 5 kHz | 91 / 7 / 0,2 / 1 % | 59 / 23 / 13 / 5 % | 54 / 33 / 9 / 3 % |
| Andel av tonhöjdsenergin i c-moll (slump: 58 %) | 60 % | 86 % | 91 % |
| Starkaste tonklasser | G, Gess, Ass | C, G, Dess | C, Ess, G |
| Topp mot bakgrund i halvtonsbanden | 8,6 dB | 11,6 dB | 10,6 dB |
| Slag per sekund | 8,0 | 16,6 | 5,9 |
| Slag på 16-delsrutnätet | 100 % | 100 % | 54 % (bara de som faller på slagen) |
| Slag på triolrutnätet | 67 % (de på slagen) | 35 % | 100 % |
| Takter som är lika med takten före | 100 % | 0 % | 0 % (NÅD) |
| Efterklang: tid från stopp till −40 dB | 0,25 s | 1,15 s | mer än 6 s |

RUNKINATOR är bas och rutnät och upprepar samma takt. PERKELE är plåt och luft, snabb och polymetrisk. GISSLA ligger emellan i ljushet men har mest energi i mellanregistret (kroppar, kör och klockor), har den högsta andelen c-moll av de tre och är den enda vars starkaste tonklasser är molltreklangen (C, Ess, G: kyrkklockans ters). Rytmen är det tydligaste: GISSLA spelar bara på triolrutnätet, i ungefär en tredjedel av PERKELEs täthet, och valvet klingar kvar i sekunder när de andra redan är tysta. Var röst för sig ligger i c-moll (se motortesterna); resten i mixen är brus från piskan, handflatan, andetagen och röken.

## Patcharna

Allt är vanilla-PD och öppnas direkt i PlugData. `gissla.pd` är huvudpatchen. Patcharna skrevs av [tools/generate_patches.py](tools/generate_patches.py), som är läsbar dokumentation av hur de hänger ihop; den skriver över `.pd`-filerna, så kör den bara om du ändrar där i stället för i PlugData.

| Fil | Vad |
| --- | --- |
| `gissla.pd` | Parametrarna (`@hv_param`) → `gs_*`, utjämnade signaler för SYND, VALV och VOLYM, slingans tabell, alla delpatchar och `dac~`. |
| `GS_Seq.pd` | Processionen: klocka (metro, MIDI-klocka, DAW-tempo via `__hv_dpf_bpm`), PROCESSION, SKULD, NÅD, accent och ettan efter BOTGÖRING. |
| `GS_Gest.pd` | BOTGÖRING: virveln, crescendot, skriket och fallet på ettan. |
| `GS_Notes.pd` | GM-trumnoter på kanal 3 och delade kanal 1. |
| `GS_CC.pd` | CC på kanal 3 och 1 (se nedan). |
| `GS_Hit.pd` | Alla slag (`röst anslag`) → rätt röst, och `ev_hit` ut. |
| `GS_Kott.pd`, `GS_Piska.pd`, `GS_Hud.pd`, `GS_Rokelse.pd`, `GS_Sanctus.pd`, `GS_Klocka.pd`, `GS_Ande.pd`, `GS_Kor.pd`, `GS_Skrik.pd` | Rösterna. |
| `GS_FX.pd` | SYND, VALV, VOLYM och mjuk begränsare. |

### Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `kott` | 0–1 | 0,5 | KÖTT · KICK · CC16 |
| `snart` | 0–1 | 0,45 | SNÄRT · PISKANS DECAY · CC17 |
| `hud` | 0–1 | 0,4 | HUD · HANDFLATA · CC18 |
| `rokelse` | 0–1 | 0,4 | RÖKELSE · HIHAT · CC19 |
| `klocka` | 0–1 | 0,5 | KLOCKA · EFTERKLANG (SANCTUS och KYRKKLOCKA) · CC20 |
| `flock` | 0–1 | 0,5 | FLOCK · KÖRENS STORLEK (och andetagens längd) · CC21 |
| `skuld` | 0–1 | 0 | SKULD · SWING · CC22 |
| `nad` | 0–1 | 0,1 | NÅD · CHANS · CC23 (upp till 60 % skonade steg) |
| `delning` | 0–2 | 1 | PROCESSION · DELNING · CC24 (0–42 åttondelar, 43–85 trioler, 86–127 sextondelar) |
| `synd` | 0–1 | 0,25 | SYND · DRIVE · CC25 |
| `valv` | 0–1 | 0,55 | VALV · REVERB · CC26 (efterklang 1,4–8 s) |
| `volume` | 0–1 | 0,8 | VOLYM · CC7 |
| `bpm` | 30–300 | 72 | CC14 (samma skala som RUNKINATOR) |
| `start` | 0/1 | 0 | Play · CC15 |
| `botgoring` | 0/1 | 0 | BOTGÖRING, hålls · CC80 och CC64 (64–127 håller) |
| `len` | 1–16 | 12 | slingans längd · CC102 |
| `tune` | −6–5 | 0 | ingen ratt: halvtoner för ÄLSKOGs tonartsval |
| `step0`–`step15` | 0–6560 | PROCESSIONEN | alla åtta spår i ett tal: spår *t* är `int(kod / 3^t) % 3` (0 vila, 1 slag, 2 accent; RÖKELSE 1 ryck, 2 sving) |

CC120 och CC123 tystar allt och släpper BOTGÖRING.

### MIDI-noter (kanal 3 och 1)

GM: 35/36 KÖTT, 38/40 PISKA, 39 HANDFLATA (37 mjukt), 42/44/54 RÖKELSE ryck, 46 RÖKELSE sving, 81 SANCTUS (80 mjukt), 53/49 KYRKKLOCKA, 70 ANDE (69 mjukt), 79 KÖR · HAH!, 78 SKRIK. Noter av ignoreras.

### Händelser ut

| Send | Värden |
| --- | --- |
| `ev_hit` | röst 0–9, anslag 0–1 |
| `ev_step` | stegräknare (sedan start; steget är `räknare % len`) |
| `ev_botgoring` | 1 hålls, 2 skriket, 0 tillbaka på ettan |
| `ev_spare` | 1 när NÅD skonar ett steg |

## Webbsidan

- **Valvet** skalas som en bild och reflowar aldrig. På telefon i liggande läge fyller den höjden.
- **Bröderna** är trummorna: KÖTT, PISKA, HANDFLATA, RÖKELSE, SANCTUS, KLOCKA, ANDE och KÖR (A S D F G H J K). En rygg spelar och väljer sitt spår för stegraden. **Kyrkvaktmästaren** svänger rökelsekaret (RÖKELSE sving) och **klockrepet** ringer i kyrkklockan.
- **Stegen** är hud: ett klick ger ett rapp, två ett dubbelt (accent). **LEN** och sedan ett steg sätter slingans längd.
- **Psalmtavlan** har fyra slingor (1–4): 69 PROCESSIONEN (12 trioler), 13 MISERERE (6 trioler, långsamt), 666 DIES IRAE (16 sextondelar, mer SYND) och 40 FLAGELLANTERNA (9 trioler). Alla har bara vila, slag och accent, så allt ligger i c-moll.
- **BOTGÖRING**: håll knappen eller B. Mellanslag spelar.
- **Kugghjulet**: spela exempel, rensa slingan, spara och öppna session (JSON), Anslut MIDI, installera app, helskärm, MIDI-mappning och VST3-nedladdningar.
- Allt sparas automatiskt i webbläsaren.
- **MIDI**: ensam på sidan tar den emot alla kanaler. Inne i ÄLSKOG lyssnar den bara på 3 och 1. MIDI-klocka styr sequencern i motorn, och displayen visar `SYNKAD`.
- **iPhone**: ljudet spelas även med ljudlös-knappen på (`navigator.audioSession`).

### Värdkroken `window.gissla`

Samma form som `window.perkele`, för ÄLSKOG och för testerna. Tiderna är AudioContext-sekunder när ljudet hörs.

```js
window.gissla.ensureAudio();
window.gissla.update('start', 1);        // samma väg som rattarna; även 'bpm', 'tune', 'len', 'delning', 'botgoring'
window.gissla.update('bpm', 90); window.gissla.update('tune', 3);
window.gissla.values;                    // {kott, snart, …, volume, len, bpm, tune, start, botgoring}
window.gissla.addEventListener('hit', (e) => e.detail);        // {voice, track, name, velocity, note, time}
window.gissla.addEventListener('step', (e) => e.detail);       // {count, step, time}
window.gissla.addEventListener('pump', (e) => e.detail);       // {time, depth}: varje KÖTT
window.gissla.addEventListener('botgoring', (e) => e.detail);  // {phase, time}; 'spare' när NÅD skonar
window.gissla.setTempo(72); window.gissla.start(); window.gissla.stop();
window.gissla.hit(6, 110);               // röst 0–9 eller dess namn
window.gissla.botgoring(true); window.gissla.botgoring(false);
window.gissla.setPattern({rows, len}); window.gissla.pattern; window.gissla.loadPsalm(2);
window.gissla.node; window.gissla.context; window.gissla.ready;
```

## Bygga

```bash
source ~/emsdk/emsdk_env.sh
python3 tools/build_gissla.py                 # webben → synths/Gissla/web/dist
python3 tools/build_gissla.py --kit           # även byggkitet i web/downloads
python3 tools/build_gissla.py --vst3          # byggkit + Linux-VST3, byggd genom att köra kitet (kräver dep/dpf)
python3 tools/build_gissla.py --publish DIR   # kopiera den färdiga sidan till DIR, t.ex. runken.nu/gissla
```

## Testa

```bash
python3 -m unittest tests.test_gissla        # motorn: c-moll, röster, trioler, NÅD, SKULD, BOTGÖRING, valvet, klocka, CC
python3 tests/run_gissla_web.py               # sidan i headless Chromium, desktop och telefon, med riktigt ljud
python3 tests/run_vst3_host.py GISSLA_3000.vst3
```
