# TURBOTUTTE 3000

Blöt, smutsig 303-acidbas i ett hockeyomklädningsrum. Ljudet är PlugData-patcharna i den här mappen och kompileras med hvcc, precis som RUNKINATOR. Webbsidan i `web/` är rummet från `design-system/preview/omkladningsrummet.html`, med prototypens Web Audio-ljud ersatt av den riktiga motorn.

```
turbotutte.pd  →  hvcc  →  C  →  Emscripten  →  turbotutte-engine.js  →  AudioWorklet (web/worklet.js)
               →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Intel + Apple Silicon), Windows och Linux
```

## Patcharna

Allt är vanilla-PD och öppnas direkt i PlugData. `turbotutte.pd` är huvudpatchen.

| Fil | Vad |
| --- | --- |
| `turbotutte.pd` | Rattarnas parametrar (`@hv_param`) → utjämnade signaler (`s~ tt_*`), två röster, effekter, `dac~`. |
| `TT_Voice.pd` | En 303-röst. **Oscillator:** polyBLEP-sågtand med 303:ans kondensatorböj och en fyrkant med hängande topp. **Glid:** RC som landar på ca 60 ms, och GLIDTID kan sträcka den. **Filter som en diodstege:** överstyrd ingång (Devil Fish), resonant 2-pol (två `cpole~`), mättning och sedan 1-pol vid fc och 2fc. **Övrigt:** filterkuvert, accentsvep som laddar upp vid täta accenter, VCA med 1 ms anslag och en klick-topp på accenten. **TACKLING** går från varm till nästan fyrkantig RAT-klippning. Basen dras ur före klipparen och kommer tillbaka ren bredvid, och allt ligger före VCA:n så att accenterna behåller sin punch. |
| `TT_Seq.pd` | 16-stegsslingan med 303:ans grammatik: glid håller grinden in i nästa steg, annars 55 % grindtid. Längd och swing. Följer DAW:ns transport och MIDI-klocka (start/fortsätt/stopp, 24 ppqn = sex pulser per steg, DAW-tempo via `__hv_dpf_bpm`). Röst 0. |
| `TT_Mono.pd` | MIDI-toner på kanal 15 och den delade kanal 1. Monofon, senaste tonen gäller, överlapp = glid, släpp = tillbaka till den tangent som fortfarande hålls, anslag ≥ 100 = accent. Röst 1. |
| `TT_CC.pd` | Seriens CC-banker (se nedan) på kanal 15 och 1. |
| `TT_Cold.pd` | ISKALL DUSCH: medan den hålls faller cutoff till 70 Hz på 120 ms. Vid släpp sveper den upp till 7 kHz på 90 ms och sjunker tillbaka till rattens värde på 0,7 s. |
| `TT_FX.pd` | Kakelrum (fyra dämpade kamfilter och två allpass per sida), eko (punkterad åttondel, ping-pong), volym och mjuk begränsare. |

Två röster gör att man kan jamma på bänken ovanpå slingan, precis som i prototypen.

### Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `cutoff` | 0–1 | 0,35 | HANDDUK · CC74 |
| `resonance` | 0–1 | 0,7 | ÅNGA · CC71 |
| `envmod` | 0–1 | 0,6 | SVETT · CC16 |
| `decay` | 0–1 | 0,4 | DUSCHTID · CC17 |
| `accent` | 0–1 | 0,8 | SNÄRT · CC18 |
| `drive` | 0–1 | 0,45 | TACKLING · CC77 |
| `cold` | 0/1 | 0 | ISKALL DUSCH · CC19 (64–127 = håll) |
| `bpm` | 30–300 | 128 | CC14 (samma skala som RUNKINATOR). Webbsidan och exemplet startar på 120. |
| `start` | 0/1 | 0 | Play · CC15 |
| `wave` | 0–1 | 0 | Basskåpet / V · CC70 (såg → fyrkant) |
| `tune` | −12–12 | 0 | TUUTTI · TONART · CC21, halvtoner (displayen visar tonnamnet) |
| `volume` | 0–1 | 0,8 | PUBLIKKI · VOLYM · CC7 |
| `room` | 0–1 | 0,2 | CC91, kakelrum |
| `echo` | 0–1 | 0 | CC92 |
| `length` | 1–16 | 16 | CC20, slingans längd |
| `swing` | 0–1 | 0 | CC22 |
| `slide` | 0–1 | 0,35 | CC5, glidtid (8–130 ms tidskonstant; 0,35 ≈ 303) |
| `step0`–`step15` | 0–511 | prototypens slinga | kod = ton+12 + 64·grind + 128·accent + 256·glid (ton i halvtoner över C2) |

CC123 och CC120 tystar och glömmer alla hållna toner.

### Händelser ut

| Send | Värden |
| --- | --- |
| `ev_note` | röst (0 = slingan, 1 = bänken/MIDI), MIDI-ton, accent, glid |
| `ev_off` | röst |
| `ev_step` | steg 0–15 |

Webbsidan gör om dem till `window.turbotutte`-händelser med ljudklockans tid:

```js
window.turbotutte.addEventListener('note', (e) => e.detail); // {note, accent, slide, time, voice}
window.turbotutte.update('cutoff', .6); // samma väg som rattarna
```

## Webbsidan

- **Rummet** skalas som en bild och reflowar aldrig. På telefon i liggande läge fyller det höjden.
- **Bänken** tar flera fingrar samtidigt. Två fingrar ger glid, och ett finger som dras längs bänken glider ton för ton.
- **Skåpen** är slingbanker: SNÄRTARN, ÅNGAN och TUTTEN har åtta slingor var. Öppna en dörr och välj slinga med en planka på bänken, eller tryck 1–8. Under uppspelning byter den när varvet är slut, som på en 303. SNÄRTARN har åtta färdiga acidslingor.
- **TUUTTI** och **PUBLIKKI** sist i ratt-raden är tonart och volym, som TUNING och VOLUME på en 303. TUUTTI går i hela halvtoner och displayen visar tonen (C, C#, …).
- **Exempelslingan** går i c-moll på 120 BPM, samma tonart och tempo som SVETTANs exempel, så att de låter ihop från start. Motorns standard för `bpm` är kvar på 128 så att befintliga DAW-projekt inte ändras; i en DAW styr transporten ändå tempot.
- **Basskåpet** (dörren med högtalaren) och `V` byter mellan sågtand och fyrkant.
- **Kugghjulet**: exempelslinga, rensa slinga, spara och öppna session (JSON med alla skåp och rattar), Anslut MIDI, installera app, helskärm, MIDI-mappning och VST3-nedladdningar.
- Allt sparas automatiskt i webbläsaren.
- **MIDI**: ensam på sidan tar den emot alla kanaler. Inne i ÄLSKOG lyssnar den bara på 15 och 1. MIDI-klocka (start, fortsätt, stopp och 24 ppqn) styr slingan i motorn, och LCD:n visar `SYNKAD`. Med SKRIV på skriver keyboardet in steg.
- **Byggkit**: kugghjulet länkar `TURBOTUTTE_3000_VST3_Source.zip`, med patcharna och `bygg.command` (Mac), `bygg-vst3-windows.ps1` (MSYS2) och `bygg-vst3-linux.sh`. Det har samma stuk som RUNKINATOR och VULVA; se `kit/BUILD-VST3.md`.

## Bygga

```bash
source ~/emsdk/emsdk_env.sh
python3 tools/build_turbotutte.py                 # webben → synths/Turbotutte/web/dist
python3 tools/build_turbotutte.py --kit           # även byggkitet i web/downloads
python3 tools/build_turbotutte.py --vst3          # byggkit + Linux-VST3, byggd genom att köra kitet (kräver dep/dpf)
python3 tools/build_turbotutte.py --publish ../Hemsidor/Runken.nu/landing/turbotutte-test
```

## Testa

```bash
python3 -m unittest tests.test_turbotutte        # motorn: slingan, mono/glid, accent, CC, ISKALL DUSCH, klocka, glidtid, tonart, volym
python3 tests/run_turbotutte_web.py               # sidan i headless Chromium, desktop och telefon
```
