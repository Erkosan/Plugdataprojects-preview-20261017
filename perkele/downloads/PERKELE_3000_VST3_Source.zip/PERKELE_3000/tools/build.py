#!/usr/bin/env python3
"""PERKELE 3000 byggkit: låsta verktyg, hvcc-export och VST3-bygge på den här datorn.

    python3 tools/build.py            # VST3 i build/bin/PERKELE_3000.vst3
    python3 tools/build.py --install  # och kopiera den till systemets VST3-mapp

Samma upplägg som RUNKINATOR: första körningen skapar en .venv med låst hvcc och hämtar
DPF på en låst commit. Kör på målplattformen (macOS, Windows/MSYS2 UCRT64 eller Linux).
"""
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import time

ROOT = Path(__file__).resolve().parents[1]
NAME = 'PERKELE_3000'
PINS = {'dpf': ('https://github.com/DISTRHO/DPF.git', '4238e1c7f0351bbe488d79f0899c540543ac7583')}
PATCHES = ['perkele.pd', 'PK_Seq.pd', 'PK_Notes.pd', 'PK_CC.pd', 'PK_Hit.pd', 'PK_Gest.pd', 'PK_Startti.pd', 'PK_Dack.pd', 'PK_Huv.pd', 'PK_Luft.pd', 'PK_Nyckel.pd', 'PK_Fat.pd', 'PK_Skiva.pd', 'PK_FX.pd']


def run(args, cwd=ROOT, env=None):
    print('+', ' '.join(map(str, args)), flush=True)
    started = time.monotonic()
    process = subprocess.Popen(list(map(str, args)), cwd=cwd, env=env)
    while True:
        try:
            result = process.wait(timeout=30)
            if result:
                raise subprocess.CalledProcessError(result, args)
            print(f'  Klart ({time.monotonic() - started:.1f} s)', flush=True)
            return
        except subprocess.TimeoutExpired:
            print(f'  Arbetar fortfarande… {time.monotonic() - started:.0f} s', flush=True)


def ensure_windows_python():
    """MSYS2 UCRT64 står för make/gcc, men hvcc:s hjul kräver vanlig Windows-Python 3.13."""
    if 'mingw' not in (sysconfig.get_config_var('SOABI') or '').lower():
        return
    candidates = []
    if os.environ.get('PERKELE_WINDOWS_PYTHON'):
        candidates.append([os.environ['PERKELE_WINDOWS_PYTHON']])
    launcher = shutil.which('py.exe') or shutil.which('py')
    if launcher:
        candidates.append([launcher, '-3.13'])
    local = os.environ.get('LOCALAPPDATA', '')
    if local:
        candidates.append([str(Path(local) / 'Programs/Python/Python313/python.exe')])
        candidates.append([str(Path(local) / 'Programs/Python/Launcher/py.exe'), '-3.13'])
    candidates.append([str(Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'py.exe'), '-3.13'])
    probe_code = ('import sys,sysconfig; print(int(sys.version_info[:2] == (3,13) and sys.platform == "win32" '
                  'and "mingw" not in (sysconfig.get_config_var("SOABI") or "").lower()))')
    for candidate in candidates:
        try:
            probe = subprocess.run([*candidate, '-c', probe_code], cwd=ROOT, capture_output=True, text=True, timeout=15)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if probe.returncode == 0 and probe.stdout.strip() == '1':
            os.environ['PYTHONUTF8'] = '1'
            print('MSYS2-kompilering + vanlig Windows-Python 3.13:', ' '.join(candidate), flush=True)
            run([*candidate, '-X', 'utf8', str(Path(__file__).resolve()), *sys.argv[1:]])
            sys.exit(0)
    raise RuntimeError('MSYS2-Python kan inte installera pydantic_core. Installera vanlig 64-bitars '
                       'Windows-Python 3.13 med `winget install -e --id Python.Python.3.13`, starta om '
                       'terminalen och kör bygg-vst3-windows.ps1 igen.')


def python_environment():
    try:
        if importlib.metadata.version('hvcc') == '0.17.2':
            return
    except importlib.metadata.PackageNotFoundError:
        pass
    venv = ROOT / ('.venv-windows' if sys.platform == 'win32' else '.venv')
    python = venv / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    if not python.is_file():
        if venv.exists():
            raise RuntimeError(f'{venv} finns men saknar Python. Byt namn på mappen och kör igen.')
        run([sys.executable, '-m', 'venv', venv])
    if Path(sys.prefix).resolve() == venv.resolve():
        raise RuntimeError('hvcc saknas eller har fel version i ' + str(venv))
    pip = [str(python), '-m', 'pip', 'install', '-r', str(ROOT / 'requirements.lock')]
    if sys.platform == 'win32':
        pip[4:4] = ['--prefer-binary', '--only-binary=pydantic_core']
    run(pip)
    os.environ['PYTHONUTF8'] = '1'
    if sys.platform == 'win32':
        run([str(python), '-X', 'utf8', str(Path(__file__).resolve()), *sys.argv[1:]])
        sys.exit(0)
    os.execv(str(python), [str(python), str(Path(__file__).resolve()), *sys.argv[1:]])


def dependencies():
    (ROOT / 'dep').mkdir(exist_ok=True)
    for name, (url, commit) in PINS.items():
        path = ROOT / 'dep' / name
        if not path.exists():
            run(['git', 'clone', url, path])
            run(['git', 'checkout', '--detach', commit], cwd=path)
        actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path, text=True).strip()
        if actual != commit:
            raise RuntimeError(f'{name}: väntade {commit}, hittade {actual}; mappen lämnas orörd')
    run(['git', 'submodule', 'update', '--init', '--recursive'], cwd=ROOT / 'dep/dpf')


def export():
    for name in PATCHES + ['metadata.json']:
        if not (ROOT / name).is_file():
            raise RuntimeError(f'Källfil saknas: {name}')
    build = ROOT / 'build'
    if (build / 'plugin').exists():
        shutil.rmtree(build / 'plugin')
    build.mkdir(exist_ok=True)
    metadata = json.loads((ROOT / 'metadata.json').read_text(encoding='utf-8'))
    # hvcc:s Makefile sätter ../../ framför dpf_path från plugin/source, alltså relativt build/.
    metadata['dpf']['dpf_path'] = os.path.relpath(ROOT / 'dep', build).replace(os.sep, '/') + '/'
    meta = build / 'metadata.build.json'
    meta.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    hvcc = Path(sys.executable).parent / ('hvcc.exe' if os.name == 'nt' else 'hvcc')
    if not hvcc.is_file():
        hvcc = Path(shutil.which('hvcc') or '')
        if not hvcc.is_file():
            raise RuntimeError('Hittar inte hvcc')
    run([hvcc, ROOT / 'perkele.pd', '-o', build, '-n', 'perkele', '-m', meta, '-g', 'dpf',
         '--copyright', 'PERKELE 3000. Creator: Pastor Gregorius. Generated using hvcc.'])


def compile_plugin(jobs):
    env = dict(os.environ)
    # Ingen SIMD: exakt samma sampel-för-sampel-motor som webbversionen.
    flags = ['-DHV_SIMD_NONE']
    if sys.platform == 'darwin':
        # En bundle för både Intel och Apple Silicon.
        flags += ['-arch', 'x86_64', '-arch', 'arm64', '-mmacosx-version-min=10.15']
        env['LDFLAGS'] = (env.get('LDFLAGS', '') + ' -arch x86_64 -arch arm64').strip()
    env['CFLAGS'] = (env.get('CFLAGS', '') + ' ' + ' '.join(flags)).strip()
    env['CXXFLAGS'] = (env.get('CXXFLAGS', '') + ' ' + ' '.join(flags)).strip()
    command = ['make', f'-j{jobs}', 'vst3']
    if sys.platform == 'win32':
        command.append('EXTRA_UI_LIBS=-lws2_32 -lshell32 -lole32 -luuid')
    run(command, cwd=ROOT / 'build/plugin/source', env=env)
    bundle = ROOT / 'build/bin' / f'{NAME}.vst3'
    if not bundle.is_dir():
        raise RuntimeError(f'Bygget gav ingen {bundle}')
    if sys.platform == 'darwin' and shutil.which('codesign'):
        # Ad hoc-signatur så att Apple Silicon och Gatekeeper accepterar ett lokalt bygge.
        run(['codesign', '--force', '--deep', '--sign', '-', bundle])
    return bundle


def install(bundle):
    if sys.platform == 'darwin':
        target = Path.home() / 'Library/Audio/Plug-Ins/VST3'
    elif sys.platform == 'win32':
        target = Path(os.environ.get('CommonProgramFiles', r'C:\Program Files\Common Files')) / 'VST3'
    else:
        target = Path.home() / '.vst3'
    target.mkdir(parents=True, exist_ok=True)
    dest = target / bundle.name
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(bundle, dest)
    print('Installerad i', dest)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--install', action='store_true', help='kopiera VST3:an till systemets VST3-mapp')
    parser.add_argument('--prepare-only', action='store_true', help='generera källkoden utan att kompilera')
    parser.add_argument('-j', '--jobs', type=int, default=min(os.cpu_count() or 2, 4))
    args = parser.parse_args()
    ensure_windows_python()
    python_environment()
    dependencies()
    export()
    if args.prepare_only:
        print('Källkoden finns i build/plugin/source.')
        return
    bundle = compile_plugin(args.jobs)
    if args.install:
        install(bundle)
    print(f'\nKlart: {bundle}')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        sys.exit(error.returncode)
    except (OSError, ValueError, RuntimeError) as error:
        sys.exit(str(error))
