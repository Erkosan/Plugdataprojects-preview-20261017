#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 tools/build.py "$@"
printf '\nKlart. Linux VST3 finns i build/bin/PERKELE_3000.vst3.\n'
