# PERKELE 3000

Trummaskinen i SAUNASARJA. En finsk bilverkstad (korjaamo) en vinterkväll: en rostig Lada står på pallbockar, mekanikern Pertti ligger under den och radion står på. Verktygen på Perttis verktygstavla är trummorna. Slår han sig på tummen blir det tyst ett ögonblick och sedan kommer en arg fill. Vrider man om nyckeln drar startmotorn runt, hostar och tänder på nästa etta.

Ljudet är PlugData-patcharna i den här mappen och kompileras med hvcc, precis som TURBOTUTTE och SVETTAN. Webbsidan i `web/` är verkstaden runt motorn.

```
perkele.pd  →  hvcc  →  C  →  Emscripten  →  perkele-engine.js  →  AudioWorklet (web/worklet.js)
            →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Intel + Apple Silicon), Windows och Linux
```

## Ljudet: plåt och mekanik, inte en 808

Varje röst är en kort stöt (ett klick, en dunk eller en brusstöt) som får en bank av **stämda resonatorer** att ringa: `bp~` med Q satt från en avklingningstid och förstärkningen normerad, så att en stöt ringer lika starkt oavsett hur länge den klingar. Resonatorerna är stämda i **C och ligger i c-moll** (C D Ess F G Ass B), som resten av serien. Det finns ingen TONART-ratt: allt är i C. Trummorna blir halvt melodiska och ligger ihop med TURBOTUTTE och SVETTAN.

| Spår | Röst | Ljud | Stämning |
| --- | --- | --- | --- |
| DÄCK · KICK | 0 | Ett däck som släpps i betonggolvet: en dov gummidunk, betongsmäll, och med högt DÄCKTRYCK en studs. Inget tonhöjdssvep. | C2, med G2, C3 och en knack i C4 |
| MOTORHUV · SNARE | 1 | Huven som slås igen: låset klickar, plåten dånar, skrammel. | G3 B3 Ess4 G4 C5 F5 |
| TRYCKLUFT · HIHAT | 2, 3 | Luftpistolens pys och höga plåtmoder. Stängd (2) stryper öppen (3); den öppna pyser nedåt. | C7 G7 Ess8 |
| SKIFTNYCKEL · CLAP | 4 | Nyckeln slår tre gånger mot plåten (handklappens flammor) och ringer som en stav. | C5 G6 Ess7 |
| OLJEFAT · TOM | 5 | Ett 200-litersfat: dunk och plåtring, längre ju tommare fatet är. | C3 med kvint, oktav, duodecima och dubbeloktav; GM-noterna ger G2 B2 C3 Ess3 F3 G3 |
| BROMSSKIVA · COWBELL | 6 | En stålskiva som ringer i ett ackord, lätt ostämd. | C5 Ess5 G5 B5 D6 G6 |

Efter rösterna kommer **PUMP** (allt utom DÄCK duckar för kicken), **ROSTI** (drive), **RADIO** (bandpass, sampel-och-håll och knaster) och **VERKSTAD · RUM**: korta metalliska reflexer från kamfilter stämda på C4 Ess4 G4 B4, så att verkstaden ringer i c-moll.

## Rytmen är en motor

- **Sex spår med egen längd** (polymeter, 1–16 steg). Standardslingan DIISELI har OLJEFAT på 12 steg, så den vandrar mot de andra.
- **VARVTAL**: halvfart, normal, dubbelfart (även med MIDI-klocka: 12, 6 eller 3 pulser per steg).
- **MISSTÄNDNING · CHANS**: steg tappas (cylindern missar) eller kommer igen en 32-del senare (baktändning), som en kall Lada.
- **HUMPPA**: 2/4-oompah. DÄCK tar slagen (accent på ettan) och MOTORHUV offbeats; de andra spåren går vidare.
- **KOSSU · SWING** och **SLÄGGA · ACCENT** (ett steg är vila, slag eller accent; TRYCKLUFT: vila, stängd eller öppen).

## Gesterna

- **PERKELE!** Pertti slår sig på tummen. Allt choke:as och grinden stänger resten av steget och ett helt steg till. Sedan kommer en arg fill på åtta steg i 32-delar: OLJEFAT springer ner i c-moll (G F Ess C B G), MOTORHUV smäller och allt slutar i ett plåtackord, med ROSTI uppskruvad. Därefter går slingan vidare där den var. Fungerar även när sequencern står still.
- **STARTTI**: startmotorn drar runt (en sågtand som stiger från G1 till C3 och tuffar allt fortare, brus som stiger, ett klick varje steg och hostningar som blir tätare). DÄCK och OLJEFAT tystnar under tiden. På nästa etta tänder den: VROOM (DÄCK, öppen TRYCKLUFT och BROMSSKIVA) och en tomgång i C1 som dör ut på en takt. Står sequencern still väntar den en takt och startar sedan maskinen.

## Patcharna

Allt är vanilla-PD och öppnas direkt i PlugData. `perkele.pd` är huvudpatchen. Patcharna skrevs av [tools/generate_patches.py](tools/generate_patches.py), som är läsbar dokumentation av hur de hänger ihop; den skriver över `.pd`-filerna, så kör den bara om du ändrar där i stället för i PlugData.

| Fil | Vad |
| --- | --- |
| `perkele.pd` | Parametrarna (`@hv_param`) → `pk_*`, utjämnade signaler för mastern, slingans tabell, alla delpatchar och `dac~`. |
| `PK_Seq.pd` | Motorn: klocka (metro, MIDI-klocka, DAW-tempo via `__hv_dpf_bpm`), VARVTAL, swing, MISSTÄNDNING, polymeter, HUMPPA och accent. |
| `PK_Gest.pd` | PERKELE! och STARTTI: räknare, grinden, fillen och en egen metro när sequencern står still. |
| `PK_Startti.pd` | Startmotorns ljud, hostningar och tomgången. |
| `PK_Notes.pd` | GM-trumnoter på kanal 2 och delade kanal 1. |
| `PK_CC.pd` | CC på kanal 2 och 1 (se nedan). |
| `PK_Hit.pd` | Alla slag (`röst anslag förskjutning`) → rätt röst, och `ev_hit` ut. |
| `PK_Dack.pd`, `PK_Huv.pd`, `PK_Luft.pd`, `PK_Nyckel.pd`, `PK_Fat.pd`, `PK_Skiva.pd` | Rösterna. |
| `PK_FX.pd` | PUMP, PERKELE-grinden, ROSTI, RADIO, VERKSTAD · RUM, VOLYM och mjuk begränsare. |

### Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `tire` | 0–1 | 0,5 | DÄCKTRYCK · KICK · CC16 |
| `hood` | 0–1 | 0,45 | MOTORHUV · SNARE · CC17 |
| `air` | 0–1 | 0,4 | TRYCKLUFT · HIHAT · CC18 |
| `wrench` | 0–1 | 0,45 | SKIFTNYCKEL · CLAP · CC19 |
| `barrel` | 0–1 | 0,45 | OLJEFAT · TOM · CC20 |
| `disc` | 0–1 | 0,4 | BROMSSKIVA · COWBELL · CC21 |
| `accent` | 0–1 | 0,5 | SLÄGGA · ACCENT · CC22 (vanliga slag har 1 − 0,4 · SLÄGGA) |
| `misfire` | 0–1 | 0,1 | MISSTÄNDNING · CHANS · CC23 (upp till 33 % tappade och 16 % baktända steg) |
| `rpm` | 0–2 | 1 | VARVTAL · CC24 (0–42 halv, 43–85 normal, 86–127 dubbel) |
| `swing` | 0–1 | 0 | KOSSU · SWING · CC25 |
| `rust` | 0–1 | 0,3 | ROSTI · DRIVE · CC26 |
| `pump` | 0–1 | 0,3 | PUMP · CC27 |
| `radio` | 0–1 | 0 | RADIO · LO-FI · CC28 |
| `room` | 0–1 | 0,3 | VERKSTAD · RUM · CC29 |
| `volume` | 0–1 | 0,8 | VOLYM · CC7 |
| `bpm` | 30–300 | 128 | CC14 (samma skala som RUNKINATOR) |
| `start` | 0/1 | 0 | Play · CC15 |
| `humppa` | 0/1 | 0 | HUMPPA · CC82 (64–127 på) |
| `perkele` | 0/1 | 0 | PERKELE! · CC80 (stigande flank) |
| `startti` | 0/1 | 0 | STARTTI · CC81 (stigande flank) |
| `len0`–`len5` | 1–16 | 16 16 16 16 12 16 | spårens längd · CC102–107 |
| `step0`–`step15` | 0–728 | DIISELI | alla sex spår i ett tal: spår *t* är `int(kod / 3^t) % 3` (0 vila, 1 slag, 2 accent; TRYCKLUFT 1 stängd, 2 öppen) |

CC120 och CC123 tystar allt och glömmer gesterna.

### MIDI-noter (kanal 2 och 1)

GM: 35/36 DÄCK, 38/40 MOTORHUV, 42/44/51 TRYCKLUFT stängd, 46/49 TRYCKLUFT öppen, 39 SKIFTNYCKEL (37 som kantslag), 41 43 45 47 48 50 OLJEFAT (G2 B2 C3 Ess3 F3 G3), 56 BROMSSKIVA. Noter av ignoreras.

### Händelser ut

| Send | Värden |
| --- | --- |
| `ev_hit` | röst 0–6, anslag 0–1, OLJEFATs förskjutning i halvtoner |
| `ev_step` | stegräknare (sedan start; spår *t* står på `räknare % len_t`) |
| `ev_perkele` | 1 tystnad, 2 fillen börjar, 0 slut |
| `ev_startti` | 1 startmotorn drar, 2 en hostning, 3 den tände |
| `ev_start` | 1 när STARTTI startade maskinen själv |
| `ev_misfire` | 1 tappat steg, 2 baktändning |

## Webbsidan

- **Verkstaden** skalas som en bild och reflowar aldrig. På telefon i liggande läge fyller den höjden.
- **Verktygstavlan** är trummorna: DÄCK, MOTORHUV, LUFTPISTOL (stängd), LUFTSLANG (öppen), SKIFTNYCKEL, OLJEFAT och BROMSSKIVA (A S D F G H J). Ett verktyg spelar och väljer sitt spår för stegraden.
- **Stegen**: ett klick ger slag, två accent (TRYCKLUFT: stängd, öppen). **LEN** och sedan ett steg sätter spårets längd.
- **Kassetterna** vid radion: DIISELI, HUMPPA, TANGO och TALVI (1–4). Alla spelar OLJEFAT på C3, så allt ligger i c-moll.
- **PERKELE!** (P, knappen eller Perttis ben), **STARTTI** (T, knappen eller Ladan), **HUMPPA** (U), mellanslag spelar.
- **Kugghjulet**: spela exempel, rensa slingan, spara och öppna session (JSON), Anslut MIDI, installera app, helskärm, MIDI-mappning och VST3-nedladdningar.
- Allt sparas automatiskt i webbläsaren.
- **MIDI**: ensam på sidan tar den emot alla kanaler. Inne i ÄLSKOG lyssnar den bara på 2 och 1. MIDI-klocka styr sequencern i motorn, och displayen visar `SYNKAD`.
- **iPhone**: ljudet spelas även med ljudlös-knappen på (`navigator.audioSession`).

### Värdkroken `window.perkele`

Som `window.svettan` och `window.turbotutte`, för ÄLSKOG och för testerna. Tiderna är AudioContext-sekunder när ljudet hörs.

```js
window.perkele.addEventListener('hit', (e) => e.detail);   // {voice, track, name, velocity, offset, note, time}
window.perkele.addEventListener('step', (e) => e.detail);  // {count, step, time}
window.perkele.addEventListener('pump', (e) => e.detail);  // {time, depth}: varje DÄCK, för att ducka andra maskiner
window.perkele.addEventListener('perkele', (e) => e.detail); // {phase, time}; likadant 'startti' och 'misfire'
window.perkele.update('misfire', .4);   // samma väg som rattarna; även 'bpm', 'start', 'humppa', 'len0'…'len5'
window.perkele.setTempo(126); window.perkele.start(); window.perkele.stop();
window.perkele.hit(5, 110);             // röst 0–6 eller verktygets namn
window.perkele.perkele(); window.perkele.startti();
window.perkele.setPattern({rows, lens, humppa}); window.perkele.pattern; window.perkele.loadCassette(1);
window.perkele.values; window.perkele.node; window.perkele.context; window.perkele.ready;
```

Det finns ingen tonart att sätta: allt är i C.

## Bygga

```bash
source ~/emsdk/emsdk_env.sh
python3 tools/build_perkele.py                 # webben → synths/Perkele/web/dist
python3 tools/build_perkele.py --kit           # även byggkitet i web/downloads
python3 tools/build_perkele.py --vst3          # byggkit + Linux-VST3, byggd genom att köra kitet (kräver dep/dpf)
python3 tools/build_perkele.py --publish DIR   # kopiera den färdiga sidan till DIR, t.ex. runken.nu/perkele
```

## Testa

```bash
python3 -m unittest tests.test_perkele        # motorn: c-moll, röster, polymeter, VARVTAL, MISSTÄNDNING, HUMPPA, PERKELE!, STARTTI, PUMP, klocka, CC
python3 tests/run_perkele_web.py               # sidan i headless Chromium, desktop och telefon, med riktigt ljud
python3 tests/run_vst3_host.py PERKELE_3000.vst3
```
