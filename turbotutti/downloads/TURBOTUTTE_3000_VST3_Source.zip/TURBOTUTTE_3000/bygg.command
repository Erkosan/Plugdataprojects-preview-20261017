#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 tools/build.py "$@"
printf '\nKlart. VST3 finns i build/bin/TURBOTUTTE_3000.vst3 (Intel och Apple Silicon). Tryck Enter för att stänga.\n'
read -r
