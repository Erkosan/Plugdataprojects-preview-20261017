# TAXFREE 3000

Däck 6 på en gungande Finlands-/Polenfärja klockan 03:30 i kuling. Mässingsräcken, vinröd heltäckningsmatta indränkt i spilld Long Drink, klirrande spritbackar, neonskyltar i taxfree-gult och cyan, och en bar-klaviatur som lutar 15 grader i sjögången.

TAXFREE 3000 är den första maskinen i serien **TULLFRI LYCKA (Östersjöfärjan 1991)**. Den kombinerar en 6-rösters dub-chord-synth med en Karplus-Strong flask- och glas-resonator, ett djuphavs-bandeko som gungar i otakt med vågorna, en 16-stegs spritback (rytmisk dub-gate) och den stora gesten MAN ÖVERBORD.

Ljudet är PlugData-patcharna i den här mappen och kompileras med hvcc, precis som RUNKINATOR, TURBOTUTTE och SVETTAN. Webbsidan i `web/` är däck 6 runt motorn.

```
taxfree.pd  →  hvcc  →  C  →  Emscripten  →  taxfree-engine.js  →  AudioWorklet (web/worklet.js)
            →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Intel + Apple Silicon), Windows och Linux
```

## Ljudet

- **Rösterna:** Sex röster med dubbla sågtänder och en sub-oscillator som passerar en vågvikare (**VÅGFYLLA**), ett dub-lågpassfilter (**RÄKBUFFÉ**) med resonans (**DIMMA**), och en flexibel klangansats (**STÖT**) som spänner från korta dub-stötar till långa, svallande mattor.
- **Flaskresonansen:** Varje röst har en egen Karplus-Strong sträng-/flaskresonator med intern kamfilteråterkoppling (**KLIRR** och **SPRITBACK**), stämd i C-mollskalans övertoner. När skrovet kränger i sjön klirrar dessutom lösa flaskor i backarna.
- **Sjögången:** En tung och långsam LFO (**SJÖGÅNG** och **KULING**) simulerar skrovets gungning i kuling. Dyningen modulerar stereobild, cutoff och ekotid fram och tillbaka som vågor mot skrovet.
- **Belysning och dist:** Masterkanalen mättas av **TULLKVOT** (varm drive och soft clipping från maskinrummet) och ryms i heltäckningsmattans nattklubbsakustik (**DISKOTEK**).
- **Reling och svall:** Ett rullande bandeko (**BANDEKO**, återkoppling **SVALL**, taktindelning **RELING**) som driver i otakt med fartygets rullning.
- **Spritbacken:** En 16-stegs gate-sequencer med 16 flaskor (tom, full, accentuerad). Ett klassiskt baktakts-skank med justerbart gungdjup (**GUNG**).
- **Dansgolvet:** En arpeggiator med lägena AV, UPP, NER och SLUMP som plockar genom ackorden.
- **MAN ÖVERBORD:** Fartygets stora gest. En livboj på däck. När den utlöses sugs hela ackordet under vattenytan via en omvänd delay-suction och ett djupt resonerande bubblande lågpassfilter, innan ljudet bryter ytan igen på nästa taktslag med ett friskt stänk.

## Patcharna

Allt är vanilla-PD och öppnas direkt i PlugData. `taxfree.pd` är huvudpatchen. Patcharna skrevs av [tools/generate_patches.py](tools/generate_patches.py), som är läsbar dokumentation av hur de hänger ihop.

| Fil | Vad |
| --- | --- |
| `taxfree.pd` | Rattarnas parametrar (`@hv_param`) → utjämnade signaler (`s~ tf_*`), sex röster, alla delpatchar och `dac~`. |
| `TF_Notes.pd` | MIDI-toner på kanal 4 och delade kanal 1 → ANKARE (håll) → `poly 6 1` → sex röster. Ut: `ev_voice`. |
| `TF_Voice.pd` | En röst (argument 1–6): två sågtänder + sub, vågvikare, Karplus-Strong flaskresonator, dub-filter och STÖT-envelope. |
| `TF_Sjo.pd` | Dyningens LFO, skrovets lutning (±15°), `ev_sjo` i 20 Hz till värden och GUI, samt fasförskjuten våg till ekot. |
| `TF_Klirr.pd` | Stokastiskt flaskklirr vid krängning, stämt i C-moll. Skickar `ev_klirr`. |
| `TF_Seq.pd` | Spritbacken: 16 flasksteg (`g0`–`g15`), baktakts dub-skank, MIDI-klocka och transport. Skickar `ev_step`. |
| `TF_Arp.pd` | Dansgolvets arpeggiator (AV, UPP, NER, SLUMP). Skickar `ev_pluck`. |
| `TF_Overbord.pd` | MAN ÖVERBORD-gesten: omvänd fördröjningsbuffert (`vd~`), undervattens-suction, bubblor och uppdykande. Skickar `ev_overbord`. |
| `TF_CC.pd` | Seriens CC-banker på kanal 4 och 1. |
| `TF_FX.pd` | Heltäckningsmattans nattklubbsreverb, rullande bandeko, masterdrive (TULLKVOT) och volym. |

### Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `rakbuffe` | 0–1 | 0,55 | RÄKBUFFÉ · filter · CC16 |
| `dimma` | 0–1 | 0,35 | DIMMA · resonans · CC17 |
| `vagfyll` | 0–1 | 0,3 | VÅGFYLLA · wavefold · CC18 |
| `stot` | 0–1 | 0,45 | STÖT · dub-stab / decay · CC19 |
| `klirr` | 0–1 | 0,5 | KLIRR · flaskresonans · CC20 |
| `spritback` | 0–1 | 0,6 | SPRITBACK · flaskklangtid · CC21 |
| `tullkvot` | 0–1 | 0,3 | TULLKVOT · drive · CC22 |
| `sjogang` | 0–1 | 0,45 | SJÖGÅNG · svaj · CC23 |
| `kuling` | 0–1 | 0,3 | KULING · dyningens fart · CC24 |
| `eko` | 0–1 | 0,35 | BANDEKO · eko-mängd · CC25 |
| `ekofb` | 0–1 | 0,45 | SVALL · eko-återkoppling · CC26 |
| `ekotid` | 0–3 | 1 | RELING · ekotid (1/8, 3/16, 1/4, 3/8) · CC27 |
| `gung` | 0–1 | 0,7 | GUNG · gate-djup · CC28 |
| `diskotek` | 0–1 | 0,3 | DISKOTEK · rumsklang · CC29 |
| `arp` | 0–3 | 0 | DANSGOLV · arpeggio (AV, UPP, NER, SLUMP) · CC30 |
| `volume` | 0–1 | 0,8 | VOLYM · mastervolym · CC7 |
| `overbord` | 0/1 | 0 | MAN ÖVERBORD · livboj / sjösjuka · CC31 |
| `hold` | 0/1 | 0 | ANKARE · håll ackordet (sustain) · CC64 |
| `bpm` | 30–300 | 100 | Tempo i BPM · CC14 |
| `start` | 0/1 | 0 | Spritbacken spelar · CC15 |
| `length` | 1–16 | 16 | Spritbackens längd |
| `swing` | 0–1 | 0 | Sväng / swing |
| `g0`–`g15` | 0–2 | tabell | Spritbackens 16 steg (0 tom, 1 full, 2 accent) |

CC120 och CC123 tystar alla röster och glömmer hållna toner.

### Händelser ut

| Send | Värden |
| --- | --- |
| `ev_voice` | röst (1–6), MIDI-ton, anslag (0 = tystnar) |
| `ev_sjo` | skrovets krängning/dyning -1..1 (20 Hz) |
| `ev_klirr` | triggas vid flaskklirr under krängning |
| `ev_step` | spritbackens aktiva steg 0–15 |
| `ev_pluck` | arpeggiatorns anslagston |
| `ev_overbord` | 1 när skeppet kränger under ytan, 0 när det bryter ytan |

Webbsidan gör om dem till `window.taxfree`-händelser med ljudklockans tid:

```js
window.taxfree.addEventListener('note', (e) => e.detail);     // {voice, note, velocity, time}
window.taxfree.addEventListener('sjo', (e) => e.detail);      // {tilt, time}
window.taxfree.addEventListener('overbord', (e) => e.detail); // {underwater, time}
window.taxfree.update('rakbuffe', 0.6);
window.taxfree.overbord();
```

## Webbsidan

- **Däck 6:** Fast rityta som skalas med `--zoom` och aldrig reflowar. Hela rummet lutar upp till ±15 grader i takt med dyningen (`ev_sjo`).
- **Spritbacken:** 16 flaskor i en träback. Klicka för att växla mellan tom, full och krossad/accentuerad. Den aktiva flaskan lyser upp i takt med musiken.
- **Bardisken:** Klaviaturen med två oktaver (C3–C5). Mässingskant och barluckor.
- **MAN ÖVERBORD:** En lysande röd livboj. Vid klick eller `ev_overbord` sjunker scenen under vattenytan med blått djup, bubbelanimationer och filter-suction, för att sedan bryta ytan med ett stänk.
- **Kugghjulet:** Spela exempel (dub-ackord med spritbacken igång), nollställ, spara/öppna session, anslut Web MIDI, installera PWA, helskärm och ladda ner VST3.

## Bygga

```bash
source ~/emsdk/emsdk_env.sh
python3 tools/build_taxfree.py                 # webben → synths/Taxfree/web/dist
python3 tools/build_taxfree.py --kit           # byggkitet i web/downloads
python3 tools/build_taxfree.py --vst3          # byggkit + Linux-VST3 (kräver dep/dpf)
```
