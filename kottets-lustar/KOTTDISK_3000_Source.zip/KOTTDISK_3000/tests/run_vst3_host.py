#!/usr/bin/env python3
"""Load built VST3s in a real VST3 host (Pedalboard, which is JUCE) and play them.

    pip install pedalboard mido
    python3 tests/run_vst3_host.py PATH/TO/SVETTAN_3000.vst3 [more .vst3 ...]

For each plugin it checks: it loads as an instrument, plays on its own MIDI channel, is silent
after the notes are released, ignores a channel that is not its own, and that one knob changes
the sound across its full range. The machine is recognised from the plugin name. This runs the
Linux binaries; macOS and Windows builds still need a check in a real DAW on those systems.
"""
import sys

import numpy as np
from mido import Message
from pedalboard import load_plugin

RATE = 48000
# plugin name -> (notes, own MIDI channel, a channel to ignore, knob to sweep)
MACHINES = {
    'KÖTTDISK 3000': ([48, 63, 67], 9, 3, 'disk'),
    'RUNKINATOR 3000': ([36, 38, 42], 10, 14, 'kick_pitch'),
    'VULVA 3000': ([48], 14, None, 'cutoff'),
    'TURBOTUTTE 3000': ([36], 15, 3, 'cutoff'),
    'SVETTAN 3000': ([48, 52, 55, 60], 16, 3, 'vowel'),
}
failures = []


def db(x):
    return 20 * np.log10(max(1e-9, float(np.sqrt(np.mean(x ** 2)))))


def character(x):
    """Brightness and zero crossings of the left channel: either moves when a knob does something."""
    left = x[0]
    bright = float(np.sqrt(np.mean(np.diff(left) ** 2)) / max(1e-9, np.sqrt(np.mean(left ** 2))))
    return bright, int(np.sum((left[:-1] < 0) & (left[1:] >= 0)))


def check(ok, message):
    print(('ok  ' if ok else 'FEL ') + message)
    if not ok:
        failures.append(message)


def play(plugin, notes, channel, seconds=3.0, hold=1.5):
    messages = [Message('note_on', note=n, velocity=100, channel=channel - 1, time=.1) for n in notes]
    messages += [Message('note_off', note=n, velocity=0, channel=channel - 1, time=.1 + hold) for n in notes]
    return plugin(messages, duration=seconds, sample_rate=RATE, num_channels=2, buffer_size=256, reset=True)


def test(path):
    # KÖTTDISK uses raw normalized JUCE parameters to avoid Pedalboard's
    # expensive inference pass over DPF's synthetic MIDI controller parameters.
    from pathlib import Path
    if Path(path).name.lower() in ('kottdisk.vst3', 'kottdisk_3000.vst3'):
        from run_kottdisk_vst3 import HostTests
        suite = HostTests(Path(path).resolve())
        for name in ('identity', 'channels_and_release', 'velocity_and_chord',
                     'hold_pedal_and_panic', 'mapped_cc_state', 'knob_timbre',
                     'midi_sample_offset', 'state_roundtrip', 'extremes_and_cpu'):
            suite.check(name, getattr(suite, name))
        check(all(row['passed'] for row in suite.results), 'KÖTTDISK: verklig VST3-värd')
        return
    plugin = load_plugin(path)
    if plugin.name not in MACHINES:
        check(False, f'{path}: okänd maskin "{plugin.name}"')
        return
    notes, channel, other, knob = MACHINES[plugin.name]
    own = [k for k in plugin.parameters if not k.startswith('midi_ch_')]
    print(f'\n== {plugin.name}: {len(own)} parametrar')
    check(plugin.is_instrument, 'laddas som instrument')
    audio = play(plugin, notes, channel)
    playing = audio[:, int(.1 * RATE):int(.9 * RATE)]
    check(np.isfinite(audio).all() and np.abs(audio).max() <= 1.0, f'ändligt och inom ±1 (topp {np.abs(audio).max():.2f})')
    check(db(playing) > -45, f'låter på kanal {channel} ({db(playing):.1f} dB)')
    check(db(audio[:, -RATE // 4:]) < -60, f'tyst efter släppta toner ({db(audio[:, -RATE // 4:]):.1f} dB)')
    if other:
        check(db(play(plugin, notes, other)) < -60, f'ignorerar kanal {other}')
    low, high = plugin.parameters[knob].range[:2]
    setattr(plugin, knob, low)
    a = character(play(plugin, notes, channel)[:, int(.15 * RATE):int(.9 * RATE)])
    setattr(plugin, knob, high)
    b = character(play(plugin, notes, channel)[:, int(.15 * RATE):int(.9 * RATE)])
    check(abs(a[0] - b[0]) > .02 or abs(a[1] - b[1]) > 2, f'{knob} {low:g} → {high:g} ändrar ljudet (ljushet {a[0]:.3f} → {b[0]:.3f})')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    for path in sys.argv[1:]:
        test(path)
    sys.exit('\nFEL: ' + '; '.join(failures) if failures else 0)
