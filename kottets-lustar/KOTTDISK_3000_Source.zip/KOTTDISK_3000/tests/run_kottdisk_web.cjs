#!/usr/bin/env node
'use strict';
// Real compiled PlugData/hvcc/WASM integration. No engine or audio mocks.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
let chromium;
try { ({ chromium } = require('playwright-core')); }
catch {
  try { ({ chromium } = require('../synths/Kottdisk/node_modules/playwright-core')); }
  catch { ({ chromium } = require('/home/elias/node_modules/playwright-core')); }
}
const ROOT = path.resolve(__dirname, '..');
const DIST = path.join(ROOT, 'synths/Kottdisk/web/dist');
const OUTPUT = path.join(ROOT, 'docs/kottdisk');
const report = { instrument: 'KÖTTDISK 3000', date: new Date().toISOString(), engine: 'Real compiled PlugData/hvcc/WASM', tests: [], audio: {}, errors: { page: [], console: [], requests: [], http: [] }, limitations: ['Chromium/Linux only; Safari, iOS, physical MIDI and DAW hosting need device testing.'] };
const mime = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.css':'text/css','.svg':'image/svg+xml','.txt':'text/plain; charset=utf-8','.zip':'application/zip' };
let server, browser, page;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function test(name, run) {
  const begin = Date.now();
  try { const detail = await run(); report.tests.push({ name, pass: true, duration_ms: Date.now() - begin, ...(detail === undefined ? {} : {detail}) }); console.log('PASS', name); return true; }
  catch (error) { report.tests.push({ name, pass: false, duration_ms: Date.now() - begin, error: error.message }); console.error('FAIL', name, error.message); return false; }
}
async function measure(name, duration = 250) {
  const result = await page.evaluate(async duration => {
    const data = new Float32Array(window.__analyser.fftSize);
    let sum = 0, count = 0, peak = 0, finite = true;
    const until = performance.now() + duration;
    do {
      window.__analyser.getFloatTimeDomainData(data);
      for (const value of data) { finite = finite && Number.isFinite(value); sum += value * value; peak = Math.max(peak, Math.abs(value)); count++; }
      await new Promise(r => setTimeout(r, 15));
    } while (performance.now() < until);
    return { rms: Math.sqrt(sum / count), peak, finite, samples: count };
  }, duration);
  report.audio[name] = result;
  assert(result.finite, `${name}: non-finite sample`);
  assert(result.peak <= 1.01, `${name}: peak ${result.peak} clips`);
  return result;
}
async function update(params) { await page.evaluate(params => { for (const [name, value] of Object.entries(params)) window.kottdisk.update(name, value, {display:false}); }, params); await wait(70); }
async function panic() { await page.evaluate(() => window.kottdisk.panic()); await wait(180); }
(async () => {
  fs.mkdirSync(OUTPUT, { recursive: true });
  let url = process.argv[2];
  if (!url) {
    server = http.createServer((request, response) => {
      let file;
      try { file = path.resolve(DIST, '.' + decodeURIComponent(new URL(request.url, 'http://localhost').pathname)); }
      catch { response.writeHead(400).end(); return; }
      if (!file.startsWith(DIST + path.sep) && file !== DIST) { response.writeHead(403).end(); return; }
      if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
      fs.readFile(file, (error, body) => { if (error) response.writeHead(404).end('Not found'); else response.writeHead(200, {'Content-Type':mime[path.extname(file)] || 'application/octet-stream','Cache-Control':'no-store'}).end(body); });
    });
    await new Promise((resolve, reject) => { server.on('error', reject); server.listen(0, '127.0.0.1', resolve); });
    url = `http://127.0.0.1:${server.address().port}/`;
  }
  report.url = url;
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  page = await browser.newPage({ viewport: { width: 1280, height: 850 }, hasTouch: true, serviceWorkers:'block' });
  const requested = [];
  page.on('pageerror', error => report.errors.page.push(error.message));
  page.on('console', message => { if (message.type() === 'error') report.errors.console.push(message.text()); });
  page.on('requestfailed', request => report.errors.requests.push({url:request.url(),error:request.failure()?.errorText}));
  page.on('request', request => requested.push(request.url()));
  page.on('response', response => { if (response.status() >= 400) report.errors.http.push({url:response.url(),status:response.status()}); });
  // Observe the genuine worklet handshake without replacing its processor or engine.
  await page.addInitScript(() => {
    window.__workletMessages = [];
    const NativeNode = window.AudioWorkletNode;
    window.AudioWorkletNode = class extends NativeNode {
      constructor(...args) { super(...args); this.port.addEventListener('message', event => window.__workletMessages.push(event.data)); this.port.start(); }
    };
  });
  await page.goto(url, { waitUntil:'networkidle' });
  await page.waitForFunction(() => window.kottdisk);
  await test('No eager audio; fixed panel and complete keyboard', async () => {
    assert(await page.evaluate(() => window.kottdisk.engine.context === null && !window.kottdisk.ready));
    assert(!requested.some(url => /worklet\.js|kottdisk-engine\.js/.test(url)));
    assert.equal(await page.locator('[role=slider]').count(), 10);
    assert.equal(await page.locator('.key').count(), 24);
    const size = await page.locator('#instrument').boundingBox(); assert.equal(size.width,1200); assert.equal(size.height,750);
  });
  const started = await test('Gesture starts actual AudioWorklet and embedded WASM', async () => {
    await page.locator('.key[data-note="48"]').click();
    await page.evaluate(() => window.kottdisk.start());
    const ready = await page.evaluate(() => ({ messages:window.__workletMessages, state:window.kottdisk.engine.context.state, node:window.kottdisk.engine.node instanceof AudioWorkletNode }));
    assert.equal(ready.state,'running'); assert(ready.node); assert(ready.messages.some(m => m.type === 'ready' && m.wasm === true && m.engine === 'PlugData/hvcc'));
    const artifact = await page.evaluate(async () => { const r=await fetch('./kottdisk-engine.js'); const s=await r.text(); return {ok:r.ok, embeddedWasm:s.includes('AGFzbQ'), processExport:s.includes('_kd_process')}; });
    assert(artifact.ok && artifact.embeddedWasm && artifact.processExport); // Worklet fetches are outside Page request events in Chromium.
    ready.artifact = artifact;
    await page.evaluate(() => { const e=window.kottdisk.engine; window.__analyser=e.context.createAnalyser();window.__analyser.fftSize=2048;e.node.connect(window.__analyser); });
    report.worklet = ready;
  });
  if (!started) throw new Error('Real audio engine did not initialize; later audio checks cannot run.');
  await panic();
  await update({kd_volume:.65,kd_tone:.65,kd_bite:.35,kd_ratio:.25,kd_attack:0,kd_decay:.2,kd_sustain:.65,kd_release:0,kd_warmth:.1,kd_space:0,kd_hold:0});
  await test('Idle silence', async () => { const a=await measure('idle');assert(a.rms < .00001,`idle RMS ${a.rms}`); });
  await test('Audible note and bounded output', async () => { await page.evaluate(()=>window.kottdisk.noteOn(60,100,1));await wait(150);const a=await measure('note');assert(a.rms > .001,`note RMS ${a.rms}`); });
  await test('Volume parameter changes measured sound', async () => {
    await update({kd_volume:.1});const quiet=await measure('quiet');await update({kd_volume:.8});const loud=await measure('loud');assert(loud.rms>quiet.rms*2,`loud ${loud.rms}; quiet ${quiet.rms}`);
  });
  await test('Brightness and FM change the rendered signal', async () => {
    const spect = () => page.evaluate(() => { const a=window.__analyser,b=new Float32Array(a.frequencyBinCount);a.getFloatFrequencyData(b);let total=0,weighted=0;for(let i=1;i<b.length;i++){const power=Math.pow(10,b[i]/10);total+=power;weighted+=power*i;}return total?weighted/total:0; });
    await update({kd_tone:.12,kd_bite:.05});await wait(120);const dark=await spect();await update({kd_tone:.95,kd_bite:.85});await wait(120);const bright=await spect();report.audio.spectral={dark_bin:dark,bright_bin:bright};assert(Math.abs(bright-dark)>.15,`spectral bins ${dark}, ${bright}`);
  });
  await test('Note-off release reaches silence', async () => { await page.evaluate(()=>window.kottdisk.noteOff(60,1));await wait(1100);const a=await measure('released');assert(a.rms<.0001,`release RMS ${a.rms}`); });
  await panic();await update({kd_volume:.65,kd_tone:.65,kd_bite:.35,kd_release:0,kd_sustain:.7,kd_hold:0});
  await test('Six-note chord sounds and panics to silence', async () => {
    await page.evaluate(()=>[48,55,60,63,67,70].forEach(n=>window.kottdisk.noteOn(n,95,1)));await wait(180);const chord=await measure('chord');assert(chord.rms>.001);await panic();const silent=await measure('panic');assert(silent.rms<.00001,`panic RMS ${silent.rms}`);
  });
  await test('Sustain holds note-off then releases', async () => {
    await page.evaluate(()=>{window.kottdisk.controlChange(64,127,1);window.kottdisk.noteOn(60,100,1);});await wait(150);await page.evaluate(()=>window.kottdisk.noteOff(60,1));await wait(220);const held=await measure('sustain');assert(held.rms>.001,`sustain RMS ${held.rms}`);await page.evaluate(()=>window.kottdisk.controlChange(64,0,1));await wait(1100);const released=await measure('sustain_released');assert(released.rms<.0001,`pedal release RMS ${released.rms}`);
  });
  await panic();
  await test('Host MIDI channel filtering and CC panel synchronization', async () => {
    await page.evaluate(()=>{window.kottdisk.controlChange(16,127,9);window.kottdisk.controlChange(64,127,9);window.kottdisk.controlChange(64,0,2);});
    assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_tone),1);assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_hold),1);
    await panic();await page.evaluate(()=>window.kottdisk.noteOn(60,100,2));await wait(100);const wrong=await measure('wrong_channel');assert(wrong.rms<.00001);
  });
  await test('Computer keyboard chords and accessible knob controls', async () => {
    await page.keyboard.down('a');await page.keyboard.down('d');assert.equal(await page.locator('.key.active').count(),2);await page.keyboard.up('a');await page.keyboard.up('d');assert.equal(await page.locator('.key.active').count(),0);
    await page.locator('#kd_tone').focus();await page.keyboard.press('Home');await page.keyboard.press('ArrowUp');assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_tone),.01);
    await page.locator('#tender').focus();await page.keyboard.down('Space');assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_tender),1);await page.keyboard.up('Space');assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_tender),0);
  });
  await test('Two-touch glissando and captured pointer cleanup', async () => {
    const c=await page.locator('.key[data-note="48"]').boundingBox(),e=await page.locator('.key[data-note="52"]').boundingBox(),d=await page.locator('.key[data-note="50"]').boundingBox();
    const point=(b,id)=>({x:b.x+b.width/2,y:b.y+110,id,radiusX:2,radiusY:2});const client=await page.context().newCDPSession(page);
    await client.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(c,1),point(e,2)]});await wait(40);assert.equal(await page.locator('.key.active').count(),2);
    await client.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[point(d,1),point(e,2)]});await wait(40);assert.equal(await page.locator('.key[data-note="50"].active').count(),1);
    await client.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await wait(40);assert.equal(await page.locator('.key.active').count(),0);await client.detach();
  });
  await test('Menu presets, session validation, export and import', async () => {
    await page.locator('#menu-open').click();await page.selectOption('#presets','glaskropp');assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_bite),.76);
    await page.locator('#save-session').click();const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('kottdisk.session.v1')));assert.equal(saved.version,1);assert.equal(saved.values.kd_bite,.76);
    const downloadEvent=page.waitForEvent('download');await page.locator('#export-session').click();const download=await downloadEvent;assert.equal(download.suggestedFilename(),'kottdisk-3000-session.json');
    const filename=await download.path();const exported=JSON.parse(fs.readFileSync(filename,'utf8'));assert.deepEqual(exported.values,saved.values);
    await page.selectOption('#presets','falukarlek');await page.locator('#session-file').setInputFiles({name:'session.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(saved))});await wait(100);assert.equal(await page.evaluate(()=>window.kottdisk.values.kd_bite),.76);
    const valid=await page.evaluate(()=>{const k=window.kottdisk,s=k.exportSession();let rejected=false;try{k.importSession({...s,values:{...s.values,kd_tone:99}})}catch{rejected=true}return rejected;});assert(valid);
  });
  await test('Host transport gates menu demo and panic stops it', async () => {
    await update({kd_space:0}); // Isolate scheduler/panic from the intentionally ringing room effect.
    await page.evaluate(()=>window.kottdisk.setTransport({bpm:400,playing:false}));await page.locator('#demo').click();await wait(160);const stopped=await measure('demo_waiting');assert(stopped.rms<.0001);
    await page.evaluate(()=>window.kottdisk.setTransport({playing:true}));await wait(200);const running=await measure('demo');assert(running.rms>.001);await panic();const stoppedAgain=await measure('demo_panicked');assert(stoppedAgain.rms<.00001);
  });
  await test('Downloads and required Heavy attribution work in menu', async () => {
    await page.locator('summary').filter({hasText:'Hämta instrumentet'}).click();assert(await page.locator('#downloads a').count()>0,'download manifest has no links');
    for (const href of await page.locator('#downloads a').evaluateAll(links=>links.map(a=>a.href))) { const response=await page.request.head(href);assert(response.ok(),`download unavailable: ${href}`); }
    assert.equal(await page.locator('a[href="https://enzienaudio.com"]').textContent(),'powered by heavy');
  });
  await test('Mobile retains complete panel without reflow or overflow', async () => {
    await page.locator('#menu-close').click();
    await page.setViewportSize({width:390,height:844});
    // Chromium can acknowledge the viewport before dispatching the resize event.
    await page.waitForFunction(() => document.querySelector('#instrument').getBoundingClientRect().width <= innerWidth && document.documentElement.scrollWidth <= innerWidth);
    const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,box:document.querySelector('#instrument').getBoundingClientRect().toJSON()}));assert(geometry.scroll<=geometry.width);assert(Math.abs(geometry.box.width/geometry.box.height-1.6)<.001);return geometry;
  });
  await page.setViewportSize({width:1280,height:850});await page.evaluate(()=>{window.kottdisk.loadPreset('favorit');document.querySelector('#kd_tone').blur();});await wait(1900);
  if (await page.evaluate(()=>document.querySelector('#menu').open)) await page.locator('#menu-close').click();
  await page.screenshot({path:path.join(OUTPUT,'preview.png')});
  await test('No browser, console, HTTP or failed-request errors', async () => { for (const [kind,items] of Object.entries(report.errors)) assert.equal(items.length,0,`${kind}: ${JSON.stringify(items)}`); });
})().catch(error => {report.fatal=error.stack;console.error(error);}).finally(async () => {
  if(browser) await browser.close();if(server) await new Promise(resolve=>server.close(resolve));
  report.pass=!report.fatal&&report.tests.every(t=>t.pass);
  report.summary={passed:report.tests.filter(t=>t.pass).length,failed:report.tests.filter(t=>!t.pass).length};
  fs.mkdirSync(OUTPUT,{recursive:true});fs.writeFileSync(path.join(OUTPUT,'web-tests.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({pass:report.pass,...report.summary,report:'docs/kottdisk/web-tests.json'}));
  if(!report.pass) process.exitCode=1;
});
