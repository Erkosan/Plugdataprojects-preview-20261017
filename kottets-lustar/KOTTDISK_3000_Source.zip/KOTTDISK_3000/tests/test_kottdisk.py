"""Real audio regression tests against the same C engine compiled into WASM/VST3."""
import ctypes as C
import math
from pathlib import Path
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PARAMS=['attack','bite','decay','hold','ratio','release','space','sustain','tender','tone','volume','warmth']
LIB=C.CDLL(str(ROOT/'build/kottdisk/libkottdisk.so'))
LIB.kd_new.argtypes=[C.c_double]; LIB.kd_new.restype=C.c_void_p
LIB.kd_free.argtypes=[C.c_void_p]
LIB.kd_param.argtypes=[C.c_void_p,C.c_int,C.c_float]
LIB.kd_midi.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int]
LIB.kd_process.argtypes=[C.c_void_p,C.POINTER(C.c_float),C.c_int]

def rms(a): return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))

class Synth:
    def __init__(self,sr=48000): self.sr=sr; self.p=LIB.kd_new(sr); self.audio(.03)
    def close(self):
        if self.p: LIB.kd_free(self.p); self.p=None
    def __del__(self): self.close()
    def param(self,name,value): LIB.kd_param(self.p,PARAMS.index(name),value)
    def note(self,note,velocity=100,channel=1): LIB.kd_midi(self.p,0x90|channel-1,note,velocity)
    def cc(self,cc,value,channel=1): LIB.kd_midi(self.p,0xb0|channel-1,cc,value)
    def audio(self,seconds):
        result=np.zeros((math.ceil(seconds*self.sr/128),128,2),np.float32)
        for block in result: LIB.kd_process(self.p,block.ctypes.data_as(C.POINTER(C.c_float)),128)
        return result.reshape(-1,2)

class AudioTests(unittest.TestCase):
    def make(self,sr=48000):
        synth=Synth(sr); self.addCleanup(synth.close); return synth
    def test_start_pitch_release(self):
        s=self.make(); self.assertLess(rms(s.audio(.1)),1e-10)
        s.param('bite',0); s.param('space',0); s.note(60)
        a=s.audio(.5); self.assertGreater(rms(a),.02)
        spectrum=np.abs(np.fft.rfft(a[:,0]*np.hanning(len(a))))
        freq=np.argmax(spectrum)*s.sr/len(a)
        self.assertAlmostEqual(freq,261.626,delta=3)
        s.note(60,0); self.assertLess(rms(s.audio(1)[-4800:]),1e-7)
    def test_velocity_and_polyphony(self):
        levels=[]
        for v in [25,70,127]:
            s=self.make(); s.note(60,v); levels.append(rms(s.audio(.4)))
        self.assertTrue(levels[0]<levels[1]<levels[2],levels)
        s=self.make()
        for n in [48,55,60,63,67,70]: s.note(n)
        a=s.audio(.4); self.assertGreater(rms(a),.06); self.assertLess(np.max(np.abs(a)),.981)
        for n in [48,55,60,63,67,70]: s.note(n,0)
        self.assertLess(rms(s.audio(1)[-4800:]),1e-7)
    def test_channels_and_independent_note_ownership(self):
        for channel in [1,9,2,16]:
            s=self.make(); s.note(60,channel=channel)
            self.assertEqual(rms(s.audio(.3))>.02,channel in [1,9])
        s=self.make(); s.note(60,channel=1); s.note(60,channel=9); s.audio(.2)
        s.note(60,0,1); self.assertGreater(rms(s.audio(.7)),.01)
        s.note(60,0,9); self.assertLess(rms(s.audio(1)[-4800:]),1e-7)
    def test_sustain_collects_notes_and_pedal_up(self):
        s=self.make(); s.param('bite',0); s.param('space',0); s.param('sustain',1)
        s.cc(64,127)
        for n in [60,64]: s.note(n); s.audio(.1); s.note(n,0)
        a=s.audio(.5)[:,0]
        fft=np.abs(np.fft.rfft(a*np.hanning(len(a))))
        for freq in [261.626,329.628]:
            b=int(round(freq*len(a)/s.sr)); self.assertGreater(np.max(fft[b-1:b+2]),20)
        s.cc(64,0); self.assertLess(rms(s.audio(1)[-4800:]),1e-7)
    def test_cc_mute_panic_and_stealing(self):
        s=self.make(); s.note(60); s.audio(.2); s.cc(7,0)
        self.assertLess(rms(s.audio(.2)[-4800:]),1e-10)
        for cc in [120,123]:
            s=self.make(); s.cc(64,127)
            for n in range(48,80): s.note(n)
            s.audio(.3); s.cc(cc,0)
            self.assertLess(rms(s.audio(.6)[-4800:]),1e-7)
    def test_controls_change_sound(self):
        for param in ['tone','bite','ratio','attack','decay','sustain','release','warmth','space','tender']:
            sounds=[]
            for value in [0,1]:
                s=self.make(); s.param(param,value); s.note(60); a=s.audio(.5)
                s.note(60,0); sounds.append(np.concatenate([a,s.audio(.5)]))
            self.assertGreater(rms(sounds[0]-sounds[1]),1e-4,param)
    def test_extremes_are_finite_bounded_and_can_stop(self):
        for sr in [44100,48000,96000]:
            for value in [0,1]:
                s=self.make(sr)
                for name in PARAMS:
                    if name!='hold': s.param(name,value)
                for n in [0,12,36,60,96,127]: s.note(n,127)
                a=s.audio(.8)
                self.assertTrue(np.isfinite(a).all()); self.assertLessEqual(float(np.max(np.abs(a))),.981)
                s.cc(120,0); self.assertLess(rms(s.audio(.6)[-4800:]),1e-7)

if __name__=='__main__': unittest.main(verbosity=2)
