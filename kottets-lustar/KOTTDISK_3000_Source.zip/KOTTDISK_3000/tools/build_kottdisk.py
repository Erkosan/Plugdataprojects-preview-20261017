#!/usr/bin/env python3
"""Reproducible KÖTTDISK build; never reads another worktree or its build outputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'synths/Kottdisk'
BUILD = ROOT / 'build/kottdisk'
DIST = SOURCE / 'web/dist'
DPF_COMMIT = '4238e1c7f0351bbe488d79f0899c540543ac7583'
LABELS = {'attack':'ANSATS', 'bite':'MARMORERING', 'decay':'MÖRHET', 'hold':'LÅT VILA',
          'ratio':'STYCKNING', 'release':'VILA', 'space':'SALUHALL', 'sustain':'KROPP',
          'tender':'MÖRA', 'tone':'DISK', 'volume':'VOLYM', 'warmth':'FETT'}

def run(args, **kwargs):
    print('+', ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), check=True, cwd=kwargs.pop('cwd', ROOT), **kwargs)

def git_head():
    try: return subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip()
    except (subprocess.CalledProcessError, FileNotFoundError): return 'source-kit'

def parameters():
    entries = {}
    for path in SOURCE.glob('*.pd'):
        for name, lo, hi, default in re.findall(r'r (kd_\w+) @hv_param ([\d.]+) ([\d.]+) ([\d.]+)', path.read_text()):
            entries[name] = {'name':name,'min':float(lo),'max':float(hi),'default':float(default),
                             'label':LABELS[name[3:]]}
    if len(entries) != 12: raise RuntimeError(f'Expected 12 parameters, found {len(entries)}')
    return [entries[name] for name in sorted(entries)]

def ensure_dpf():
    dpf = ROOT / 'dep/dpf'
    if not dpf.exists(): run(['git','clone','https://github.com/DISTRHO/DPF.git',dpf])
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=dpf, text=True).strip()
    if head != DPF_COMMIT: run(['git','checkout','--detach',DPF_COMMIT], cwd=dpf)
    run(['git','submodule','update','--init','--recursive'], cwd=dpf)

def generate():
    BUILD.mkdir(parents=True, exist_ok=True)
    meta = json.loads((SOURCE/'metadata.json').read_text())
    meta['name'] = 'Kottdisk'
    meta['nosimd'] = True
    meta['dpf'].update({'dpf_path':'../../../dep/', 'enable_ui':0, 'license':'GPL-3.0-or-later', 'version':'0, 1, 0'})
    (BUILD/'metadata.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2))
    if (BUILD/'heavy').exists(): shutil.rmtree(BUILD/'heavy')
    run([Path(sys.executable).parent/'hvcc',SOURCE/'kottdisk.pd','-p',SOURCE,'-o',BUILD/'heavy',
         '-n','Kottdisk','-m',BUILD/'metadata.json','-g','c','dpf'])
    generated = (BUILD/'heavy/c/Heavy_Kottdisk.h').read_text()
    actual = set(re.findall(r'HV_KOTTDISK_PARAM_IN_(KD_\w+) =', generated))
    expected = {p['name'].upper() for p in parameters()}
    if actual != expected: raise RuntimeError(f'Lost or extra hvcc parameters: {actual ^ expected}')

def native():
    files = sorted((BUILD/'heavy/c').glob('*.c')) + sorted((BUILD/'heavy/c').glob('*.cpp'))
    run(['g++','-std=c++17','-O2','-DHV_SIMD_NONE','-shared','-fPIC','-I',BUILD/'heavy/c',
         *files,SOURCE/'bridge.cpp','-o',BUILD/'libkottdisk.so'])

def web():
    emsdk = Path(os.environ.get('EMSDK', Path.home()/'emsdk'))
    compiler = shutil.which('em++') or str(emsdk/'upstream/emscripten/em++')
    env = os.environ.copy()
    env['EM_CONFIG'] = str(emsdk/'.emscripten')
    # A project-owned cache prevents changes to other agents' SDK build caches.
    env['EM_CACHE'] = str(BUILD/'emscripten-cache')
    default_cache = emsdk/'upstream/emscripten/cache'
    if not (BUILD/'emscripten-cache').exists() and default_cache.exists():
        shutil.copytree(default_cache, BUILD/'emscripten-cache')
    files = sorted((BUILD/'heavy/c').glob('*.c')) + sorted((BUILD/'heavy/c').glob('*.cpp'))
    exports = ['_kd_new','_kd_free','_kd_param','_kd_midi','_kd_transport','_kd_process','_malloc','_free']
    run([compiler,'-O2','-DHV_SIMD_NONE','-I',BUILD/'heavy/c',*files,SOURCE/'bridge.cpp',
         '-sMODULARIZE=1','-sEXPORT_ES6=1','-sEXPORT_NAME=createKottdiskModule',
         '-sSINGLE_FILE=1','-sWASM_ASYNC_COMPILATION=0','-sENVIRONMENT=web,worker',
         '-sALLOW_MEMORY_GROWTH=0','-sINITIAL_MEMORY=33554432','-sFILESYSTEM=0',
         '-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["HEAPF32"]',
         '-o',BUILD/'kottdisk-engine.js'], env=env)
    assemble()

def assemble():
    DIST.mkdir(parents=True, exist_ok=True)
    for path in (SOURCE/'web').iterdir():
        if path.is_file(): shutil.copy2(path, DIST/path.name)
    shutil.copy2(BUILD/'kottdisk-engine.js',DIST/'kottdisk-engine.js')
    (DIST/'params.json').write_text(json.dumps(parameters(),ensure_ascii=False,indent=2)+'\n')
    (DIST/'LICENSE.txt').write_text((SOURCE/'LICENSE.txt').read_text())
    notice = (BUILD/'heavy/c/HvHeavy.h').read_text().split('*/',1)[0] + '*/\n'
    (DIST/'HEAVY-NOTICES.txt').write_text(notice)
    version = hashlib.sha256(b''.join(p.read_bytes() for p in sorted(DIST.glob('*')) if p.is_file() and p.suffix in {'.js','.html','.css'})).hexdigest()[:16]
    sw = (SOURCE/'web/sw.js').read_text().replace('kottdisk-shell-v1','kottdisk-'+version)
    sw = sw.replace("'./manifest.webmanifest'", "'./kottdisk-engine.js', './params.json', './manifest.webmanifest'")
    (DIST/'sw.js').write_text(sw)
    (DIST/'build.json').write_text(json.dumps({'version':'0.1.0','source_commit':git_head(),'asset_hash':version,
                                             'documentation_commit':'d1212fc904ca322dd4b8d58528a0794be680faf2',
                                             'engine':'PlugData / hvcc 0.17.2 / Emscripten 3.1.69','dpf_commit':DPF_COMMIT},indent=2)+'\n')

def vst3():
    ensure_dpf()
    source = BUILD/'heavy/plugin/source'
    shutil.copy2(SOURCE/'plugin/KottdiskUI.cpp',source/'KottdiskUI.cpp')
    info = source/'DistrhoPluginInfo.h'
    text = info.read_text().replace('"Kottdisk"','"KÖTTDISK 3000"')
    text = re.sub(r'(#define DISTRHO_PLUGIN_HAS_UI\s+)0',r'\g<1>1',text)
    text += '\n#define DISTRHO_UI_USE_NANOVG 1\n#define DISTRHO_UI_DEFAULT_WIDTH 1200\n#define DISTRHO_UI_DEFAULT_HEIGHT 750\n#define DISTRHO_PLUGIN_WANT_PARAMETER_VALUE_CHANGE_REQUEST 1\n'
    info.write_text(text)
    dsp = source/'HeavyDPF_Kottdisk.cpp'
    text = dsp.read_text()
    start = text.index('void HeavyDPF_Kottdisk::handleMidiInput(')
    opening = text.index('{', start)
    depth, end = 1, opening + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    text = text[:start] + (SOURCE/'plugin/midiInput.cpp').read_text() + text[end:]
    text = re.sub(r'hv_Kottdisk_new_with_options\(getSampleRate\(\), [^;]+\);',
                  'hv_Kottdisk_new_with_options(getSampleRate(), 64, 32, 8);',text)
    # Pinned DPF's VST3 title conversion only handles ASCII. Preserve full Swedish
    # in both panels, but use unique transliterated titles in host parameter lists.
    for name,label in LABELS.items():
        host_label = label.translate(str.maketrans({'Å':'A','Ä':'A','Ö':'O'}))
        text = text.replace(f'parameter.name = "kd {name}";',f'parameter.name = "{host_label}";')
    dsp.write_text(text)
    makefile = source/'Makefile'
    text = makefile.read_text().replace('FILES_DSP = $(wildcard *.cpp)', 'FILES_DSP = $(filter-out KottdiskUI.cpp, $(wildcard *.cpp))')
    text = text.replace('DPF_TARGET_DIR =', 'FILES_UI = KottdiskUI.cpp\nUI_TYPE = opengl\n\nDPF_TARGET_DIR =')
    makefile.write_text(text)
    run(['make','-j2','vst3'], cwd=source)
    return BUILD/'heavy/bin/Kottdisk.vst3'

def packages(plugin=None):
    DIST.mkdir(parents=True, exist_ok=True)
    kit = DIST/'KOTTDISK_3000_Source.zip'
    with zipfile.ZipFile(kit,'w',zipfile.ZIP_DEFLATED) as z:
        paths = [ROOT/'tools/build_kottdisk.py', ROOT/'tools/render_kottdisk_clip.py',
                 ROOT/'requirements-kottdisk.txt', ROOT/'docs/kottdisk/README.md',
                 ROOT/'docs/kottdisk/LEVERANS.md']
        paths += [p for p in SOURCE.rglob('*') if p.is_file() and 'dist' not in p.relative_to(SOURCE).parts and '__pycache__' not in p.parts]
        paths += [ROOT/'tests/test_kottdisk.py', ROOT/'tests/run_kottdisk_web.cjs', ROOT/'tests/run_kottdisk_vst3.py',
                  ROOT/'tests/run_vst3_host.py']
        for p in paths:
            if p.exists(): z.write(p, 'KOTTDISK_3000/'+str(p.relative_to(ROOT)))
    downloads = [{'label':'Hämta källkod och byggkit','url':kit.name}]
    if plugin and plugin.exists():
        name='KOTTDISK_3000_Linux_x86_64.zip'
        with zipfile.ZipFile(DIST/name,'w',zipfile.ZIP_DEFLATED) as z:
            for p in plugin.rglob('*'):
                if p.is_file(): z.write(p, 'KOTTDISK_3000.vst3/'+str(p.relative_to(plugin)))
            z.write(SOURCE/'LICENSE.txt','LICENSE.txt')
        downloads.insert(0,{'label':'Hämta VST3 för Linux x86_64','url':name})
    (DIST/'downloads.json').write_text(json.dumps({'version':'0.1.0','commit':git_head(),'downloads':downloads,
                                                'source':kit.name,'license':'LICENSE.txt'},ensure_ascii=False,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native',action='store_true')
    parser.add_argument('--vst3',action='store_true')
    parser.add_argument('--skip-web',action='store_true')
    parser.add_argument('--kit',action='store_true')
    args=parser.parse_args()
    generate()
    if args.native: native()
    if not args.skip_web: web()
    plugin = vst3() if args.vst3 else None
    if args.kit or args.vst3: packages(plugin)
    print('KÖTTDISK klar:',DIST)

if __name__=='__main__': main()
