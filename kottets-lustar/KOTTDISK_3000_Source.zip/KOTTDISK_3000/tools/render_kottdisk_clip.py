#!/usr/bin/env python3
"""Render the catalog's 20-second C-minor preview through the real Pd engine."""
from pathlib import Path
import subprocess
import sys
import wave
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from test_kottdisk import Synth

def main():
    synth=Synth()
    parts=[]
    for notes in ([48,55,60,63,67],[44,51,56,60,63],[41,48,53,56,60],[43,50,55,58,62]):
        for note in notes: synth.note(note,90)
        parts.append(synth.audio(3.75))
        for note in notes: synth.note(note,0)
        parts.append(synth.audio(1.25))
    synth.close()
    audio=np.concatenate(parts)[:20*48000]
    assert np.isfinite(audio).all() and np.max(np.abs(audio))<1
    output=ROOT/'site/klipp/kottdisk.mp3'; output.parent.mkdir(parents=True,exist_ok=True)
    temporary=ROOT/'build/kottdisk/catalog.wav'
    with wave.open(str(temporary),'wb') as stream:
        stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(48000)
        stream.writeframes((audio*32767).astype('<i2').tobytes())
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(temporary),'-codec:a','libmp3lame','-b:a','160k',str(output)],check=True)
    print(output)

if __name__=='__main__': main()
