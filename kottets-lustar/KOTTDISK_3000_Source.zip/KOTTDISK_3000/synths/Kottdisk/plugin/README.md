# KÖTTDISK 3000 · VST3-panel

`KottdiskUI.cpp` är den egna DPF/NanoVG-panelen. Den använder samma fasta format,
1200 × 750, reglage, färger och saluhallsdisk som webbversionen. Ljudet kommer
från instrumentets kompilerade PlugData-patch.

Rattar dras uppåt eller åt höger. Skift ger finjustering; mushjulet ändrar också
värdet. Displayen visar reglagets namn, betydelse och värde 0–100. MÖRA är
momentan (mus eller mellanslag) och LÅT VILA är en spärr. Klaviaturen har 24 toner från C3; musdrag
byter ton. Datorns tangenter `A W S E D F T G Y H U J K O L P ; ' ] \ Z X C V`
spelar samma toner. Escape eller kugghjulets ”Släpp alla toner” släpper panelens
toner och återställer MÖRA och LÅT VILA. När panelen tappar fokus eller stängs
släpps endast dess egna nedtryckta tangenter och pågående reglagegester.
Värdens LÅT VILA och externt styrd MÖRA lämnas kvar; en pågående MÖRA-gest
från panelen släpps.
Tangenterna följer DPF:s teckenkoder och kan variera med tangentbordslayout.

Byggintegrationen ska använda `FILES_UI = KottdiskUI.cpp`, `UI_TYPE = opengl`,
`DISTRHO_PLUGIN_HAS_UI = 1` och `DISTRHO_UI_USE_NANOVG = 1`. Aktivera även
`DISTRHO_PLUGIN_WANT_MIDI_INPUT = 1` så att DPF erbjuder `sendNote`.
DPF:s inbäddade DejaVu Sans laddas med `loadSharedResources()`; ingen extern
typsnittsfil eller webbläsare behövs. Stäng inte av DPF:s delade resurser.

Parameterindex följer hvcc:s alfabetiska ordning:

| Index | Parameter |
| --- | --- |
| 0 | kd_attack |
| 1 | kd_bite |
| 2 | kd_decay |
| 3 | kd_hold |
| 4 | kd_ratio |
| 5 | kd_release |
| 6 | kd_space |
| 7 | kd_sustain |
| 8 | kd_tender |
| 9 | kd_tone |
| 10 | kd_volume |
| 11 | kd_warmth |

Alla värden är 0–1. Hoständringar läses i `parameterChanged`; användargester
omges av `editParameter` och skickas med `setParameterValue`. Panelens noter
skickas på MIDI-kanal 1 (`sendNote(0, …)`). DAW:ns externa MIDI går direkt till
ljudmotorn; panelens klaviatur och lampor visar panelens egna noter.
