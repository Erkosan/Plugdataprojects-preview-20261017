// Build-time replacement for hvcc 0.17.2's MIDI handler.
// Read only the current event and preserve its sample offset within the block.
void HeavyDPF_Kottdisk::handleMidiInput(uint32_t frames, const MidiEvent* events, uint32_t count)
{
  for (uint32_t i = 0; i < count; ++i) {
    const MidiEvent& event = events[i];
    const uint8_t* data = event.size > 4 ? event.dataExt : event.data;
    if (!data || event.size == 0) continue;
    const int status = data[0];
    const int channel = status & 15;
    const double delay = 1000.0 * (event.frame < frames ? event.frame : frames - 1) / getSampleRate();
    if (status >= 248) {
      _context->sendMessageToReceiverV(HV_HASH_MIDIREALTIMEIN, delay, "ff", (float)status, 0.0f);
      continue;
    }
    if (event.size < 3) continue;
    const int a = data[1] & 127, b = data[2] & 127;
    switch (status & 240) {
      case 128:
        _context->sendMessageToReceiverV(HV_HASH_NOTEIN, delay, "fff", (float)a, 0.0f, (float)channel);
        break;
      case 144:
        _context->sendMessageToReceiverV(HV_HASH_NOTEIN, delay, "fff", (float)a, (float)b, (float)channel);
        break;
      case 176: {
        _context->sendMessageToReceiverV(HV_HASH_CTLIN, delay, "fff", (float)b, (float)a, (float)channel);
        if (channel != 0 && channel != 8) break;
        // Keep saved host parameter state aligned with mapped MIDI CCs.
        int index = -1;
        switch (a) {
          case 7: index=10; break; case 1: index=1; break;
          case 16:index=9;break; case 17:index=1;break; case 18:index=4;break;
          case 19:index=0;break; case 20:index=2;break; case 21:index=7;break;
          case 22:index=5;break; case 23:index=11;break; case 24:index=6;break;
          case 25:index=8;break; case 26:case 64:index=3;break;
          case 120:case 123:
            _parameters[3]=0.0f; _parameters[8]=0.0f;
            requestParameterValueChange(3,0.0f); requestParameterValueChange(8,0.0f);
            break;
        }
        if (index >= 0) {
          const float value = index == 3 || index == 8 ? (b >= 64 ? 1.0f : 0.0f) : (float)b/127.0f;
          _parameters[index]=value;
          requestParameterValueChange((uint32_t)index,value);
        }
        break;
      }
    }
  }
}
