# KÖTTDISK 3000

Första och enda instrumentet i KÖTTETS LUSTAR: ett anslagskänsligt FM-keyboard med sex röster och fyra sinusoperatorer per röst. Av Pastor Gregorius.

Öppna `kottdisk.pd` i PlugData. Den redigerbara panelen är 1200 × 750 på ett 25-pixelsrutnät. Pianot har två oktaver, C3–B4; klick spelar ett kort anslag. Ett externt MIDI-keyboard ger full anslagskänslighet och hålltid. Samma patch kompileras med hvcc 0.17.2 till webb och VST3. Webbsidans JavaScript producerar inget ljud.

`KD_Engine.pd` samlar sex separata `KD_Voice.pd`, `KD_Parameters.pd` och `KD_Midi.pd`. Fyra harmoniska operatorer ligger i en seriell fasmodulationskedja. Anslag och amplitudenveloppen styr FM-djupet; modulationsdjupet minskar i diskanten för att begränsa vikningsbrus. En lågpassfiltrering, mjuk mättnad och ett kort stereorum avslutar motorn. Samtliga inställningar har startvärden via `loadbang` och utjämnade signalvägar där det behövs.

| Parameter | Panel | Standard | MIDI CC |
|---|---|---:|---:|
| `kd_volume` | VOLYM · UTNIVÅ | 0.65 | 7 |
| `kd_tone` | DISK · LJUSHET | 0.65 | 16 |
| `kd_bite` | MARMORERING · FM | 0.35 | 17 samt 1 |
| `kd_ratio` | STYCKNING · ÖVERTONER | 0.25 | 18 |
| `kd_attack` | ANSATS · ANSATS | 0.08 | 19 |
| `kd_decay` | MÖRHET · AVKLINGNING | 0.40 | 20 |
| `kd_sustain` | KROPP · HÅLLNIVÅ | 0.45 | 21 |
| `kd_release` | VILA · SLÄPP | 0.30 | 22 |
| `kd_warmth` | FETT · MÄTTNAD | 0.20 | 23 |
| `kd_space` | SALUHALL · RUM | 0.18 | 24 |
| `kd_tender` | MÖRA · EXTRA BETT | 0 | 25 |
| `kd_hold` | LÅT VILA · HÅLL TONER | 0 | 26 samt 64 |

Alla tolv parametrar har intervallet 0–1 och är deklarerade som `@hv_param`. `kd_ratio` väljer harmoniska kvoter 1, 2, 3, 4, 6, 8. Attack är 3–1203 ms, decay 35–2435 ms och release 30–3230 ms med kvadratisk rattkurva. LÅT VILA är aktiv från 0.5. MÖRA på PlugData-panelen är en 180 ms lång gest; webb och värd skickar själva 1 vid nedtryck och 0 vid släpp. MIDI CC25, CC26 och CC64 är binära: värden från 64 aktiverar gesten, lägre värden släpper den. Ingen tonart eller tempoparameter finns. Exempel och presets skrivs i c-moll.

MIDI lyssnar på kanal **1 och 9**. Kanalnumren från vanilla Pd `notein` och `ctlin` är ettbaserade. Heavy-mottagarna `__hv_notein` och `__hv_ctlin` använder däremot nollbaserade kanaler: wrappers ska skicka **0 eller 8**, så översätter hvcc:s standardabstraktioner till 1 och 9. Note-on med anslag 0 fungerar som note-off. Kanalernas noter har separata interna identiteter (`ton + 128 × kanalindex`) så att samma ton på den ena kanalen inte släpps av den andras note-off. Innan `mtof` återställs identiteten till tonnumret med modulo 128.

Hållpedalen skjuter upp note-off före `poly 6 1`, med en tabell över väntande släpp för de 256 kanal/ton-identiteterna. Släppta tangenter behåller därför sin röst tills pedalen släpps eller den sjunde tonen stjäl den äldsta aktiva rösten. Pedalsläpp skickar endast de väntande släppen, så fysiskt nedtryckta tangenter fortsätter klinga. Ett nytt anslag av samma ton på samma kanal ersätter föregående anslag och rensar dess väntande släpp. CC120 och CC123 tystar alla röster med en 5 ms ramp, tömmer väntande släpp och nollställer röstfördelaren samt parametrarna LÅT VILA och MÖRA direkt i patchen.

PlugData-pianot skickar interna listor `ton anslag` till `kd_ui_note`; webben och VST3 använder standard-MIDI, aldrig en separat syntmotor. GUI-mottagarna `kd_*_ui` använder explicita `set`-meddelanden och `route float` på sändningssidan för att spegla värden utan rundgång även i Heavy. Patchen har inga externa ljudbibliotek, samples, JavaScript-oscillatorer eller separata ljudfiler. För mycket tät MIDI använder wrappers lämpligen `hv_Kottdisk_new_with_options(sr,64,32,8)` i stället för standardkön.

Källan är de incheckade `.pd`-filerna. Layouten och kabeldragningen kan även återbildas deterministiskt med `python3 synths/Kottdisk/generate_patch.py`. Kompilera med `hvcc synths/Kottdisk/kottdisk.pd -n Kottdisk -o /tmp/kottdisk-audio-check`; motorprefixet är `hv_Kottdisk_*`. Plugin-ID är `Kd30`, varumärkes-ID `Erks`.

Bygg- och testkommandon för webb och VST3 finns i repots byggverktyg. Riktigt ljud ska kontrolleras med nativ motortest, Chromium och VST3-värd. Plattformar som inte faktiskt har provats ska redovisas separat.
