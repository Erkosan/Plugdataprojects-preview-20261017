// KÖTTDISK host bridge. All synthesis and effects live in the Pd patch.
#include "Heavy_Kottdisk.h"
#include <cmath>
#include <cstdint>

static const char* parameters[] = {
  "kd_attack", "kd_bite", "kd_decay", "kd_hold", "kd_ratio", "kd_release",
  "kd_space", "kd_sustain", "kd_tender", "kd_tone", "kd_volume", "kd_warmth"
};
extern "C" {
void* kd_new(double sr) { return hv_Kottdisk_new_with_options(sr, 64, 32, 4); }
void kd_free(void* c) { hv_Kottdisk_free((HeavyContextInterface*)c); }
void kd_param(void* c, int index, float value) {
  if (!c || index < 0 || index >= 12 || !std::isfinite(value)) return;
  hv_sendFloatToReceiver((HeavyContextInterface*)c, hv_stringToHash(parameters[index]), fmaxf(0, fminf(1, value)));
}
void kd_midi(void* c, int status, int first, int second) {
  if (!c) return;
  auto* context = (HeavyContextInterface*)c;
  int channel = status & 15;
  first &= 127; second &= 127;
  switch(status & 240) {
    case 128: hv_sendMessageToReceiverFFF(context, hv_stringToHash("__hv_notein"), 0, first, 0, channel); break;
    case 144: hv_sendMessageToReceiverFFF(context, hv_stringToHash("__hv_notein"), 0, first, second, channel); break;
    case 176: hv_sendMessageToReceiverFFF(context, hv_stringToHash("__hv_ctlin"), 0, second, first, channel); break;
  }
}
void kd_transport(void* c, double bpm, int playing) {
  if (!c || !std::isfinite(bpm)) return;
  auto* context = (HeavyContextInterface*)c;
  hv_sendFloatToReceiver(context, hv_stringToHash("__hv_dpf_bpm"), (float)bpm);
  hv_sendMessageToReceiverFF(context, hv_stringToHash("__hv_midirealtimein"), 0, playing ? 250 : 252, 0);
}
void kd_process(void* c, float* output, int frames) {
  if (c && frames > 0) hv_processInlineInterleaved((HeavyContextInterface*)c, nullptr, output, frames);
}
}
