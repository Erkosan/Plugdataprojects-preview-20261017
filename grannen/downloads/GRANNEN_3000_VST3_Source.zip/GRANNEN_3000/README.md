# GRANNEN 3000

Miljonprogrammets betongstomme, subbas, bärvägg och elementrör i C-moll (1971) — första maskinen i **FOLKHEMMETS SKUGGOR**. Ljudet är PlugData-patcharna i den här mappen (`grannen.pd` och `GR_*.pd`) och kompileras med hvcc 0.17.2 till C/C++, WebAssembly och DPF VST3.

## Patcharna

| Fil | Vad |
| --- | --- |
| `grannen.pd` | Huvudpatch med redigerbar PlugData-panel (`cnv`, `hsl`, `tgl`, `bng`) på 25px-rutnät, utjämnade ratt-parametrar (`@hv_param` → `line~` → `s~ gr_*`) och koppling mellan subpatcharna. |
| `GR_Seq.pd` | 16-stegsslinga i C-moll med `metro`, `midirealtimein` (248, 250, 251, 252), `__hv_dpf_bpm`, `swing`, `length` och `table gr_steps 16`. |
| `GR_Mono.pd` | Monofon MIDI-mottagare på kanal 8 och delade kanal 1 (`table gr_held 128`). Senaste tonen gäller, överlapp = glid, släpp = tillbaka till hållen ton, velocity ≥ 100 = accent. |
| `GR_CC.pd` | MIDI CC på kanal 8 och 1 (CC16–28, CC74, CC71, CC77, CC64, CC14, CC15, CC7, CC120/123). |
| `GR_Voice.pd` | Subbas + oktav-sub (`sub`), anslagsduns (`punch`), stommens avklingning (`decay`), glid (`glide`), bärväggsfilter med C-moll-väggmoder (`wall`: C2, G2, C3, Eb3), elementrörens C-moll-metallklirr (`pipe`: C4, Eb4, G4, Bb4, D5) och `VRÄKNING` (-1 oktav sub-dyk). |
| `GR_Klagar.pd` | `GRANNEN KLAGAR · KVAST I TAKET` (`klagar`): rytmiska kvastdunk i taket och elementrören i C-moll (C3, G3, Eb4) samt duckning/pump i basen. |
| `GR_FX.pd` | `VENTILATION · OVERDRIVE` (`hum`), `TRAPPHUS · RUMSKLANG` (`stair`), mastervolym (`volume`) och mjuk begränsare. |

## Parametrar

| Namn | Område | Standard | Ratt / CC |
| --- | --- | --- | --- |
| `sub` | 0–1 | 0,70 | BETONG · SUBNIVÅ · CC16 |
| `punch` | 0–1 | 0,55 | DUNS · ANSLAG · CC17 |
| `decay` | 0–1 | 0,45 | STOMME · AVKLINGNING · CC18 |
| `glide` | 0–1 | 0,25 | SVIKT · GLID · CC19 |
| `wall` | 0–1 | 0,65 | BÄRVÄGG · FILTER · CC74 & CC20 |
| `pipe` | 0–1 | 0,35 | ELEMENTRÖR · METALLKLIRR · CC71 & CC21 |
| `hum` | 0–1 | 0,30 | VENTILATION · OVERDRIVE · CC77 & CC22 |
| `stair` | 0–1 | 0,22 | TRAPPHUS · RUMSKLANG · CC23 |
| `volume` | 0–1 | 0,80 | VOLYM · UTNIVÅ · CC7 & CC24 |
| `klagar` | 0/1 | 0 | GRANNEN KLAGAR · KVAST I TAKET · CC25 |
| `vrakning` | 0/1 | 0 | VRÄKNING · SUB-DYK · CC64 & CC26 |
| `bpm` | 30–300 | 120 | TEMPO · CC14 |
| `start` | 0/1 | 0 | START · CC15 |
| `swing` | 0–1 | 0,15 | SVÄNG · CC27 |
| `length` | 1–16 | 16 | LÄNGD · CC28 |
| `step0`–`step15` | 0–399 | C-moll-basgång | 0 = paus, 1..99 = ton, +100 = accent, +200 = glid, +300 = accent+glid |
