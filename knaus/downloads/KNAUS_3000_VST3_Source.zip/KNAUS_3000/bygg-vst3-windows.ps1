$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$msys = 'C:\msys64\msys2_shell.cmd'
if (-not (Test-Path $msys)) {
  throw 'MSYS2 saknas. Installera MSYS2 till C:\msys64 och följ BUILD-VST3.md.'
}
& $msys -defterm -here -no-start -ucrt64 -c "python -X utf8 tools/build.py $args"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host 'Klart. Windows VST3 finns i build/bin/KNAUS_3000.vst3.'
