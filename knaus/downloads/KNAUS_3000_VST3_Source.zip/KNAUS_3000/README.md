# KNAUS 3000

Lo-fi polyfonisk husvagnssynth för campingsemestern. Den första maskinen i **Camping-serien** (Pastor Gregorius 3000-serie). Ljudet är rena Pure Data/PlugData-patchar som kompileras med hvcc till både en fristående webbapplikation med AudioWorklet och en VST3 för macOS, Windows och Linux.

```
knaus.pd  →  hvcc  →  C  →  Emscripten  →  knaus-engine.js  →  AudioWorklet (web/worklet.js)
          →  byggkit (hvcc -g dpf)  →  VST3 för macOS (Universal), Windows och Linux
```

## Koncept och ton

Husvagnen står uppställd på campingen vid Vättern en regnig tisdagkväll i juli. Genom takluckan smattrar ett jämnt ösregn (`ÖSREGN · TAKBRUS`), batteriet i bodelen svajar lätt med nostalgiskt svaj (`BATTERI · FLUTTER`), gasolvärmaren sprakar svagt med varm saturation (`GASOL · MÄTTNAD`), och om campingen överbelastas trycker man på den röda panikknappen (`STRÖMAVBROTT`).

All musik och sequencersekvenser ligger i C-moll som standard.

## Patcharna

Alla patchar är vanilla Pure Data och kan öppnas och redigeras direkt i PlugData. Huvudpatchen är `knaus.pd`.

| Fil | Beskrivning |
| --- | --- |
| `knaus.pd` | Huvudpatch. Rattarnas parametrar (`@hv_param`) → utjämnade signaler (`s~ kn_*`), moduler, master mix och `dac~`. |
| `KN_Voice.pd` | 4 polyfona röster. Tre vågformer (0=orgel/sinus, 1=puls, 2=sågtand), ADSR-kuvert via `line~`, 4-poligt resonant lågpassfilter (`cpole~`-kaskad med DC-gainnormalisering), gasolmättnad (`tanh`), och röstbaserad stereopanering. |
| `KN_Seq.pd` | 16-stegs sequencer i c-moll med gate, tonväljare, längd (1–16 steg), swing och tempo. Följer värdens transport och MIDI-klocka (`__hv_dpf_bpm`, realtime start/stop). |
| `KN_Notes.pd` | Polyfon röstallokering via `[poly 4 1]` för 4 samtidiga röster på MIDI-kanal 3 (och kanal 1). Korrekt avkodning och röststyrning till `kn_v1`–`kn_v4`. |
| `KN_FX.pd` | Takbrusamplifiering (`ÖSREGN`), LFO-batterisvaj (`BATTERI`), strömavbrotts-panic (`STRÖMAVBROTT`) med 12 ms klickfri mjuk dämpning och tystnad, mastervolym och mjuk limiter. |
| `KN_CC.pd` | MIDI CC-inmatning på kanal 3 och 1. |

## Parametrar

| Namn | Område | Standard | Reglage / Betydelse |
| --- | --- | --- | --- |
| `wave` | 0–2 | 1 | VÅGFORM · 0=SINUS, 1=PULS, 2=SÅG |
| `cutoff` | 0–1 | 0,45 | KONDENS · FILTER CUTOFF |
| `resonance` | 0–1 | 0,4 | MYGG · RESONANS |
| `envmod` | 0–1 | 0,5 | IMMA · KUVERTMODULERING |
| `attack` | 0–1 | 0,05 | SVÄLL · ATTACK |
| `decay` | 0–1 | 0,35 | KLIBB · DECAY |
| `sustain` | 0–1 | 0,6 | STUDS · SUSTAIN |
| `release` | 0–1 | 0,4 | SLÄPP · RELEASE |
| `drive` | 0–1 | 0,35 | GASOL · MÄTTNAD |
| `rain` | 0–1 | 0 (DAW) / 0,35 (Web) | ÖSREGN · TAKBRUS |
| `flutter` | 0–1 | 0,25 | BATTERI · SVAJ |
| `brownout` | 0/1 | 0 | STRÖMAVBROTT · PANIKKNAPP |
| `volume` | 0–1 | 0,8 | VOLYM · MASTER |
| `bpm` | 30–300 | 116 | TEMPO · BPM |
| `start` | 0/1 | 0 | SEQUENCER START/STOPP |
| `length` | 1–16 | 16 | SEQUENCER LÄNGD |
| `swing` | 0–1 | 0 | SEQUENCER SWING |
| `step0`–`step15` | 0–511 | c-moll förval | Stegkod: ton + 64·gate + 128·accent |

## MIDI-mappning

- **MIDI-kanal:** Kanal 3 (primär för Knaus) samt kanal 1.
- **CC-kontroller:**
  - CC 7: Volym
  - CC 74: Kondens (Cutoff)
  - CC 71: Mygg (Resonans)
  - CC 1: Batterisvaj (Flutter)
  - CC 14: Tempo (BPM)
  - CC 15: Sequencer Start/Stopp
  - CC 16: Gasol (Drive)
  - CC 17: Ösregn (Takbrus)
  - CC 120 / CC 123: All Notes Off / Panic

## Bygga och testa

### 1. Bygg webb och VST3
```bash
python3 tools/build_knaus.py --vst3
```

### 2. Kör motortester
```bash
python3 -m unittest tests/test_knaus.py
```

### 3. Kör VST3-värdtest
```bash
python3 tests/run_vst3_host.py build/knaus/kit/KNAUS_3000/build/bin/KNAUS_3000.vst3
```

### 4. Kör webbtest (Headless Chromium Playwright med ljudmätning)
```bash
python3 tests/run_knaus_web.py
```
