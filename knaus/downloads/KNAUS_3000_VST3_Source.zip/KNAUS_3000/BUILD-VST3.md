# KNAUS 3000 — bygg VST3

**Skapare:** Pastor Gregorius  
**Format:** VST3 (macOS, Windows och Linux)  
**Kategori:** Synth / Husvagns-keyboard / Polyfon

Ljudet är PlugData-patcharna i den här mappen (`knaus.pd` och `KN_*.pd`). Öppna dem i PlugData för att lyssna eller ändra. Bygget gör om exakt samma patchar till en VST3 med hvcc och DPF, och motorn är densamma som på webben. Pluginet har värdens vanliga reglage för alla rattar. Slingan följer DAW:ns start, stopp och tempo.

## macOS

Krav: Python 3.10+, Git och Xcode Command Line Tools (`xcode-select --install`).

```bash
bash bygg.command
```

Resultat: `build/bin/KNAUS_3000.vst3`, universal binary (Intel och Apple Silicon). `bash bygg.command --install` installerar direkt till `~/Library/Audio/Plug-Ins/VST3/`.

## Windows 10/11

Kör från PowerShell i projektmappen:

```powershell
.\bygg-vst3-windows.ps1
```

Kräver MSYS2 UCRT64 (`C:\msys64`) och Windows-Python 3.13. Resultat: `build/bin/KNAUS_3000.vst3`.

## Linux

Krav: `python3-venv git make g++`.

```bash
chmod +x bygg-vst3-linux.sh
./bygg-vst3-linux.sh
```

Resultat: `build/bin/KNAUS_3000.vst3`. `./bygg-vst3-linux.sh --install` kopierar till `~/.vst3/`.

## I DAW:n

- **MIDI:** kanal 3 och den delade kanal 1.
- **Slingan:** följer DAW:ns transport (start, stopp och tempo).
- **Steg:** parametrarna `step0`–`step15` sparas med DAW-projektet.
