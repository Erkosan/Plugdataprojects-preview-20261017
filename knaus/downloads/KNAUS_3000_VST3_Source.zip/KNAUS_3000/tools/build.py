#!/usr/bin/env python3
"""KNAUS 3000 byggkit: låsta verktyg, hvcc-export och VST3-bygge på den här datorn.

    python3 tools/build.py            # VST3 i build/bin/KNAUS_3000.vst3
    python3 tools/build.py --install  # och kopiera den till systemets VST3-mapp
"""
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import time

ROOT = Path(__file__).resolve().parents[1]
NAME = 'KNAUS_3000'
PINS = {'dpf': ('https://github.com/DISTRHO/DPF.git', '4238e1c7f0351bbe488d79f0899c540543ac7583')}
PATCHES = ['knaus.pd', 'KN_Voice.pd', 'KN_Seq.pd', 'KN_Notes.pd', 'KN_CC.pd', 'KN_FX.pd']


def run(args, cwd=ROOT, env=None):
    print('+', ' '.join(map(str, args)), flush=True)
    started = time.monotonic()
    process = subprocess.Popen(list(map(str, args)), cwd=cwd, env=env)
    while True:
        try:
            result = process.wait(timeout=30)
            if result:
                raise subprocess.CalledProcessError(result, args)
            print(f'  Klart ({time.monotonic() - started:.1f} s)', flush=True)
            return
        except subprocess.TimeoutExpired:
            print(f'  Arbetar fortfarande… {time.monotonic() - started:.0f} s', flush=True)


def ensure_windows_python():
    if 'mingw' not in (sysconfig.get_config_var('SOABI') or '').lower():
        return
    candidates = []
    if os.environ.get('KNAUS_WINDOWS_PYTHON'):
        candidates.append([os.environ['KNAUS_WINDOWS_PYTHON']])
    launcher = shutil.which('py.exe') or shutil.which('py')
    if launcher:
        candidates.append([launcher, '-3.13'])
    local = os.environ.get('LOCALAPPDATA', '')
    if local:
        candidates.append([str(Path(local) / 'Programs/Python/Python313/python.exe')])
        candidates.append([str(Path(local) / 'Programs/Python/Launcher/py.exe'), '-3.13'])
    candidates.append([str(Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'py.exe'), '-3.13'])
    probe = ('import sys,sysconfig; print(int(sys.version_info[:2] == (3,13) and sys.platform == "win32" '
             'and "mingw" not in (sysconfig.get_config_var("SOABI") or "").lower()))')
    for candidate in candidates:
        try:
            out = subprocess.check_output([*candidate, '-c', probe], stderr=subprocess.DEVNULL).decode().strip()
            if out == '1':
                venv = ROOT / '.venv-windows'
                python = venv / 'Scripts/python.exe'
                if not python.is_file():
                    run([*candidate, '-m', 'venv', venv])
                    run([python, '-m', 'pip', 'install', '--upgrade', 'pip'])
                    run([python, '-m', 'pip', 'install', '-r', ROOT / 'requirements.lock'])
                os.execv(str(python), [str(python), *sys.argv])
        except Exception:
            continue
    raise RuntimeError('Hittade inte Windows-Python 3.13.')


def python_environment():
    venv = ROOT / '.venv'
    python = venv / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    if sys.executable != str(python):
        if not python.is_file():
            run([sys.executable, '-m', 'venv', venv])
            run([python, '-m', 'pip', 'install', '--upgrade', 'pip'])
            run([python, '-m', 'pip', 'install', '-r', ROOT / 'requirements.lock'])
        os.execv(str(python), [str(python), *sys.argv])
    try:
        found = importlib.metadata.version('hvcc')
        if found != '0.17.2':
            raise RuntimeError(f'hvcc {found} != 0.17.2')
    except importlib.metadata.PackageNotFoundError:
        run([python, '-m', 'pip', 'install', '-r', ROOT / 'requirements.lock'])


def dependencies():
    dep = ROOT / 'dep'
    dep.mkdir(exist_ok=True)
    for name, (url, commit) in PINS.items():
        target = dep / name
        if not (target / '.git').is_dir():
            run(['git', 'clone', url, target])
            run(['git', '-C', target, 'checkout', '--detach', commit])
            run(['git', '-C', target, 'submodule', 'update', '--init', '--recursive'])


def export():
    for name in PATCHES + ['metadata.json']:
        if not (ROOT / name).is_file():
            raise RuntimeError(f'Källfil saknas: {name}')
    build = ROOT / 'build'
    if (build / 'plugin').exists():
        shutil.rmtree(build / 'plugin')
    build.mkdir(exist_ok=True)
    metadata = json.loads((ROOT / 'metadata.json').read_text(encoding='utf-8'))
    metadata['dpf']['dpf_path'] = os.path.relpath(ROOT / 'dep', build).replace(os.sep, '/') + '/'
    meta = build / 'metadata.build.json'
    meta.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    hvcc = Path(sys.executable).parent / ('hvcc.exe' if os.name == 'nt' else 'hvcc')
    if not hvcc.is_file():
        hvcc = Path(shutil.which('hvcc') or '')
        if not hvcc.is_file():
            raise RuntimeError('Hittar inte hvcc')
    run([hvcc, ROOT / 'knaus.pd', '-o', build, '-n', 'knaus', '-m', meta, '-g', 'dpf',
         '--copyright', 'KNAUS 3000. Creator: Pastor Gregorius. Generated using hvcc.'])


def compile_plugin(jobs):
    env = dict(os.environ)
    flags = ['-DHV_SIMD_NONE']
    if sys.platform == 'darwin':
        flags += ['-arch', 'x86_64', '-arch', 'arm64', '-mmacosx-version-min=10.15']
        env['LDFLAGS'] = (env.get('LDFLAGS', '') + ' -arch x86_64 -arch arm64').strip()
    env['CFLAGS'] = (env.get('CFLAGS', '') + ' ' + ' '.join(flags)).strip()
    env['CXXFLAGS'] = (env.get('CXXFLAGS', '') + ' ' + ' '.join(flags)).strip()
    command = ['make', f'-j{jobs}', 'vst3']
    if sys.platform == 'win32':
        command.append('EXTRA_UI_LIBS=-lws2_32 -lshell32 -lole32 -luuid')
    run(command, cwd=ROOT / 'build/plugin/source', env=env)
    bundle = ROOT / 'build/bin' / f'{NAME}.vst3'
    if not bundle.is_dir():
        raise RuntimeError(f'Bygget gav ingen {bundle}')
    if sys.platform == 'darwin' and shutil.which('codesign'):
        run(['codesign', '--force', '--deep', '--sign', '-', bundle])
    return bundle


def install(bundle):
    if sys.platform == 'darwin':
        target = Path.home() / 'Library/Audio/Plug-Ins/VST3'
    elif sys.platform == 'win32':
        target = Path(os.environ.get('CommonProgramFiles', r'C:\Program Files\Common Files')) / 'VST3'
    else:
        target = Path.home() / '.vst3'
    target.mkdir(parents=True, exist_ok=True)
    dest = target / bundle.name
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(bundle, dest)
    print('Installerad i', dest)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--install', action='store_true', help='kopiera VST3:an till systemets VST3-mapp')
    parser.add_argument('--prepare-only', action='store_true', help='generera källkoden utan att kompilera')
    parser.add_argument('-j', '--jobs', type=int, default=min(os.cpu_count() or 2, 4))
    args = parser.parse_args()
    ensure_windows_python()
    python_environment()
    dependencies()
    export()
    if args.prepare_only:
        print('Källkoden finns i build/plugin/source.')
        return
    bundle = compile_plugin(args.jobs)
    if args.install:
        install(bundle)
    print(f'\nKlart: {bundle}')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        sys.exit(error.returncode)
    except (OSError, ValueError, RuntimeError) as error:
        sys.exit(str(error))
